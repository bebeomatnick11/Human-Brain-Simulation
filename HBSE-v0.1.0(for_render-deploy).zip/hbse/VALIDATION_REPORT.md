# HBSE v0.1.0 — Local validation report

This report records a local validation run of the source archive. It is not a neuroscience validity claim or a comparison with another computer.

## Automated and live checks

- Python: 3.13.5
- NumPy: 2.3.5
- FastAPI: 0.128.2
- pytest: 9.0.2
- Unit/API/scheduler tests: **16 passed**
- Python compile check: passed (`python -m compileall -q main.py hbse benchmarks tests`).
- Live HTTP smoke test: `/health` returned HTTP 200; `POST /v1/simulate` completed 2 ticks with HTTP 200; the final tick was 2 and `finite_state` was true.
- Checkpoint tests: missing token was rejected; a valid checkpoint restored; modified state failed SHA-256 integrity validation.

## Microbenchmarks

Single run from `python benchmarks/run_benchmarks.py`, Linux x86_64. Results vary by CPU, operating-system load, Python and NumPy build; rerun on the target host.

| Test | Input | Observed result |
|---|---:|---:|
| Rate network | 128 rate units, 1,929 present synapses, 2,000 steps | 0.3018 seconds; approximately 6,628 steps/second |
| Episodic recall | 1,000 stored traces, 200 queries, top-5 results | 0.1058 seconds; approximately 1,890 queries/second |
| End-to-end engine | 32 rate units, 500 simulation ticks | 0.0763 seconds; approximately 6,551 ticks/second |

The complete raw payload is included as `HBSE-benchmark-run.json`. The script also emits `benchmark-results.local.json`, excluded from normal Git commits.

## Interpretation limits

- These are timing measurements, not measures of human-like cognition or neural fidelity.
- No biological dataset was fitted or evaluated in this initial release.
- The microbenchmark uses synthetic inputs and one run per workload; it provides no confidence interval, warm-up study, hardware-normalized comparison, or baseline from another implementation.
- The actual implementation is the documented rate-based approximation; it does not implement action potentials, detailed synaptic biophysics, region-specific human anatomy, or subjective consciousness.
