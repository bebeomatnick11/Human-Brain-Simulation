"""ASGI entry point used by Uvicorn and Render."""
from hbse.api.app import app

__all__ = ["app"]
