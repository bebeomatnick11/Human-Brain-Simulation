from fastapi.testclient import TestClient
from hbse.api.app import app

client = TestClient(app)


def test_health_and_status():
    assert client.get("/health").status_code == 200
    status = client.get("/v1/status")
    assert status.status_code == 200
    assert status.json()["engine"] == "HBSE"


def test_simulation_endpoint_advances_state():
    before = client.get("/v1/status").json()["tick"]
    response = client.post("/v1/simulate", json={"ticks": 2, "stimulus": {"novelty": 0.4}})
    assert response.status_code == 200, response.text
    assert response.json()["tick"] == before + 2


def test_api_rejects_invalid_stimulus():
    response = client.post("/v1/simulate", json={"ticks": 1, "stimulus": {"novelty": 5}})
    assert response.status_code == 422


def test_checkpoint_requires_auth_and_restores_verified_state(monkeypatch, tmp_path):
    from dataclasses import replace
    import hbse.api.app as api_module

    monkeypatch.setattr(
        api_module,
        "settings",
        replace(api_module.settings, api_token="unit-test-secret", state_file=tmp_path / "hbse.json"),
    )
    denied = client.post("/v1/checkpoint")
    assert denied.status_code == 401

    headers = {"Authorization": "Bearer unit-test-secret"}
    snapshot = client.post("/v1/checkpoint", headers=headers)
    assert snapshot.status_code == 200, snapshot.text
    payload = snapshot.json()
    assert client.get("/v1/checkpoint", headers=headers).status_code == 200

    advanced = client.post(
        "/v1/simulate", headers=headers,
        json={"ticks": 1, "stimulus": {"novelty": 0.9}},
    )
    assert advanced.status_code == 200
    restored = client.post("/v1/restore", headers=headers, json=payload)
    assert restored.status_code == 200, restored.text
    assert restored.json()["tick"] == payload["state"]["tick"]

    tampered = dict(payload)
    tampered["state"] = dict(payload["state"], tick=payload["state"]["tick"] + 100)
    mismatch = client.post("/v1/restore", headers=headers, json=tampered)
    assert mismatch.status_code == 400
