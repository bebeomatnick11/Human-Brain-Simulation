from hbse.memory.store import MemoryStore


def test_working_and_episodic_memory_are_bounded():
    memory = MemoryStore(working_capacity=3, episodic_capacity=2)
    for tick in range(5):
        memory.observe(tick, {"novelty": 1.0}, "novelty", 0.9)
    assert len(memory.working) == 3
    assert len(memory.episodes) == 2
    assert memory.dropped_episodes == 3
    assert [item.id for item in memory.episodes] == [1, 2]  # older records are preserved


def test_recall_prioritizes_tag_overlap():
    memory = MemoryStore()
    memory.encode(1, "threat episode", ["threat"], 0.3)
    memory.encode(2, "novelty episode", ["novelty"], 0.3)
    result = memory.recall(["threat"], limit=2)
    assert result[0]["content"] == "threat episode"
    assert result[0]["retrieval_count"] == 1
