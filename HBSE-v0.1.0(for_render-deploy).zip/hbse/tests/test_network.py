import numpy as np
import pytest
from hbse.neural.rate_network import RateNetwork


def test_rate_network_stays_finite_and_bounded():
    net = RateNetwork(n=32, seed=1)
    for _ in range(100):
        net.step({"novelty": 0.4, "threat": 0.2, "reward": 0.1})
    assert np.isfinite(net.rates).all()
    assert np.all((net.rates >= 0) & (net.rates <= 1))
    assert np.isfinite(net.weights).all()
    assert np.all((net.weights >= 0) & (net.weights <= 0.5))
    assert np.all(net.weights[net.connectivity == 0] == 0)


def test_same_seed_initializes_same_network():
    first, second = RateNetwork(16, 12), RateNetwork(16, 12)
    np.testing.assert_allclose(first.weights, second.weights)


def test_unknown_network_features_fail():
    with pytest.raises(ValueError):
        RateNetwork().step({"telepathy": 1})
