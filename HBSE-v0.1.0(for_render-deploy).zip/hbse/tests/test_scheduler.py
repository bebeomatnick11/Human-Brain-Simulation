import pytest
from hbse.simulation.scheduler import SimulationScheduler


def test_scheduler_periods_and_commit_validation():
    scheduler = SimulationScheduler()
    scheduler.register("every_tick")
    scheduler.register("every_two", every_n_ticks=2)
    first = scheduler.plan_next()
    assert first == {"tick": 1, "due": ["every_tick"]}
    scheduler.commit(first)
    second = scheduler.plan_next()
    assert second == {"tick": 2, "due": ["every_tick", "every_two"]}
    altered = {"tick": second["tick"], "due": ["every_tick"]}
    with pytest.raises(ValueError):
        scheduler.commit(altered)
    scheduler.commit(second)
    assert scheduler.tick == 2


def test_engine_checkpoint_includes_scheduler_tick():
    from hbse.simulation.engine import SimulationEngine
    engine = SimulationEngine(neuron_count=16, seed=15)
    engine.run(3, {"novelty": 0.7})
    restored = SimulationEngine.from_state_dict(engine.state_dict())
    assert restored.scheduler.tick == restored.tick == 3
    assert restored.step({"novelty": 0.2})["event"]["tick"] == 4
