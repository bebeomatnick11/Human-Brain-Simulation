import pytest
from hbse.simulation.engine import SimulationEngine


def test_engine_advances_and_updates_subsystems():
    engine = SimulationEngine(neuron_count=16, seed=4)
    result = engine.run(5, {"novelty": 0.8, "reward": 0.2})
    assert engine.tick == 5
    assert result["status"]["network"]["steps"] == 5
    assert result["status"]["world_model"]["observations"] == 5
    assert result["results"][-1]["event"]["tick"] == 5


def test_input_bounds_and_feature_names():
    engine = SimulationEngine()
    with pytest.raises(ValueError):
        engine.step({"novelty": 2})
    with pytest.raises(ValueError):
        engine.step({"unknown": 0.3})

def test_checkpoint_round_trip_preserves_state_and_future():
    engine = SimulationEngine(neuron_count=16, seed=9)
    engine.run(4, {"novelty": 0.7, "reward": 0.1})
    snapshot = engine.state_dict()
    restored = SimulationEngine.from_state_dict(snapshot)
    assert restored.tick == engine.tick
    assert restored.status()["network"] == engine.status()["network"]
    a = engine.step({"threat": 0.2})
    b = restored.step({"threat": 0.2})
    assert a["event"] == b["event"]
    assert a["learning"] == b["learning"]

def test_consolidation_is_labeled_as_heuristic():
    engine = SimulationEngine()
    for _ in range(4):
        engine.step({"novelty": 0.8})
    result = engine.consolidate()
    assert result["model"].startswith("bounded_heuristic")


def test_first_nonzero_observation_produces_prediction_error():
    engine = SimulationEngine(neuron_count=16, seed=3)
    result = engine.step({"novelty": 0.8})
    assert result["event"]["prediction_error"] > 0
