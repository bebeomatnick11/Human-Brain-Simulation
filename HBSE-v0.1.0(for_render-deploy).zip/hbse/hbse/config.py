"""Runtime configuration with bounded resource defaults."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _int_env(name: str, default: int, lower: int, upper: int) -> int:
    raw = os.getenv(name)
    try:
        value = int(raw) if raw is not None else default
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc
    if not lower <= value <= upper:
        raise ValueError(f"{name} must be between {lower} and {upper}")
    return value


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True, slots=True)
class Settings:
    neuron_count: int = 32
    random_seed: int = 42
    max_ticks_per_request: int = 1000
    api_token: str | None = None
    data_dir: Path = Path("data")
    state_file: Path = Path("data/hbse_state.json")
    autosave: bool = False

    @classmethod
    def from_env(cls) -> "Settings":
        data_dir = Path(os.getenv("HBSE_DATA_DIR", "data"))
        state_file = Path(os.getenv("HBSE_STATE_FILE", str(data_dir / "hbse_state.json")))
        token = os.getenv("HBSE_API_TOKEN", "").strip() or None
        return cls(
            neuron_count=_int_env("HBSE_NEURON_COUNT", 32, 8, 512),
            random_seed=_int_env("HBSE_RANDOM_SEED", 42, 0, 2**31 - 1),
            max_ticks_per_request=_int_env("HBSE_MAX_TICKS_PER_REQUEST", 1000, 1, 10000),
            api_token=token,
            data_dir=data_dir,
            state_file=state_file,
            autosave=_bool_env("HBSE_AUTOSAVE", False),
        )
