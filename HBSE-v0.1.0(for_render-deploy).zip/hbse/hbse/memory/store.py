"""Bounded working and episodic memory with provenance-aware retrieval."""
from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, asdict
from typing import Any


@dataclass(slots=True)
class MemoryTrace:
    id: int
    tick: int
    content: str
    tags: list[str]
    importance: float
    confidence: float
    provenance: str = "simulated_observation"
    retrieval_count: int = 0


class MemoryStore:
    """Small bounded memory store; retrieval is lexical/tag-based, not semantic understanding."""
    MAX_WORKING_CAPACITY = 256
    MAX_EPISODIC_CAPACITY = 10000

    def __init__(self, working_capacity: int = 16, episodic_capacity: int = 500) -> None:
        if not 1 <= working_capacity <= self.MAX_WORKING_CAPACITY:
            raise ValueError(f"working_capacity must be between 1 and {self.MAX_WORKING_CAPACITY}")
        if not 1 <= episodic_capacity <= self.MAX_EPISODIC_CAPACITY:
            raise ValueError(f"episodic_capacity must be between 1 and {self.MAX_EPISODIC_CAPACITY}")
        self.working_capacity = working_capacity
        self.episodic_capacity = episodic_capacity
        self.working: deque[dict[str, Any]] = deque(maxlen=working_capacity)
        self.episodes: list[MemoryTrace] = []
        self.semantic_counts: Counter[str] = Counter()
        self.next_id = 1
        self.dropped_episodes = 0

    def observe(self, tick: int, features: dict[str, float], attention: str, importance: float) -> None:
        item = {"tick": int(tick), "features": dict(features), "attention": attention, "importance": float(importance)}
        self.working.append(item)
        tags = [key for key, value in features.items() if abs(float(value)) >= 0.15]
        tags.extend([attention, "actionable"] if importance >= 0.5 else ["background"] )
        self.semantic_counts.update(tags)
        # Encode an episode only when the event is informative; avoid storing every tick by default.
        if importance >= 0.35:
            self.encode(
                tick=tick,
                content=f"tick={tick}; attention={attention}; salient_features={','.join(tags)}",
                tags=sorted(set(tags)), importance=importance, confidence=max(0.05, 1.0 - min(1.0, importance * 0.25)),
            )

    def encode(self, tick: int, content: str, tags: list[str], importance: float, confidence: float = 0.8, provenance: str = "simulated_observation") -> MemoryTrace | None:
        trace = MemoryTrace(
            id=self.next_id, tick=int(tick), content=str(content)[:2000],
            tags=sorted(set(str(tag)[:80] for tag in tags))[:64],
            importance=max(0.0, min(1.0, float(importance))),
            confidence=max(0.0, min(1.0, float(confidence))), provenance=str(provenance)[:80],
        )
        self.next_id += 1
        # Preserve previously stored episodic records by default. Once capacity is
        # reached, reject new records and count them instead of silently overwriting history.
        if len(self.episodes) >= self.episodic_capacity:
            self.dropped_episodes += 1
            return None
        self.episodes.append(trace)
        return trace

    def recall(self, query_tags: list[str] | None = None, limit: int = 5) -> list[dict[str, Any]]:
        if limit < 1 or limit > 100:
            raise ValueError("limit must be between 1 and 100")
        query = set(query_tags or [])
        scored: list[tuple[float, MemoryTrace]] = []
        newest_tick = self.episodes[-1].tick if self.episodes else 0
        for trace in self.episodes:
            overlap = len(query.intersection(trace.tags)) / max(1, len(query)) if query else 0.0
            recency = 1.0 / (1.0 + max(0, newest_tick - trace.tick) * 0.02)
            score = 0.65 * overlap + 0.20 * trace.importance + 0.10 * trace.confidence + 0.05 * recency
            scored.append((score, trace))
        scored.sort(key=lambda pair: (pair[0], pair[1].tick, pair[1].id), reverse=True)
        result = []
        for score, trace in scored[:limit]:
            trace.retrieval_count += 1
            row = asdict(trace)
            row["retrieval_score"] = round(float(score), 6)
            result.append(row)
        return result

    def state_dict(self) -> dict[str, Any]:
        return {
            "working_capacity": self.working_capacity, "episodic_capacity": self.episodic_capacity,
            "working": list(self.working), "episodes": [asdict(item) for item in self.episodes],
            "semantic_counts": dict(self.semantic_counts), "next_id": self.next_id,
            "dropped_episodes": self.dropped_episodes, "overflow_policy": "preserve_existing",
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        wc, ec = int(state["working_capacity"]), int(state["episodic_capacity"])
        if not 1 <= wc <= self.MAX_WORKING_CAPACITY or not 1 <= ec <= self.MAX_EPISODIC_CAPACITY or len(state["episodes"]) > ec or len(state["working"]) > wc:
            raise ValueError("Invalid memory capacities in checkpoint")
        episodes = [MemoryTrace(**item) for item in state["episodes"]]
        ids = [item.id for item in episodes]
        for item in episodes:
            if item.id < 1 or item.tick < 0 or not 0 <= item.importance <= 1 or not 0 <= item.confidence <= 1 or item.retrieval_count < 0:
                raise ValueError("Invalid episodic-memory record")
            if len(item.content) > 2000 or len(item.tags) > 64 or any(not isinstance(tag, str) or len(tag) > 80 for tag in item.tags):
                raise ValueError("Episodic-memory record exceeds schema limits")
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate episodic-memory IDs")
        working = list(state["working"])
        for item in working:
            if int(item["tick"]) < 0 or not isinstance(item["features"], dict):
                raise ValueError("Invalid working-memory record")
            if any(not (-1.0 <= float(v) <= 1.0) for v in item["features"].values()):
                raise ValueError("Working-memory feature is out of bounds")
        counts = {str(k): int(v) for k, v in state["semantic_counts"].items()}
        if any(v < 0 for v in counts.values()):
            raise ValueError("Invalid semantic-memory count")
        next_id = int(state["next_id"])
        if next_id <= max(ids, default=0):
            raise ValueError("Invalid next memory ID")
        self.working_capacity, self.episodic_capacity = wc, ec
        self.working = deque(working, maxlen=wc)
        self.episodes = episodes
        self.semantic_counts = Counter(counts)
        self.next_id = next_id
        if state.get("overflow_policy", "preserve_existing") != "preserve_existing":
            raise ValueError("Unsupported episodic-memory overflow policy")
        self.dropped_episodes = int(state.get("dropped_episodes", 0))
        if self.dropped_episodes < 0:
            raise ValueError("Invalid dropped-episode counter")
        if self.next_id <= max((item.id for item in self.episodes), default=0):
            raise ValueError("Invalid next memory ID")
