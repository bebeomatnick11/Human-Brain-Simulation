"""Human Brain Simulation Engine: staged, testable computational models."""
__version__ = "0.1.0"
