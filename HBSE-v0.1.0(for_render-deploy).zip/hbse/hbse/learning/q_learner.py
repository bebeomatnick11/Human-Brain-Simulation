"""Bounded tabular Q-learning over a deliberately small discretized context space."""
from __future__ import annotations

from typing import Any
import numpy as np

ACTIONS = ("rest", "explore", "learn", "maintain")
GOALS = {"maintain_resources", "reduce_uncertainty", "learn_environment"}


class QLearner:
    """Q(s,a) table with epsilon-greedy choice and bounded updates.

    The context is discretized into low/high energy, threat and uncertainty bins plus
    the active goal. This is an interpretable prototype, not a human decision model.
    """
    def __init__(self, seed: int = 42, alpha: float = 0.15, gamma: float = 0.90, epsilon: float = 0.08) -> None:
        if not (0 < alpha <= 1 and 0 <= gamma <= 1 and 0 <= epsilon <= 1):
            raise ValueError("Invalid Q-learning hyperparameters")
        self.alpha, self.gamma, self.epsilon = float(alpha), float(gamma), float(epsilon)
        self.q: dict[str, dict[str, float]] = {}
        self.rng = np.random.default_rng(seed + 1)
        self.updates = 0
        self.last_action: str | None = None
        self.last_state: str | None = None

    @staticmethod
    def state_key(context: dict[str, Any]) -> str:
        energy = float(context.get("energy", 1.0))
        threat = float(context.get("threat", 0.0))
        uncertainty = float(context.get("uncertainty", context.get("prediction_error", 0.0)))
        goal = str(context.get("goal", "reduce_uncertainty"))
        if goal not in GOALS:
            goal = "reduce_uncertainty"
        return "|".join((
            goal,
            "energy_low" if energy < 0.35 else "energy_ok",
            "threat_high" if threat >= 0.5 else "threat_low",
            "uncertainty_high" if uncertainty >= 0.35 else "uncertainty_low",
        ))

    def _values(self, state: str) -> dict[str, float]:
        return self.q.setdefault(state, {action: 0.0 for action in ACTIONS})

    def choose(self, context: dict[str, Any]) -> str:
        state = self.state_key(context)
        values = self._values(state)
        scores = dict(values)
        scores["rest"] += max(0.0, 0.35 - float(context.get("energy", 1.0))) * 2.0
        scores["explore"] += 0.55 * max(float(context.get("novelty", 0.0)), float(context.get("uncertainty", 0.0)))
        scores["learn"] += 0.45 * max(0.0, float(context.get("prediction_error", 0.0))) + 0.2 * max(0.0, float(context.get("reward", 0.0)))
        scores["maintain"] += 0.8 * max(0.0, float(context.get("threat", 0.0))) + 0.35 * max(0.0, float(context.get("stress", 0.0)))
        goal = str(context.get("goal", "reduce_uncertainty"))
        if goal == "maintain_resources":
            scores["rest"] += 0.35
        elif goal == "reduce_uncertainty":
            scores["explore"] += 0.15
            scores["learn"] += 0.15
        elif goal == "learn_environment":
            scores["explore"] += 0.25
            scores["learn"] += 0.25
        if self.rng.random() < self.epsilon:
            chosen = ACTIONS[int(self.rng.integers(0, len(ACTIONS)))]
        else:
            chosen = max(ACTIONS, key=lambda action: (scores[action], action))
        self.last_state, self.last_action = state, chosen
        return chosen

    def update(self, action: str, reward: float, next_context: dict[str, Any] | None = None) -> float:
        if action not in ACTIONS:
            raise ValueError(f"Unknown action: {action}")
        state = self.last_state or self.state_key({})
        current_values = self._values(state)
        reward = float(np.clip(reward, -2.0, 2.0))
        if next_context is None:
            bootstrap = 0.0
        else:
            next_state = self.state_key(next_context)
            bootstrap = max(self._values(next_state).values())
        target = reward + self.gamma * bootstrap
        current_values[action] = float(np.clip(current_values[action] + self.alpha * (target - current_values[action]), -5.0, 5.0))
        self.updates += 1
        return current_values[action]

    def state_dict(self) -> dict[str, Any]:
        return {
            "alpha": self.alpha, "gamma": self.gamma, "epsilon": self.epsilon,
            "q": self.q, "updates": self.updates, "last_action": self.last_action,
            "last_state": self.last_state, "rng_state": self.rng.bit_generator.state,
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        raw_q = state["q"]
        if not isinstance(raw_q, dict):
            raise ValueError("Invalid Q table in checkpoint")
        q: dict[str, dict[str, float]] = {}
        if len(raw_q) > 64:
            raise ValueError("Q table exceeds the supported state count")
        for state_key, row in raw_q.items():
            if not isinstance(row, dict) or set(row) != set(ACTIONS):
                raise ValueError("Invalid action row in Q table")
            values = {str(action): float(value) for action, value in row.items()}
            if any(not np.isfinite(value) or abs(value) > 5 for value in values.values()):
                raise ValueError("Q table contains an out-of-bounds value")
            q[str(state_key)] = values
        self.alpha, self.gamma, self.epsilon = float(state["alpha"]), float(state["gamma"]), float(state["epsilon"])
        if not (0 < self.alpha <= 1 and 0 <= self.gamma <= 1 and 0 <= self.epsilon <= 1):
            raise ValueError("Invalid learner hyperparameters")
        self.q, self.updates = q, int(state["updates"])
        self.last_action, self.last_state = state["last_action"], state.get("last_state")
        if self.last_action is not None and self.last_action not in ACTIONS:
            raise ValueError("Invalid previous action")
        if self.last_state is not None and self.last_state not in self.q:
            raise ValueError("Last state missing from Q table")
        self.rng.bit_generator.state = state["rng_state"]
