"""Incremental predictive model over engineered scalar features."""
from __future__ import annotations

from typing import Any


class WorldModel:
    """EMA predictor. Prediction error is feature-level surprise, not a full causal model."""
    def __init__(self, alpha: float = 0.15) -> None:
        if not 0.0 < alpha <= 1.0:
            raise ValueError("alpha must be in (0, 1]")
        self.alpha = float(alpha)
        self.expected: dict[str, float] = {}
        self.last_observation: dict[str, float] = {}
        self.observations = 0
        self.last_prediction_error = 0.0

    def observe(self, features: dict[str, float]) -> dict[str, Any]:
        if not features:
            features = {}
        # The initial prior is zero for all features. This makes the first non-zero
        # observation informative rather than falsely assigning it zero prediction error.
        keys = sorted(set(features) | set(self.expected))
        error = (sum(abs(float(features.get(k, 0.0)) - self.expected.get(k, 0.0)) for k in keys) / len(keys)) if keys else 0.0
        for key in keys:
            observed = float(features.get(key, 0.0))
            previous = self.expected.get(key, 0.0)
            self.expected[key] = (1.0 - self.alpha) * previous + self.alpha * observed
        self.last_observation = dict(features)
        self.observations += 1
        self.last_prediction_error = float(error)
        return {"prediction_error": self.last_prediction_error, "expected": dict(self.expected), "observations": self.observations}

    def state_dict(self) -> dict[str, Any]:
        return {"alpha": self.alpha, "expected": self.expected, "last_observation": self.last_observation, "observations": self.observations, "last_prediction_error": self.last_prediction_error}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        alpha = float(state["alpha"])
        if not 0 < alpha <= 1:
            raise ValueError("Invalid world-model alpha")
        expected = {str(k): float(v) for k, v in state["expected"].items()}
        last_observation = {str(k): float(v) for k, v in state["last_observation"].items()}
        observations = int(state["observations"])
        error = float(state["last_prediction_error"])
        if any(not (-1.0 <= value <= 1.0) for value in expected.values()):
            raise ValueError("World-model prediction is out of bounds")
        if any(not (-1.0 <= value <= 1.0) for value in last_observation.values()):
            raise ValueError("World-model observation is out of bounds")
        if observations < 0 or not 0.0 <= error <= 2.0:
            raise ValueError("Invalid world-model observation count or prediction error")
        self.alpha = alpha
        self.expected = expected
        self.last_observation = last_observation
        self.observations = observations
        self.last_prediction_error = error
