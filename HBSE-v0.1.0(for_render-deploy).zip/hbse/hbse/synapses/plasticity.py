"""Bounded co-activity plasticity used by the coarse rate-network tier."""
from __future__ import annotations

import numpy as np


def bounded_hebbian_update(
    weights: np.ndarray, rates: np.ndarray, connectivity: np.ndarray,
    learning_rate: float, max_weight: float = 0.5, decay: float = 0.0001,
) -> np.ndarray:
    """Update present synapses from centered co-activity; absent edges remain absent."""
    if weights.ndim != 2 or weights.shape[0] != weights.shape[1]:
        raise ValueError("weights must be square")
    if rates.shape != (weights.shape[0],) or connectivity.shape != weights.shape:
        raise ValueError("incompatible plasticity array shapes")
    centered = rates - float(np.mean(rates))
    delta = learning_rate * np.outer(centered, centered)
    updated = np.clip(weights + delta - decay * weights, 0.0, max_weight)
    updated *= connectivity
    return updated
