from .plasticity import bounded_hebbian_update
__all__ = ["bounded_hebbian_update"]
