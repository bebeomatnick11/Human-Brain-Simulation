"""Deterministic salience selector for the feature-level simulation."""
from __future__ import annotations

WEIGHTS = {"threat": 1.5, "novelty": 1.25, "surprise": 1.2, "reward": 0.8, "social": 0.7, "intensity": 0.7, "effort": 0.4, "goal_relevance": 1.0}


class AttentionSelector:
    def score(self, features: dict[str, float]) -> dict[str, float]:
        return {key: abs(float(value)) * WEIGHTS.get(key, 0.5) for key, value in features.items()}

    def select(self, features: dict[str, float]) -> tuple[str, float]:
        scores = self.score(features)
        if not scores or max(scores.values(), default=0.0) < 1e-9:
            return "internal_state", 0.0
        key = max(scores, key=lambda item: (scores[item], item))
        return key, float(scores[key])
