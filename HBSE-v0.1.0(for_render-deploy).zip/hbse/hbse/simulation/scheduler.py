"""Deterministic, checkpointable discrete-step scheduler for module update cadence."""
from __future__ import annotations

from typing import Any


class SimulationScheduler:
    """Plans module updates before a tick and commits only after the engine step completes.

    A task with period 1 runs every tick. For period N and phase 0, it runs at ticks
    N, 2N, ...; nonzero phases provide deterministic staggering. Callbacks are kept out
    of the scheduler so the ordering is explicit, serializable and easy to test.
    """
    def __init__(self) -> None:
        self.tick = 0
        self.tasks: dict[str, dict[str, int]] = {}

    def register(self, name: str, every_n_ticks: int = 1, phase: int = 0) -> None:
        name = str(name).strip()
        if not name or len(name) > 80:
            raise ValueError("Task name must contain 1..80 characters")
        if name in self.tasks:
            raise ValueError(f"Task already registered: {name}")
        if len(self.tasks) >= 256:
            raise ValueError("Scheduler task count exceeds 256")
        if every_n_ticks < 1 or not 0 <= phase < every_n_ticks:
            raise ValueError("Invalid task period or phase")
        self.tasks[name] = {"every_n_ticks": int(every_n_ticks), "phase": int(phase)}

    def plan_next(self) -> dict[str, Any]:
        next_tick = self.tick + 1
        due = [
            name for name, spec in self.tasks.items()
            if next_tick % spec["every_n_ticks"] == spec["phase"]
        ]
        return {"tick": next_tick, "due": due}

    def commit(self, frame: dict[str, Any]) -> None:
        expected = self.plan_next()
        if frame != expected:
            raise ValueError("Scheduler frame is stale or has been modified")
        self.tick = int(frame["tick"])

    def status(self) -> dict[str, Any]:
        return {
            "tick": self.tick,
            "task_count": len(self.tasks),
            "tasks": {name: dict(spec) for name, spec in self.tasks.items()},
        }

    def state_dict(self) -> dict[str, Any]:
        return {"tick": self.tick, "tasks": {name: dict(spec) for name, spec in self.tasks.items()}}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        tick = int(state["tick"])
        tasks = {
            str(name): {"every_n_ticks": int(spec["every_n_ticks"]), "phase": int(spec["phase"])}
            for name, spec in state["tasks"].items()
        }
        if tick < 0 or len(tasks) > 256 or tasks != self.tasks:
            raise ValueError("Checkpoint scheduler schema does not match configured tasks")
        for name, spec in tasks.items():
            period, phase = spec["every_n_ticks"], spec["phase"]
            if not name or period < 1 or not 0 <= phase < period:
                raise ValueError("Invalid scheduler task definition")
        self.tick = tick
