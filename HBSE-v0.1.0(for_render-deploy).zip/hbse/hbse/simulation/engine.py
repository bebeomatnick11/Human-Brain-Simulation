"""Deterministic, step-based HBSE core integrating the implemented Tier 1/2 subsystems."""
from __future__ import annotations

import math
import time
from typing import Any

from hbse.attention.selector import AttentionSelector
from hbse.cognition.world_model import WorldModel
from hbse.core.types import SimulationEvent
from hbse.global_workspace.workspace import GlobalWorkspace
from hbse.learning.q_learner import QLearner
from hbse.memory.store import MemoryStore
from hbse.motivation.goals import GoalManager
from hbse.neural.rate_network import FEATURES, RateNetwork
from hbse.virtual_body.model import VirtualBody
from hbse.simulation.scheduler import SimulationScheduler

ALLOWED_FEATURES = set(FEATURES) - {"surprise", "goal_relevance"}


class SimulationEngine:
    schema_version = "hbse-state-v1"

    def __init__(self, neuron_count: int = 32, seed: int = 42) -> None:
        self.seed = seed
        self.tick = 0
        self.created_at_monotonic = time.monotonic()
        self.scheduler = SimulationScheduler()
        self.core_tasks = ("world_model", "attention", "goals", "decision", "neural", "body", "memory", "workspace")
        for task in self.core_tasks:
            self.scheduler.register(task, every_n_ticks=1)
        self.network = RateNetwork(neuron_count, seed=seed)
        self.memory = MemoryStore()
        self.world_model = WorldModel()
        self.attention = AttentionSelector()
        self.goals = GoalManager()
        self.learner = QLearner(seed=seed)
        self.body = VirtualBody()
        self.workspace = GlobalWorkspace()
        self.events: list[SimulationEvent] = []
        self.last_event: SimulationEvent | None = None
        self.last_metrics: dict[str, Any] = {}

    @staticmethod
    def validate_stimulus(stimulus: dict[str, float] | None) -> dict[str, float]:
        stimulus = stimulus or {}
        if not isinstance(stimulus, dict):
            raise ValueError("stimulus must be an object of feature values")
        unknown = set(stimulus) - ALLOWED_FEATURES
        if unknown:
            raise ValueError(f"Unknown stimulus features: {sorted(unknown)}")
        clean: dict[str, float] = {}
        for key, raw in stimulus.items():
            try:
                value = float(raw)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Feature '{key}' must be numeric") from exc
            if not math.isfinite(value) or not -1.0 <= value <= 1.0:
                raise ValueError(f"Feature '{key}' must be finite and in [-1, 1]")
            clean[key] = value
        return clean

    def step(self, stimulus: dict[str, float] | None = None) -> dict[str, Any]:
        features = self.validate_stimulus(stimulus)
        frame = self.scheduler.plan_next()
        due = set(frame["due"])
        missing = set(self.core_tasks) - due
        if missing:
            raise RuntimeError(f"Required core task(s) not scheduled this tick: {sorted(missing)}")
        next_tick = int(frame["tick"])
        world = self.world_model.observe(features)
        prediction_error = float(world["prediction_error"])
        enriched = dict(features)
        enriched["surprise"] = min(1.0, prediction_error)
        enriched["goal_relevance"] = max(0.0, min(1.0, prediction_error * 0.5 + abs(features.get("reward", 0.0)) * 0.3))
        attention, salience = self.attention.select(enriched)
        goal = self.goals.update(self.body.energy, prediction_error, max(0.0, features.get("novelty", 0.0)))
        action = self.learner.choose({
            "energy": self.body.energy, "novelty": max(0.0, features.get("novelty", 0.0)),
            "uncertainty": prediction_error, "prediction_error": prediction_error,
            "reward": features.get("reward", 0.0), "threat": max(0.0, features.get("threat", 0.0)),
            "stress": self.body.stress, "goal": goal,
        })
        neural_input = {key: float(enriched.get(key, 0.0)) for key in FEATURES}
        network_metrics = self.network.step(neural_input)

        reward_signal = (features.get("reward", 0.0) - 0.35 * max(0.0, features.get("threat", 0.0))
                         - 0.15 * max(0.0, features.get("effort", 0.0)))
        if action == "explore":
            reward_signal += 0.10 * max(0.0, features.get("novelty", 0.0))
        elif action == "learn":
            reward_signal += 0.08 * prediction_error
        elif action == "rest":
            reward_signal += 0.10 * (1.0 - self.body.energy)
        self.body.update(action, max(0.0, features.get("threat", 0.0)), max(0.0, features.get("effort", 0.0)), reward_signal)
        next_context = {
            "energy": self.body.energy, "novelty": max(0.0, features.get("novelty", 0.0)),
            "uncertainty": prediction_error, "prediction_error": prediction_error,
            "reward": features.get("reward", 0.0), "threat": max(0.0, features.get("threat", 0.0)),
            "stress": self.body.stress, "goal": goal,
        }
        self.learner.update(action, reward_signal, next_context)
        importance = min(1.0, max(salience / 1.5, prediction_error, abs(reward_signal) * 0.7))
        self.memory.observe(next_tick, features, attention, importance)
        self.workspace.publish(next_tick, attention, goal, action, prediction_error, confidence=1.0 / (1.0 + prediction_error))
        event = SimulationEvent(
            tick=next_tick, features=features, attention=attention, action=action,
            prediction_error=prediction_error, reward=float(reward_signal),
            network_activity=float(network_metrics["mean_activity"]),
        )
        self.scheduler.commit(frame)
        self.tick = next_tick
        # Keep only a small recent diagnostic window; episodic memory stores salient events.
        self.events.append(event)
        if len(self.events) > 100:
            self.events.pop(0)
        self.last_metrics = network_metrics
        return {
            "event": event.to_dict(), "current_goal": goal, "goal_priorities": {k: v["priority"] for k, v in self.goals.goals.items()},
            "body": self.body.state_dict(), "learning": {"q_values": {key: dict(value) for key, value in self.learner.q.items()}, "updates": self.learner.updates},
            "network": network_metrics, "memory": {"working_items": len(self.memory.working), "episodic_items": len(self.memory.episodes)},
        }

    def run(self, ticks: int = 1, stimulus: dict[str, float] | None = None) -> dict[str, Any]:
        if not 1 <= ticks <= 10000:
            raise ValueError("ticks must be between 1 and 10000")
        clean = self.validate_stimulus(stimulus)
        results = [self.step(clean) for _ in range(ticks)]
        return {"ticks_requested": ticks, "tick": self.tick, "results": results, "status": self.status()}

    def consolidate(self) -> dict[str, Any]:
        """Offline memory-consolidation analogue; not a model of biological sleep/REM."""
        before = len(self.memory.episodes)
        # Promote frequently observed feature labels as compact semantic summaries.
        promoted = 0
        for tag, count in self.memory.semantic_counts.most_common(8):
            if count >= 3 and not any(item.content == f"semantic_summary:{tag}" for item in self.memory.episodes):
                trace = self.memory.encode(self.tick, f"semantic_summary:{tag}", [tag, "consolidated"], importance=min(1.0, count / 10), confidence=0.55, provenance="computed_consolidation")
                if trace is not None:
                    promoted += 1
        self.body.fatigue = max(0.0, self.body.fatigue - 0.05)
        return {"tick": self.tick, "episodes_before": before, "episodes_after": len(self.memory.episodes), "semantic_summaries_added": promoted, "model": "bounded_heuristic_consolidation_not_biological_sleep"}

    def status(self) -> dict[str, Any]:
        return {
            "engine": "HBSE", "version": "0.1.0", "schema_version": self.schema_version, "tick": self.tick,
            "scope": "Tier 1/2 computational abstraction; not a whole-brain replica",
            "subsystems": {
                "rate_network": "implemented", "working_memory": "implemented", "episodic_memory": "implemented",
                "feature_world_model": "implemented", "salience_attention": "implemented", "goal_prioritization": "implemented",
                "tabular_reinforcement_learning": "implemented", "virtual_body_state": "implemented",
                "global_workspace_broadcast": "implemented", "molecular_dynamics": "not_implemented",
                "spiking_neurons": "not_implemented", "language_perception": "not_implemented",
                "subjective_consciousness": "not_testable_by_this_engine",
            },
            "network": self.network.metrics(), "body": self.body.state_dict(),
            "goals": self.goals.state_dict(), "scheduler": self.scheduler.status(), "memory": {"working_items": len(self.memory.working), "episodic_items": len(self.memory.episodes), "episodic_capacity": self.memory.episodic_capacity, "dropped_episodes": self.memory.dropped_episodes},
            "world_model": {"observations": self.world_model.observations, "last_prediction_error": self.world_model.last_prediction_error, "expected_features": self.world_model.expected},
            "workspace": self.workspace.last_broadcast, "last_event": self.last_event.to_dict() if self.last_event else None,
        }

    def state_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version, "seed": self.seed, "tick": self.tick,
            "network": self.network.state_dict(), "memory": self.memory.state_dict(),
            "scheduler": self.scheduler.state_dict(),
            "world_model": self.world_model.state_dict(), "goals": self.goals.state_dict(),
            "learner": self.learner.state_dict(), "body": self.body.state_dict(),
            "workspace": self.workspace.state_dict(),
            "events": [event.to_dict() for event in self.events],
            "last_event": self.last_event.to_dict() if self.last_event else None,
        }

    @classmethod
    def from_state_dict(cls, state: dict[str, Any]) -> "SimulationEngine":
        if state.get("schema_version") != cls.schema_version:
            raise ValueError("Unsupported checkpoint schema version")
        network_state = state["network"]
        engine = cls(neuron_count=int(network_state["n"]), seed=int(state["seed"]))
        engine.network.load_state_dict(network_state)
        engine.memory.load_state_dict(state["memory"])
        engine.world_model.load_state_dict(state["world_model"])
        engine.goals.load_state_dict(state["goals"])
        engine.learner.load_state_dict(state["learner"])
        engine.body.load_state_dict(state["body"])
        engine.workspace.load_state_dict(state["workspace"])
        engine.scheduler.load_state_dict(state["scheduler"])
        engine.tick = int(state["tick"])
        if engine.tick < 0 or engine.tick != engine.scheduler.tick:
            raise ValueError("Invalid simulation tick or scheduler tick mismatch")
        def event_from_dict(item: dict[str, Any]) -> SimulationEvent:
            return SimulationEvent(**item)
        engine.events = [event_from_dict(item) for item in state.get("events", [])][-100:]
        last = state.get("last_event")
        engine.last_event = event_from_dict(last) if last else None
        engine.last_metrics = engine.network.metrics()
        return engine
