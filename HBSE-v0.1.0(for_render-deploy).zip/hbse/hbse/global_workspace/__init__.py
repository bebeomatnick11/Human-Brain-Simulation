from .workspace import GlobalWorkspace
__all__ = ["GlobalWorkspace"]
