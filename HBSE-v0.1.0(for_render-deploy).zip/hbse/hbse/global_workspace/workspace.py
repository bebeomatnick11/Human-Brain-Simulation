"""Shared, bounded broadcast workspace for computational state summaries."""
from __future__ import annotations
from typing import Any
from collections import deque


class GlobalWorkspace:
    def __init__(self, capacity: int = 32) -> None:
        self.broadcasts: deque[dict[str, Any]] = deque(maxlen=capacity)
        self.last_broadcast: dict[str, Any] | None = None

    def publish(self, tick: int, attention: str, goal: str, action: str, prediction_error: float, confidence: float) -> None:
        item = {"tick": tick, "attention": attention, "goal": goal, "action": action, "prediction_error": prediction_error, "confidence": max(0.0, min(1.0, confidence)), "provenance": "computed_summary"}
        self.broadcasts.append(item)
        self.last_broadcast = item

    def state_dict(self) -> dict[str, Any]:
        return {"capacity": self.broadcasts.maxlen, "broadcasts": list(self.broadcasts), "last_broadcast": self.last_broadcast}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        capacity = int(state["capacity"])
        if not 1 <= capacity <= 1024 or len(state["broadcasts"]) > capacity:
            raise ValueError("Invalid global-workspace checkpoint")
        self.broadcasts = deque(state["broadcasts"], maxlen=capacity)
        self.last_broadcast = state["last_broadcast"]
