"""Bounded goal-priority model; goals cannot grant tools or external permissions."""
from __future__ import annotations

from typing import Any


class GoalManager:
    def __init__(self) -> None:
        self.goals: dict[str, dict[str, float | str]] = {
            "maintain_resources": {"priority": 0.65, "progress": 0.0, "status": "active"},
            "reduce_uncertainty": {"priority": 0.55, "progress": 0.0, "status": "active"},
            "learn_environment": {"priority": 0.45, "progress": 0.0, "status": "active"},
        }
        self.current_goal = "reduce_uncertainty"

    def update(self, energy: float, prediction_error: float, novelty: float) -> str:
        self.goals["maintain_resources"]["priority"] = max(0.05, min(1.0, 1.0 - energy))
        self.goals["reduce_uncertainty"]["priority"] = max(0.05, min(1.0, 0.25 + prediction_error))
        self.goals["learn_environment"]["priority"] = max(0.05, min(1.0, 0.25 + max(0.0, novelty) * 0.75))
        self.current_goal = max(self.goals, key=lambda name: (float(self.goals[name]["priority"]), name))
        self.goals[self.current_goal]["progress"] = min(1.0, float(self.goals[self.current_goal]["progress"]) + 0.01)
        return self.current_goal

    def state_dict(self) -> dict[str, Any]:
        return {"goals": self.goals, "current_goal": self.current_goal}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        goals = state["goals"]
        if set(goals) != set(self.goals):
            raise ValueError("Checkpoint goal set does not match schema")
        for name, item in goals.items():
            priority, progress = float(item["priority"]), float(item["progress"])
            if not 0 <= priority <= 1 or not 0 <= progress <= 1:
                raise ValueError("Invalid goal priority/progress")
        self.goals = {k: {"priority": float(v["priority"]), "progress": float(v["progress"]), "status": str(v["status"])} for k, v in goals.items()}
        if state["current_goal"] not in self.goals:
            raise ValueError("Invalid current goal")
        self.current_goal = str(state["current_goal"])
