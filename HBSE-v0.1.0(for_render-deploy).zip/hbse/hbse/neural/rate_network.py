"""Small recurrent rate network for Tier 1/2 experiments. Not a cortical replica."""
from __future__ import annotations

import math
from typing import Any

import numpy as np

from hbse.synapses.plasticity import bounded_hebbian_update

FEATURES = ("novelty", "threat", "reward", "social", "effort", "intensity", "surprise", "goal_relevance")


class RateNetwork:
    """Recurrent rate-based network with fixed E/I source signs and bounded plasticity.

    Rates are normalized activity values in [0, 1]. Synaptic magnitudes are nonnegative;
    inhibitory source neurons contribute with a negative sign. This coarse abstraction omits
    membrane conductances, spikes, cell diversity, dendrites and detailed receptor dynamics.
    """

    def __init__(self, n: int = 32, seed: int = 42, learning_rate: float = 0.002) -> None:
        if n < 8 or n > 512:
            raise ValueError("n must be between 8 and 512")
        self.n = n
        self.seed = seed
        self.learning_rate = float(learning_rate)
        self.rng = np.random.default_rng(seed)
        self.rates = np.full(n, 0.25, dtype=np.float64)
        self.inhibitory = np.zeros(n, dtype=np.float64)
        self.inhibitory[int(n * 0.8):] = 1.0
        self.source_sign = 1.0 - 2.0 * self.inhibitory
        mask = self.rng.random((n, n)) < 0.12
        np.fill_diagonal(mask, False)
        self.connectivity = mask.astype(np.float64)
        self.weights = self.rng.uniform(0.0, 0.12, size=(n, n)) * self.connectivity
        self.threshold = 0.35
        self.gain = 3.0
        self.dt = 0.02
        self.tau = 0.10
        self.steps = 0

    @staticmethod
    def _sigmoid(x: np.ndarray) -> np.ndarray:
        x = np.clip(x, -30.0, 30.0)
        return 1.0 / (1.0 + np.exp(-x))

    def step(self, external: dict[str, float] | None = None, plasticity: bool = True) -> dict[str, float]:
        external = external or {}
        unknown = set(external) - set(FEATURES)
        if unknown:
            raise ValueError(f"Unknown neural input features: {sorted(unknown)}")
        vector = np.zeros(self.n, dtype=np.float64)
        for i, feature in enumerate(FEATURES):
            value = float(external.get(feature, 0.0))
            if not math.isfinite(value) or not -1.0 <= value <= 1.0:
                raise ValueError(f"Input '{feature}' must be finite and in [-1, 1]")
            vector[i % self.n] += value
        centered_rates = self.rates - 0.25
        recurrent = (self.weights * self.source_sign[np.newaxis, :]) @ centered_rates
        drive = recurrent + vector - self.threshold
        target = self._sigmoid(self.gain * drive)
        self.rates += (self.dt / self.tau) * (target - self.rates)
        np.clip(self.rates, 0.0, 1.0, out=self.rates)
        if plasticity:
            self.weights = bounded_hebbian_update(
                self.weights, self.rates, self.connectivity, self.learning_rate,
            )
        self.steps += 1
        return self.metrics()

    def metrics(self) -> dict[str, float | int]:
        return {
            "neuron_count": self.n,
            "synapse_count": int(np.count_nonzero(self.connectivity)),
            "steps": self.steps,
            "mean_activity": float(np.mean(self.rates)),
            "activity_std": float(np.std(self.rates)),
            "max_weight": float(np.max(self.weights)) if self.weights.size else 0.0,
            "finite_state": bool(np.isfinite(self.rates).all() and np.isfinite(self.weights).all()),
        }

    def state_dict(self) -> dict[str, Any]:
        return {
            "n": self.n, "seed": self.seed, "learning_rate": self.learning_rate,
            "rates": self.rates.tolist(), "inhibitory": self.inhibitory.tolist(),
            "connectivity": self.connectivity.astype(int).tolist(),
            "weights": self.weights.tolist(), "threshold": self.threshold,
            "gain": self.gain, "dt": self.dt, "tau": self.tau, "steps": self.steps,
            "rng_state": self.rng.bit_generator.state,
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if int(state.get("n", -1)) != self.n:
            raise ValueError(f"Checkpoint neuron count does not match configured network ({self.n})")
        rates = np.asarray(state["rates"], dtype=np.float64)
        weights = np.asarray(state["weights"], dtype=np.float64)
        connectivity = np.asarray(state["connectivity"], dtype=np.float64)
        inhibitory = np.asarray(state["inhibitory"], dtype=np.float64)
        if rates.shape != (self.n,) or weights.shape != (self.n, self.n):
            raise ValueError("Invalid checkpoint array shape")
        if connectivity.shape != weights.shape or inhibitory.shape != rates.shape:
            raise ValueError("Invalid checkpoint connectivity or inhibitory shape")
        if not (np.isfinite(rates).all() and np.isfinite(weights).all() and np.isfinite(connectivity).all() and np.isfinite(inhibitory).all()):
            raise ValueError("Checkpoint contains non-finite network values")
        if np.any(rates < 0) or np.any(rates > 1) or np.any(weights < 0) or np.any(weights > 0.5):
            raise ValueError("Checkpoint contains values outside permitted bounds")
        if np.any((connectivity != 0) & (connectivity != 1)) or np.any((inhibitory != 0) & (inhibitory != 1)):
            raise ValueError("Connectivity and inhibitory markers must be binary")
        if np.any(np.diag(connectivity) != 0) or np.any(weights[connectivity == 0] != 0):
            raise ValueError("Checkpoint contains invalid absent/autaptic connections")
        learning_rate = float(state["learning_rate"])
        threshold, gain = float(state["threshold"]), float(state["gain"])
        dt, tau, steps = float(state["dt"]), float(state["tau"]), int(state["steps"])
        if not (math.isfinite(learning_rate) and 0 <= learning_rate <= 0.1):
            raise ValueError("Invalid plasticity learning rate")
        if not (math.isfinite(threshold) and math.isfinite(gain) and gain > 0):
            raise ValueError("Invalid network activation parameters")
        if not (math.isfinite(dt) and math.isfinite(tau) and 0 < dt <= tau and steps >= 0):
            raise ValueError("Invalid network timing or step count")
        self.seed = int(state["seed"])
        self.learning_rate = learning_rate
        self.rates = rates.copy()
        self.inhibitory = inhibitory.copy()
        self.source_sign = 1.0 - 2.0 * self.inhibitory
        self.connectivity = connectivity.copy()
        self.weights = weights.copy() * self.connectivity
        self.threshold = threshold
        self.gain = gain
        self.dt = dt
        self.tau = tau
        self.steps = steps
        self.rng.bit_generator.state = state["rng_state"]
