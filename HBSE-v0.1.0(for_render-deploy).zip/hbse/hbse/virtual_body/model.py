"""Computational body-state variables. These are not biological measurements."""
from __future__ import annotations
from typing import Any


class VirtualBody:
    def __init__(self) -> None:
        self.energy = 0.85
        self.fatigue = 0.10
        self.stress = 0.10
        self.arousal = 0.20
        self.interoceptive = {"energy_deficit": 0.15, "fatigue": 0.10, "stress": 0.10}
        self.updates = 0

    def update(self, action: str, threat: float, effort: float, reward: float) -> None:
        costs = {"rest": -0.12, "explore": 0.035, "learn": 0.025, "maintain": 0.015}
        self.energy = max(0.0, min(1.0, self.energy - costs.get(action, 0.02) - 0.025 * max(effort, 0.0) + 0.015 * max(reward, 0.0)))
        self.fatigue = max(0.0, min(1.0, self.fatigue + 0.012 * max(effort, 0.0) + 0.006 - (0.07 if action == "rest" else 0.0)))
        self.stress = max(0.0, min(1.0, 0.88 * self.stress + 0.18 * max(0.0, threat)))
        target_arousal = max(0.0, min(1.0, 0.25 + 0.6 * max(0.0, threat) + 0.2 * max(0.0, effort)))
        self.arousal = max(0.0, min(1.0, 0.8 * self.arousal + 0.2 * target_arousal))
        self.interoceptive = {"energy_deficit": 1.0 - self.energy, "fatigue": self.fatigue, "stress": self.stress}
        self.updates += 1

    def state_dict(self) -> dict[str, Any]:
        return {"energy": self.energy, "fatigue": self.fatigue, "stress": self.stress, "arousal": self.arousal, "interoceptive": self.interoceptive, "updates": self.updates}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        for key in ("energy", "fatigue", "stress", "arousal"):
            value = float(state[key])
            if not 0 <= value <= 1:
                raise ValueError(f"Invalid virtual-body variable {key}")
            setattr(self, key, value)
        self.interoceptive = {str(k): float(v) for k, v in state["interoceptive"].items()}
        if any(not 0 <= value <= 1 for value in self.interoceptive.values()):
            raise ValueError("Invalid interoceptive values")
        self.updates = int(state["updates"])
