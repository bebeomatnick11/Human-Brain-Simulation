from .model import VirtualBody
__all__ = ["VirtualBody"]
