"""Public API request and response schemas."""
from __future__ import annotations
from pydantic import BaseModel, ConfigDict, Field, field_validator
from typing import Any
import math


class SimulateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ticks: int = Field(default=1, ge=1, le=10000)
    stimulus: dict[str, float] = Field(default_factory=dict)

    @field_validator("stimulus")
    @classmethod
    def valid_values(cls, value: dict[str, float]) -> dict[str, float]:
        allowed = {"novelty", "threat", "reward", "social", "effort", "intensity"}
        unknown = set(value) - allowed
        if unknown:
            raise ValueError(f"Unknown stimulus features: {sorted(unknown)}")
        for key, number in value.items():
            if not math.isfinite(number) or not -1 <= number <= 1:
                raise ValueError(f"Feature '{key}' must be finite and in [-1, 1]")
        return value


class RestoreRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema_version: str
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    state: dict[str, Any]
    saved_to: str | None = None
