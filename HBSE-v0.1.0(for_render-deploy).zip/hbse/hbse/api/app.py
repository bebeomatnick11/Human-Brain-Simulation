"""FastAPI surface for the HBSE simulation engine."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

from hbse import __version__
from hbse.api.schemas import RestoreRequest, SimulateRequest
from hbse.config import Settings
from hbse.security.guards import authorize_mutation
from hbse.simulation.engine import SimulationEngine

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("hbse")
settings = Settings.from_env()
engine = SimulationEngine(neuron_count=settings.neuron_count, seed=settings.random_seed)
state_lock = threading.RLock()
app = FastAPI(
    title="Human Brain Simulation Engine (HBSE)", version=__version__,
    description=("A testable Tier 1/2 computational simulation. It is not a whole-brain reconstruction "
                 "and makes no claim of subjective consciousness."),
    docs_url="/docs", redoc_url="/redoc",
)


def _checkpoint_checksum(state: dict[str, Any]) -> str:
    encoded = json.dumps(state, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _save_checkpoint(state: dict[str, Any]) -> None:
    path = settings.state_file
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    payload = {"schema_version": SimulationEngine.schema_version, "sha256": _checkpoint_checksum(state), "state": state}
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


@app.exception_handler(ValueError)
async def value_error_handler(_request: Request, exc: ValueError) -> JSONResponse:
    return JSONResponse(status_code=422, content={"detail": str(exc)})


@app.get("/", tags=["service"])
def root() -> dict[str, Any]:
    return {"name": "Human Brain Simulation Engine", "version": __version__, "health": "/health", "api_docs": "/docs", "scope": "computational abstraction, not a whole-brain replica"}


@app.get("/health", tags=["service"])
def health() -> dict[str, str]:
    return {"status": "ok", "service": "hbse", "version": __version__}


@app.get("/v1/status", tags=["simulation"])
def get_status() -> dict[str, Any]:
    with state_lock:
        return engine.status()


@app.post("/v1/simulate", tags=["simulation"])
def simulate(request: SimulateRequest, http_request: Request) -> dict[str, Any]:
    authorize_mutation(http_request, settings)
    if request.ticks > settings.max_ticks_per_request:
        raise HTTPException(status_code=422, detail=f"ticks exceeds configured limit ({settings.max_ticks_per_request})")
    with state_lock:
        result = engine.run(request.ticks, request.stimulus)
        if settings.autosave:
            try:
                _save_checkpoint(engine.state_dict())
            except OSError:
                logger.exception("Autosave failed")
                raise HTTPException(status_code=500, detail="Simulation advanced, but checkpoint autosave failed")
        return result


@app.post("/v1/checkpoint", tags=["state management"])
def checkpoint(http_request: Request) -> dict[str, Any]:
    authorize_mutation(http_request, settings)
    with state_lock:
        state = engine.state_dict()
        checksum = _checkpoint_checksum(state)
        try:
            _save_checkpoint(state)
        except OSError as exc:
            logger.exception("Checkpoint write failed")
            raise HTTPException(status_code=500, detail="Could not write checkpoint to configured state file") from exc
        return {"schema_version": SimulationEngine.schema_version, "sha256": checksum, "state": state, "saved_to": str(settings.state_file)}


@app.post("/v1/restore", tags=["state management"])
def restore(payload: RestoreRequest, http_request: Request) -> dict[str, Any]:
    global engine
    authorize_mutation(http_request, settings)
    if payload.schema_version != SimulationEngine.schema_version:
        raise HTTPException(status_code=422, detail="Unsupported checkpoint schema version")
    if _checkpoint_checksum(payload.state) != payload.sha256:
        raise HTTPException(status_code=400, detail="Checkpoint checksum mismatch")
    try:
        candidate = SimulationEngine.from_state_dict(payload.state)
        if candidate.network.n > 512:
            raise ValueError("Checkpoint exceeds maximum supported neuron count (512)")
    except (KeyError, TypeError, ValueError, IndexError) as exc:
        raise HTTPException(status_code=422, detail=f"Invalid checkpoint: {exc}") from exc
    with state_lock:
        engine = candidate
        if settings.autosave:
            try:
                _save_checkpoint(engine.state_dict())
            except OSError:
                logger.exception("Restored state but could not autosave checkpoint")
                raise HTTPException(status_code=500, detail="State restored in memory but autosave failed")
        return {"status": "restored", "tick": engine.tick, "network": engine.network.metrics()}


@app.get("/v1/checkpoint", tags=["state management"])
def read_checkpoint(http_request: Request) -> dict[str, Any]:
    """Return the last explicit disk checkpoint; this is not necessarily the current live state."""
    authorize_mutation(http_request, settings)
    path = settings.state_file
    if not path.exists():
        raise HTTPException(status_code=404, detail="No saved checkpoint exists yet; POST /v1/checkpoint first")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=500, detail="Saved checkpoint is unreadable") from exc
    if _checkpoint_checksum(payload.get("state", {})) != payload.get("sha256"):
        raise HTTPException(status_code=500, detail="Saved checkpoint failed integrity verification")
    return payload


@app.post("/v1/consolidate", tags=["simulation"])
def consolidate(http_request: Request) -> dict[str, Any]:
    authorize_mutation(http_request, settings)
    with state_lock:
        return engine.consolidate()


@app.get("/v1/memory/recall", tags=["memory"])
def recall_memory(http_request: Request, tags: str = "", limit: int = 5) -> dict[str, Any]:
    # Memory contents and retrieval counters are stateful; protect this endpoint in deployment.
    authorize_mutation(http_request, settings)
    if not 1 <= limit <= 100:
        raise HTTPException(status_code=422, detail="limit must be between 1 and 100")
    query_tags = [tag.strip() for tag in tags.split(",") if tag.strip()][:64]
    with state_lock:
        return {"query_tags": query_tags, "items": engine.memory.recall(query_tags, limit)}
