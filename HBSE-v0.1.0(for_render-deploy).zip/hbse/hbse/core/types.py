"""Shared value types. These are computational abstractions, not biological diagnoses."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class SimulationEvent:
    tick: int
    features: dict[str, float]
    attention: str
    action: str
    prediction_error: float
    reward: float
    network_activity: float
    provenance: str = "simulated_observation"

    def to_dict(self) -> dict[str, Any]:
        return {
            "tick": self.tick, "features": dict(self.features), "attention": self.attention,
            "action": self.action, "prediction_error": self.prediction_error,
            "reward": self.reward, "network_activity": self.network_activity,
            "provenance": self.provenance,
        }
