"""Mutation access control for public deployments."""
from __future__ import annotations
import hmac
import os
from fastapi import HTTPException, Request
from hbse.config import Settings


def authorize_mutation(request: Request, settings: Settings) -> None:
    supplied = request.headers.get("authorization", "")
    if settings.api_token:
        expected = f"Bearer {settings.api_token}"
        if not hmac.compare_digest(supplied.encode("utf-8"), expected.encode("utf-8")):
            raise HTTPException(status_code=401, detail="A valid Bearer token is required for state-changing operations")
    elif os.getenv("RENDER") or os.getenv("RENDER_SERVICE_ID"):
        raise HTTPException(status_code=503, detail="Set HBSE_API_TOKEN in the deployment environment before using state-changing endpoints")
