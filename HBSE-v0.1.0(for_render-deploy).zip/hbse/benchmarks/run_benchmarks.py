"""Run reproducible microbenchmarks; measurements are generated locally, not hard-coded."""
from __future__ import annotations
import json
import platform
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from hbse.memory.store import MemoryStore
from hbse.neural.rate_network import RateNetwork
from hbse.simulation.engine import SimulationEngine


def benchmark() -> dict:
    net = RateNetwork(n=128, seed=7)
    start = time.perf_counter()
    for _ in range(2000):
        net.step({"novelty": 0.3, "threat": 0.1, "reward": 0.2})
    network_seconds = time.perf_counter() - start

    memory = MemoryStore(working_capacity=32, episodic_capacity=1000)
    for i in range(1000):
        memory.encode(i, f"synthetic episode {i}", [f"group_{i % 10}", "synthetic"], 0.5)
    start = time.perf_counter()
    for _ in range(200):
        memory.recall(["group_3", "synthetic"], 5)
    recall_seconds = time.perf_counter() - start

    engine = SimulationEngine(neuron_count=32, seed=7)
    start = time.perf_counter()
    for i in range(500):
        engine.step({"novelty": (i % 5) / 5, "reward": 0.1, "threat": 0.0})
    end_to_end_seconds = time.perf_counter() - start
    return {
        "environment": {"python": sys.version, "platform": platform.platform()},
        "method": "single-run microbenchmark; not a scientific validation or cross-machine comparison",
        "rate_network": {"neurons": 128, "steps": 2000, "elapsed_seconds": network_seconds, "steps_per_second": 2000 / max(network_seconds, 1e-12), "metrics": net.metrics()},
        "memory_recall": {"episodes": 1000, "queries": 200, "top_k": 5, "elapsed_seconds": recall_seconds, "queries_per_second": 200 / max(recall_seconds, 1e-12)},
        "end_to_end": {"neurons": 32, "simulation_ticks": 500, "elapsed_seconds": end_to_end_seconds, "ticks_per_second": 500 / max(end_to_end_seconds, 1e-12), "final_tick": engine.tick},
    }

if __name__ == "__main__":
    result = benchmark()
    print(json.dumps(result, indent=2))
    out = ROOT / "benchmark-results.local.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"\nSaved local measurements to {out}")
