# HBSE staged implementation and evidence ledger

## Stage 1: architecture (delivered in v0.1.0)
- Language/runtime: Python + NumPy + FastAPI.
- Stable subsystem boundaries and serializable state dictionaries.
- Step-driven scheduler and explicit provenance labels.
- Resource bounds and deployment mutation guard.
- Science/evidence boundaries documented.

## Stage 2: executable core (delivered in v0.1.0)
- Small recurrent rate network with bounded co-activity plasticity.
- Feature-level world predictor; prediction error.
- Salience/attention selection.
- Working-memory ring buffer and bounded episodic traces.
- Goal-priority updates, Q-learning and virtual body state.
- Global workspace summaries.
- Checkpoint/restore schema plus SHA-256 integrity check.
- FastAPI status/simulation/memory/consolidation/checkpoint endpoints.
- Tests and machine-local microbenchmarks.

## Stage 3: cognitive and affective systems (not yet implemented)
Acceptance gates: typed appraisal model; distinguish acute response from mood; state transition tests; stable bounded dynamics; memory and policy effects measured separately; no claims of subjective feeling. Build personality, social inference and decision modules only with explicit model assumptions and separate tests.

## Stage 4: biological detail (not yet implemented)
Add leaky-integrate-and-fire units, refractory state, synaptic conductance/time constants and plasticity rules as replaceable network implementations. Validate on small published canonical tasks before scaling. Region names alone are not evidence of anatomical fidelity.

## Stage 5: validation (initial harness delivered; scientific benchmark suite pending)
Every experiment should store config, seed, software version, dataset provenance, baseline, metric definitions, actual outputs and uncertainty. Keep performance benchmarking distinct from cognitive validity. Never report an unrun experiment as a result.

## Stage 6: expansion (conditional)
Scale only after profiling. Consider sparse connectivity, batch simulation and GPU acceleration if measurements show a bottleneck. Use durable state storage for deployments. A model's unit count is not a measure of whole-brain fidelity.
