# Human Brain Simulation Engine (HBSE)

**Version:** 0.1.0 — Stage 1 architecture + Stage 2 executable core.

HBSE is an experimental, modular computational neuroscience platform. This release integrates a small recurrent rate network, feature-level predictive model, salience selector, bounded working/episodic memory, goal-priority model, discretized-state tabular Q learner, virtual body-state variables, and a bounded global workspace. It is intended as an extensible research codebase—not as a whole-brain reconstruction.

## 1. Scientific scope and evidence labels

| Component | Implemented approximation | Important limit |
|---|---|---|
| Neural dynamics | Recurrent rate units, excitatory/inhibitory source signs, bounded Hebbian co-activity update | Not spiking neurons; no membrane conductance, dendrites, cell types, detailed synapses, or validated anatomical connectivity |
| Prediction | Exponential moving-average feature predictor and absolute prediction error | Not a complete generative/causal world model |
| Attention | Salience-weighted feature selection | Hand-designed priority weights; not a validated human attention model |
| Memory | Bounded working buffer, tagged episodic traces, lexical/tag recall and provenance | Not human memory fidelity; no embeddings or validated systems consolidation |
| Learning | Bounded Q(s,a) table over discretized energy/threat/uncertainty and goal context | A small tabular RL demonstration; not an account of all human learning |
| Goals/body | Heuristic priorities and dynamic normalized resource/stress variables | Virtual variables, not human biological needs or physiological measurements |
| Workspace | Bounded shared summary broadcasts | Functional information-sharing mechanism, not evidence of subjective consciousness |
| Consolidation | Rule-based semantic-summary promotion | Not biological sleep or REM simulation |

**Implemented now:** Tier 1/2 computational abstractions with real mutable state, deterministic seeding, a discrete-step simulation loop, validation, checkpoint integrity checks, an API, a local benchmark harness and automated tests.

**Not implemented in v0.1.0:** molecular dynamics; action potentials/spiking neurons; region-specific validated circuit models; auditory/visual encoders; natural-language understanding; full emotion/appraisal system; Theory of Mind; procedural and spatial memory systems; sleep-stage physiology; motor control; detailed neurotransmitter/receptor models. `subjective_consciousness` is not something this system can establish with a software metric.

The feature weights, thresholds and learning constants are engineering defaults, not fitted human data. Treat outputs as simulation results under stated assumptions, not clinical or neuroscientific measurements.

## 2. Architecture

```text
HTTP API (FastAPI)
    ├── request validation / mutation guard
    └── SimulationEngine (discrete scheduler; one atomic step per tick)
          ├── WorldModel -> prediction error
          ├── AttentionSelector -> selected feature
          ├── GoalManager -> active goal and priorities
          ├── QLearner -> action selection / reward update
          ├── RateNetwork -> recurrent activity + bounded plasticity
          ├── VirtualBody -> energy/fatigue/stress/arousal state
          ├── MemoryStore -> working buffer + episodic traces
          └── GlobalWorkspace -> bounded computed-summary broadcast
```

### Source tree

```text
.
├── main.py                      # Uvicorn ASGI entry point
├── render.yaml                  # Render Blueprint, free web-service profile
├── .github/workflows/tests.yml  # GitHub Actions tests
├── requirements.txt             # Runtime dependencies
├── requirements-dev.txt         # Test and development dependencies
├── pytest.ini
├── VALIDATION_REPORT.md
├── HBSE-benchmark-run.json      # Actual local microbenchmark output
├── hbse/
│   ├── config.py                # Environment-backed bounds/configuration
│   ├── api/                     # FastAPI endpoints and Pydantic schemas
│   ├── core/                    # Shared event/value types
│   ├── neural/                  # RateNetwork implementation
│   ├── synapses/                # Bounded Hebbian update
│   ├── cognition/               # Feature-level predictive world model
│   ├── attention/               # Salience selector
│   ├── memory/                  # Working + episodic memory and recall
│   ├── motivation/              # Goal prioritization
│   ├── learning/                # Tabular Q learner
│   ├── virtual_body/            # Dynamic virtual-state variables
│   ├── global_workspace/        # Bounded information broadcast
│   ├── simulation/              # Engine integration + explicit scheduler + checkpoints
│   └── security/                # Public-deployment mutation guard
├── benchmarks/run_benchmarks.py # Machine-local reproducible microbenchmarks
└── tests/                       # Unit and API integration tests
```

Deferred modules (emotion, social cognition, personality, imagination, motor control, detailed brain regions, perception adapters, visualization, production data adapters) are intentionally not represented as empty classes. They should be added once the implemented core has baseline measurements and each subsystem has a testable contract.

## 3. Local setup

Python 3.11+ is recommended locally; the Render Blueprint pins Python 3.13.5.

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
# Runtime-only dependencies: pip install -r requirements.txt
cp .env.example .env  # optional; export variables manually or use a dotenv tool
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs`. No paid model API key is required. `.env` is not auto-loaded by Uvicorn; set environment variables in your shell/IDE.

### API examples

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/v1/status
curl -X POST http://127.0.0.1:8000/v1/simulate \
  -H 'Content-Type: application/json' \
  -d '{"ticks": 5, "stimulus": {"novelty": 0.8, "reward": 0.2}}'
curl 'http://127.0.0.1:8000/v1/memory/recall?tags=novelty&limit=5'
# On Render, add: -H 'Authorization: Bearer $HBSE_API_TOKEN' to all POST requests
# and to /v1/checkpoint and /v1/memory/recall GET requests.
```

API routes:

| Method | Route | Purpose |
|---|---|---|
| GET | `/health` | Health check for Render |
| GET | `/v1/status` | Current subsystem and resource state |
| POST | `/v1/simulate` | Advance 1..configured max ticks |
| GET | `/v1/memory/recall` | Recall bounded episodic traces by tags (token-protected on Render) |
| POST | `/v1/consolidate` | Run explicitly labeled heuristic consolidation |
| POST | `/v1/checkpoint` | Save and return a checksummed state envelope |
| GET | `/v1/checkpoint` | Read/verify last saved checkpoint (token-protected) |
| POST | `/v1/restore` | Validate checksum/schema then restore state |

Stimulus keys accepted by the public simulation API: `novelty`, `threat`, `reward`, `social`, `effort`, `intensity`. Every value must be finite and in `[-1, 1]`. All simulation actions are internal; no shell, network tool, file-writing agent, or external actuator is attached.

## Hardware and resource estimate

The service is CPU-only and needs no GPU or paid model API. For the default 32-unit configuration, a 64-bit Python environment with about 1 vCPU and 512 MiB RAM is a reasonable **starting estimate**, not a validated minimum or production capacity guarantee. The 512-neuron setting is a hard upper bound for this dense-matrix prototype, not a recommended Render Free setting: compute and checkpoint size grow quadratically with neuron count. Use the bundled benchmark on the actual deployment plan before increasing `HBSE_NEURON_COUNT` or request tick limits. The Blueprint selects the `free` service plan; availability, platform limits, and any future charges are governed by Render's current account/service terms.

## 4. Tests and benchmarks

```bash
pytest -q
python benchmarks/run_benchmarks.py
```

The benchmark script measures current machine performance and writes `benchmark-results.local.json`. Runtime figures vary by CPU, Python/NumPy build and load; they are not hard-coded into this README and are not scientific validation. Baselines should be saved per machine/software version before optimizations are claimed.

Detailed test and environment-specific performance results are in [`VALIDATION_REPORT.md`](VALIDATION_REPORT.md); the captured benchmark output is included as `HBSE-benchmark-run.json`. Rerunning the benchmark emits `benchmark-results.local.json`, which is excluded from normal Git commits.

## 5. GitHub -> Render deployment

1. Create a GitHub repository and push this project (commands below).
2. In Render, choose **New + → Blueprint** and select the repository; Render reads `render.yaml`. Alternatively create a Python Web Service with build command `pip install -r requirements.txt` and start command `uvicorn main:app --host 0.0.0.0 --port $PORT`.
3. Set `HBSE_API_TOKEN` to a long random secret in Render's environment. The Blueprint declares it as a non-synchronized secret. State-changing endpoints require `Authorization: Bearer <token>` in a Render environment. Do not commit the token.
4. The health-check path is `/health`; interactive API docs are at `/docs`.
5. Push commits to the connected branch to trigger configured auto-deploy behavior.

### Push from a local clone

```bash
git init
git add .
git commit -m "Build HBSE v0.1.0 computational simulation core"
git branch -M main
git remote add origin https://github.com/<YOUR-ACCOUNT>/<YOUR-REPOSITORY>.git
git push -u origin main
```

### Persistence caveat

The checkpoint is written atomically to `HBSE_STATE_FILE` (default `data/hbse_state.json`). A Render service without a persistent disk must be treated as ephemeral: local files may be lost when the instance is replaced or redeployed. For durable production state, attach a persistent disk where supported or implement a database/object-storage adapter with credentials managed as secrets. A checkpoint restore accepts a state object plus SHA-256 digest; never accept checkpoint JSON from an untrusted source without reviewing its provenance.

The API starts in local development without a token; when running on Render, mutation routes fail closed if `HBSE_API_TOKEN` has not been configured. Status/health endpoints remain readable. Set a token locally too if the service is exposed to an untrusted network.

## 6. Resource safety and limitations

- Network size is bounded to 8..512 neurons; default is 32. Dense matrix storage is O(N²), so do not raise the limit blindly.
- Request ticks are bounded; the Render setting defaults to at most 1000 per request.
- Memory and the recent event diagnostic window are bounded. Working memory is a rolling buffer; episodic capacity preserves stored records when full and increments `dropped_episodes` rather than silently overwriting old episodes. Export/checkpoint and archive before increasing workload beyond the bounded store.
- Checkpoints include neural and RNG state to support reproducible continuation for the implemented components.
- This API is a research prototype, not hardened multi-tenant infrastructure. Add rate limiting, identity-aware authorization, durable storage and deployment observability before public production use.
- No result should be described as matching human-brain fidelity without an appropriate reference dataset, prespecified metric, baseline, uncertainty analysis and independent replication.

## 7. Next phases

1. **v0.2 — measurement first:** baseline tasks, performance/memory profiling, versioned experiment config and JSONL event logs.
2. **v0.3 — memory/learning:** associative retrieval, confidence calibration, continual-learning regression tests, memory provenance/conflict handling.
3. **v0.4 — affect and decision:** appraisal vector, mood time constants, goals, risk-sensitive policy; each component separately validated.
4. **v0.5 — neuroscience tiers:** configurable leaky-integrate-and-fire neurons and conductance/synapse models behind a common network interface.
5. **v0.6+ — region/network coupling:** regional models backed by explicitly cited datasets and a reproducible parameter-fitting process.

Implementation order is conditional on benchmarks; no phase should silently replace the existing core. Preserve checkpoint/schema migrations and regression tests.
