# HBSE — Human Brain Simulation Engine

HBSE 0.1.0 is an executable, reproducible computational-neuroscience prototype. It is **not** a reconstruction of a human brain and does not claim consciousness or subjective emotion.

## Implemented in this first runnable core
- Vectorized Izhikevich-style spiking neurons with explicit reset and refractory behavior.
- Sparse weighted synapses, excitatory/inhibitory signs, delayed spike queues, bounded activity-dependent plasticity.
- A deterministic simulation scheduler with explicit phases.
- Working memory, source/provenance labels, confidence, retrieval by token overlap and decay.
- A simple world model using prediction error.
- Goal scoring and a tiny discrete environment for end-to-end interaction.
- JSON snapshot persistence with RNG state, event log, config and state version.
- Unit tests and a runnable CLI demo.

## Scientific status
The Izhikevich model is a reduced dynamical model that can reproduce several firing patterns, not a molecularly complete neuron. Network wiring here is generated synthetic connectivity, not a measured human connectome. Cognitive modules are computational analogues, not evidence of human-like cognition or subjective experience.

## Requirements
Python 3.10+ and NumPy 1.24+. For tests, install `pytest`.

## Run
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS:
source .venv/bin/activate
python -m pip install -e ".[dev]"
hbse --steps 200 --seed 7
pytest
```

If the `hbse` command is not on PATH, run:
```bash
PYTHONPATH=src python -m hbse.cli --steps 200 --seed 7
```

## Project layout
- `neural/`: spiking neuron dynamics
- `synapses/`: sparse network and plasticity
- `brain_regions/`: coarse functional-region metadata and routing
- `perception/`: validated input encoding
- `cognition/`: world-state prediction
- `attention/`: bounded salience selection
- `memory/`: working memory with provenance
- `emotion/`: appraisal-state dynamics (computational proxy)
- `motivation/`: goals and resource pressure
- `personality/`: stable trait parameters
- `social_cognition/`: explicit belief-attribution records
- `learning/`: prediction-error updates
- `sleep/`: offline replay/consolidation operation
- `virtual_body/`: simulated energy/fatigue/arousal
- `self_model/`: capabilities and uncertainty reporting
- `global_workspace/`: competition for limited broadcast slots
- `imagination/`: labeled counterfactual rollouts
- `decision/`: action scoring
- `motor_control/`: action-to-environment adapter
- `environment/`: toy benchmark environment
- `data/`: runtime snapshots/logs (created by user)
- `simulation/`: scheduler and engine
- `visualization/`: text metrics output
- `benchmarks/`: small reproducible benchmark
- `tests/`: automated tests
- `security/`: resource/input bounds
- `api/`: stable public exports
- `config/`: simulation defaults

This is a real initial implementation, but not all listed future-facing packages contain full biological models yet. Modules marked by `status.py` report their maturity rather than pretending all mechanisms are complete.
