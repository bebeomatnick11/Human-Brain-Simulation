class ToyEnvironment:
    """A deterministic scalar prediction task for smoke tests, not a human environment."""
    def __init__(self, target=0.75):
        self.target = float(target)
        self.state = 0.0

    def observe(self):
        return {"state": self.state, "target": self.target}

    def act(self, action):
        if action == "increase": self.state = min(1.0, self.state + 0.1)
        elif action == "decrease": self.state = max(0.0, self.state - 0.1)
        elif action != "wait": raise ValueError("unknown action")
        reward = 1.0 - abs(self.target - self.state)
        return {"state": self.state, "reward": reward}
