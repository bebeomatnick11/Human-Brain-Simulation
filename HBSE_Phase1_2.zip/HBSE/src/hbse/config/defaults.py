from dataclasses import dataclass

@dataclass(frozen=True)
class SimulationConfig:
    seed: int = 7
    neuron_count: int = 128
    connection_probability: float = 0.04
    dt_ms: float = 1.0
    refractory_steps: int = 2
    memory_capacity: int = 64
    max_input: float = 20.0
    max_steps_per_call: int = 100_000

    def validate(self):
        if self.neuron_count < 2 or self.neuron_count > 100_000:
            raise ValueError("neuron_count must be in [2, 100000]")
        if not 0.0 <= self.connection_probability <= 1.0:
            raise ValueError("connection_probability must be in [0, 1]")
        if not 0.01 <= self.dt_ms <= 10.0:
            raise ValueError("dt_ms must be in [0.01, 10]")
        if self.memory_capacity < 1:
            raise ValueError("memory_capacity must be positive")
        if self.max_steps_per_call < 1:
            raise ValueError("max_steps_per_call must be positive")
