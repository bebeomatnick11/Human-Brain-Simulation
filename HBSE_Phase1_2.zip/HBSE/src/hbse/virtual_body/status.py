class VirtualBody:
    def __init__(self):
        self.energy = 1.0
        self.fatigue = 0.0
        self.arousal = 0.1

    def update(self, compute_load=0.0, rest=0.0, dt=1.0):
        load = max(0.0, min(1.0, float(compute_load)))
        rest = max(0.0, min(1.0, float(rest)))
        dt = max(0.0, float(dt))
        self.energy = max(0.0, min(1.0, self.energy + dt * (0.03*rest - 0.02*load)))
        self.fatigue = max(0.0, min(1.0, self.fatigue + dt * (0.02*load - 0.03*rest)))
        self.arousal = max(0.0, min(1.0, 0.9*self.arousal + 0.1*load))
        return {"energy": self.energy, "fatigue": self.fatigue, "arousal": self.arousal}
