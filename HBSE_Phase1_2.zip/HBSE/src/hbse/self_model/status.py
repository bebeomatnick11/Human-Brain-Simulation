def report(engine):
    status = engine.status()
    status["known_limits"] = ["synthetic connectivity", "coarse cognitive proxies",
                              "no claim of subjective experience", "no human connectome"]
    status["uncertainty"] = "module maturity varies; see README"
    return status
