class PredictionErrorLearner:
    def __init__(self, rate=0.05):
        if not 0 < rate <= 1: raise ValueError("rate must be in (0,1]")
        self.rate = float(rate)
        self.values = {}

    def update(self, state, action, reward, next_state, discount=0.95):
        key = (str(state), str(action))
        target = float(reward) + float(discount) * max(
            (v for (s, _), v in self.values.items() if s == str(next_state)), default=0.0)
        old = self.values.get(key, 0.0)
        error = target - old
        self.values[key] = old + self.rate * error
        return {"old_value": old, "target": target, "td_error": error, "new_value": self.values[key]}
