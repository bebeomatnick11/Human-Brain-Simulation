from time import perf_counter
from hbse.simulation.engine import HBSEngine
from hbse.config.defaults import SimulationConfig

def run_benchmark(neurons=128, steps=1000, seed=7):
    engine = HBSEngine(SimulationConfig(seed=seed, neuron_count=neurons))
    start = perf_counter()
    engine.run(steps)
    elapsed = perf_counter() - start
    return {"neurons": neurons, "synapses": len(engine.network.weights), "steps": steps,
            "elapsed_seconds": elapsed, "steps_per_second": steps / elapsed if elapsed else float("inf"),
            "seed": seed, "note": "Measured on the machine running this function; not a biological-fidelity metric."}
