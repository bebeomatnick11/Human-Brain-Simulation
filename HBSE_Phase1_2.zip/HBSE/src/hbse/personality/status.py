"""Stable computational tendencies; not a complete model of human personality."""
from dataclasses import dataclass

@dataclass
class PersonalityTraits:
    openness: float = 0.6
    conscientiousness: float = 0.6
    extraversion: float = 0.5
    agreeableness: float = 0.6
    stress_sensitivity: float = 0.4

    def validate(self):
        for name, value in vars(self).items():
            if not 0 <= value <= 1: raise ValueError(f"{name} must be in [0,1]")
