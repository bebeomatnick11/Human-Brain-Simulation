import argparse
import json
from hbse.config.defaults import SimulationConfig
from hbse.simulation.engine import HBSEngine

def main():
    parser = argparse.ArgumentParser(description="Run the HBSE computational brain prototype")
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--neurons", type=int, default=128)
    parser.add_argument("--save", default=None)
    args = parser.parse_args()
    engine = HBSEngine(SimulationConfig(seed=args.seed, neuron_count=args.neurons))
    engine.observe("environment_reward", 0.2, source="demo", confidence=0.9)
    engine.observe("environment_reward", 0.8, source="demo", confidence=0.9)
    events = engine.run(args.steps)
    print(json.dumps({"status": engine.status(),
                      "last_events": events[-5:],
                      "memory_retrieval": engine.memory.retrieve("environment_reward", 3)}, indent=2))
    if args.save:
        engine.save(args.save)
        print(f"snapshot_saved={args.save}")

if __name__ == "__main__":
    main()
