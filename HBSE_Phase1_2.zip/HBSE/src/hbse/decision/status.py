def choose_action(actions, risk_weight=0.25):
    if not actions: raise ValueError("actions cannot be empty")
    return max(actions, key=lambda a: float(a.get("expected_value", 0)) -
               float(risk_weight)*float(a.get("risk", 0)))
