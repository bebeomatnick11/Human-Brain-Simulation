def select_salient(items, budget=4):
    """Select highest salience while preserving original objects and provenance."""
    if budget < 0: raise ValueError("budget must be non-negative")
    return sorted(items, key=lambda x: float(x.get("salience", 0.0)), reverse=True)[:budget]
