from .network import SparseSynapticNetwork
__all__ = ["SparseSynapticNetwork"]
