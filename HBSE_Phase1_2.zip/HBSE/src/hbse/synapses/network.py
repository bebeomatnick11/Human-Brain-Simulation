"""Sparse directed synapses with delayed delivery and bounded Hebbian updates."""
from collections import deque
import numpy as np

class SparseSynapticNetwork:
    def __init__(self, size, pre, post, weights, delays, excitatory):
        self.size = int(size)
        self.pre = np.asarray(pre, dtype=np.int32)
        self.post = np.asarray(post, dtype=np.int32)
        self.weights = np.asarray(weights, dtype=np.float64)
        self.delays = np.asarray(delays, dtype=np.int32)
        self.excitatory = np.asarray(excitatory, dtype=bool)
        n = len(self.pre)
        if not (len(self.post) == len(self.weights) == len(self.delays) == len(self.excitatory) == n):
            raise ValueError("synapse arrays must have equal lengths")
        if np.any(self.pre < 0) or np.any(self.pre >= size) or np.any(self.post < 0) or np.any(self.post >= size):
            raise ValueError("synapse index out of range")
        if np.any(self.delays < 1) or np.any(~np.isfinite(self.weights)):
            raise ValueError("delays must be >= 1 and weights finite")
        self.max_delay = int(self.delays.max()) if n else 1
        self.queue = deque([np.zeros(size, dtype=np.float64) for _ in range(self.max_delay + 1)])
        self.last_pre = np.zeros(size, dtype=np.float64)
        self.last_post = np.zeros(size, dtype=np.float64)

    @classmethod
    def random(cls, size, probability, rng):
        pre, post = [], []
        for i in range(size):
            candidates = np.flatnonzero(rng.random(size) < probability)
            for j in candidates:
                if i != j:
                    pre.append(i); post.append(int(j))
        n = len(pre)
        weights = rng.uniform(0.1, 1.0, n)
        excitatory = rng.random(n) < 0.8
        delays = rng.integers(1, 4, n, dtype=np.int32)
        return cls(size, pre, post, weights, delays, excitatory)

    def deliver(self, spikes):
        spikes = np.asarray(spikes, dtype=bool)
        if spikes.shape != (self.size,):
            raise ValueError("spikes have wrong shape")
        current = self.queue.popleft()
        self.queue.append(np.zeros(self.size, dtype=np.float64))
        fired = np.flatnonzero(spikes)
        if len(fired):
            mask = np.isin(self.pre, fired)
            indices = np.flatnonzero(mask)
            for k in indices:
                slot = int(self.delays[k]) - 1
                self.queue[slot][self.post[k]] += self.weights[k] * (1.0 if self.excitatory[k] else -1.0)
        return current

    def update_plasticity(self, spikes, rate=0.002):
        spikes = np.asarray(spikes, dtype=np.float64)
        if spikes.shape != (self.size,):
            raise ValueError("spikes have wrong shape")
        # Bounded rate-trace correlation proxy, not a full biological STDP model.
        pre_trace = self.last_pre
        post_trace = self.last_post
        delta = rate * (
            pre_trace[self.pre] * spikes[self.post]
            - 0.5 * spikes[self.pre] * post_trace[self.post]
        )
        self.weights = np.clip(self.weights + delta, 0.0, 2.0)
        self.last_pre = 0.95 * pre_trace + spikes
        self.last_post = 0.95 * post_trace + spikes

    def stats(self):
        return {"neurons": self.size, "synapses": len(self.weights),
                "mean_abs_weight": float(np.mean(np.abs(self.weights))) if len(self.weights) else 0.0}
