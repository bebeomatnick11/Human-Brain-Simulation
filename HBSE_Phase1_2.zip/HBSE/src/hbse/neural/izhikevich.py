"""Vectorized Izhikevich-style point neurons; voltage in mV, time in ms."""
from dataclasses import dataclass
import numpy as np

@dataclass
class IzhikevichPopulation:
    size: int
    a: np.ndarray
    b: np.ndarray
    c: np.ndarray
    d: np.ndarray
    v: np.ndarray
    u: np.ndarray
    refractory: np.ndarray
    last_spikes: np.ndarray

    @classmethod
    def create(cls, size, rng):
        if size < 1:
            raise ValueError("size must be positive")
        # Regular-spiking-like parameterization with small seeded heterogeneity.
        a = np.full(size, 0.02, dtype=np.float64)
        b = np.full(size, 0.2, dtype=np.float64)
        c = np.full(size, -65.0, dtype=np.float64)
        d = np.full(size, 8.0, dtype=np.float64)
        v = c.copy()
        u = b * v
        return cls(size, a, b, c, d, v, u,
                   np.zeros(size, dtype=np.int32),
                   np.zeros(size, dtype=bool))

    def step(self, current, dt_ms=1.0, refractory_steps=2):
        current = np.asarray(current, dtype=np.float64)
        if current.shape != (self.size,):
            raise ValueError(f"current must have shape ({self.size},)")
        if not np.all(np.isfinite(current)):
            raise ValueError("current must be finite")
        if dt_ms <= 0:
            raise ValueError("dt_ms must be positive")
        active = self.refractory <= 0
        # Two half-steps improve numerical behavior at typical 1 ms resolution.
        v0 = self.v.copy()
        self.v[active] += 0.5 * dt_ms * (
            0.04 * v0[active] ** 2 + 5 * v0[active] + 140 - self.u[active] + current[active]
        )
        v1 = self.v.copy()
        self.v[active] += 0.5 * dt_ms * (
            0.04 * v1[active] ** 2 + 5 * v1[active] + 140 - self.u[active] + current[active]
        )
        self.u[active] += dt_ms * self.a[active] * (self.b[active] * self.v[active] - self.u[active])
        spikes = self.v >= 30.0
        self.v[spikes] = self.c[spikes]
        self.u[spikes] += self.d[spikes]
        self.refractory = np.maximum(self.refractory - 1, 0)
        self.refractory[spikes] = max(0, int(refractory_steps))
        self.last_spikes = spikes
        return spikes.copy()
