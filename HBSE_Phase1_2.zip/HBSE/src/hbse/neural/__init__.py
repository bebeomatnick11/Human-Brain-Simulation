from .izhikevich import IzhikevichPopulation
__all__ = ["IzhikevichPopulation"]
