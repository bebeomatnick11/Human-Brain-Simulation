"""Explicit, uncertain attribution records; never treat inferred states as observed facts."""
def infer_belief(agent_id, proposition, evidence_strength):
    evidence_strength = max(0.0, min(1.0, float(evidence_strength)))
    return {"agent_id": str(agent_id), "proposition": str(proposition),
            "confidence": evidence_strength, "source_type": "inference"}
