"""Small appraisal-state proxy, not a model of subjective feeling."""
class AffectiveState:
    def __init__(self):
        self.valence = 0.0
        self.arousal = 0.1
        self.stress = 0.0

    def update(self, prediction_error, controllability=0.5, dt=1.0):
        target_valence = max(-1.0, min(1.0, float(prediction_error)))
        target_arousal = max(0.0, min(1.0, abs(float(prediction_error))))
        alpha = 1.0 - pow(0.9, max(0.0, float(dt)))
        self.valence += alpha * (target_valence - self.valence)
        self.arousal += alpha * (target_arousal - self.arousal)
        stress_target = target_arousal * (1.0 - max(0.0, min(1.0, float(controllability))))
        self.stress += alpha * (stress_target - self.stress)
        return {"valence": self.valence, "arousal": self.arousal, "stress": self.stress}
