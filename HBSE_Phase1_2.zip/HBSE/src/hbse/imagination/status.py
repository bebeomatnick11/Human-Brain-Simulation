def counterfactual(label, assumptions, predicted_outcome):
    return {"label": str(label), "source_type": "counterfactual_simulation",
            "assumptions": list(assumptions), "predicted_outcome": predicted_outcome,
            "is_observed_fact": False}
