class WorldModel:
    """Exponential prediction model; stores a mean and uncertainty proxy per feature."""
    def __init__(self, learning_rate=0.15):
        if not 0 < learning_rate <= 1: raise ValueError("learning_rate must be in (0,1]")
        self.learning_rate = float(learning_rate)
        self.means = {}
        self.uncertainty = {}
        self.observations = 0

    def predict(self, key, default=0.0):
        return float(self.means.get(str(key), default))

    def observe(self, key, value):
        key, value = str(key), float(value)
        if not __import__("math").isfinite(value): raise ValueError("observation must be finite")
        old = self.means.get(key, value)
        error = value - old
        self.means[key] = old + self.learning_rate * error
        self.uncertainty[key] = 0.9 * self.uncertainty.get(key, abs(error)) + 0.1 * abs(error)
        self.observations += 1
        return {"prediction": old, "observed": value, "prediction_error": error,
                "updated": self.means[key], "uncertainty": self.uncertainty[key]}
