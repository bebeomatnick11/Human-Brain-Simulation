def consolidate(items, replay_budget=8):
    """Replay high-confidence recent memory candidates; does not simulate biological sleep."""
    if replay_budget < 0: raise ValueError("replay_budget must be non-negative")
    ranked = sorted(items, key=lambda x: float(x.get("confidence", 0)), reverse=True)
    return {"replayed": ranked[:replay_budget], "mode": "offline_consolidation_proxy"}
