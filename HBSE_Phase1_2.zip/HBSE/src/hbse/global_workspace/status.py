def broadcast(candidates, capacity=4):
    """Bounded winner-take-most workspace proxy."""
    if capacity < 0: raise ValueError("capacity must be non-negative")
    return sorted(candidates, key=lambda x: float(x.get("priority", 0)), reverse=True)[:capacity]
