import json
def render_status(engine):
    return json.dumps(engine.status(), indent=2, sort_keys=True)
