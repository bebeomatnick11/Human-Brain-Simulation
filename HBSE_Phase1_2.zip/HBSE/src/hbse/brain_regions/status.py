REGIONS = {
 "sensory_cortex": "Input feature processing; coarse functional placeholder.",
 "motor_cortex": "Action selection interface; coarse functional placeholder.",
 "prefrontal_cortex": "Goal maintenance and control; linked to GoalSystem.",
 "hippocampus": "Episodic indexing; future module, not a biological hippocampus.",
 "amygdala": "Threat/salience appraisal; future module.",
 "basal_ganglia": "Action selection; future module.",
 "thalamus": "Routing/gating; future module.",
 "cerebellum": "Adaptive motor prediction; future module.",
 "hypothalamus": "Homeostatic control; future module.",
 "brainstem": "Basic control-state placeholder; not life-support simulation."
}
