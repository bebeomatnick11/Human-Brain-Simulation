def encode_scalar(value, minimum=-1.0, maximum=1.0):
    value = float(value)
    if not minimum <= value <= maximum:
        raise ValueError("percept outside declared range")
    return {"value": value, "source_type": "direct_observation", "confidence": 1.0}
