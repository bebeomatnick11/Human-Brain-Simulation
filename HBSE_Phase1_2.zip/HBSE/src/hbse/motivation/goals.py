class GoalSystem:
    def __init__(self):
        self.goals = {"explore": 0.5, "stability": 0.5, "learn": 0.5}
        self.history = []

    def set_need(self, name, value):
        value = float(value)
        if not 0 <= value <= 1: raise ValueError("need must be in [0,1]")
        self.goals[str(name)] = value

    def choose(self, candidates):
        if not candidates: raise ValueError("at least one candidate is required")
        def score(item):
            return float(item.get("expected_reward", 0)) + 0.25 * self.goals.get(item.get("goal", ""), 0)
        chosen = max(candidates, key=score)
        self.history.append({"chosen": dict(chosen), "score": score(chosen)})
        return dict(chosen)
