def action_command(action):
    if not isinstance(action, dict) or "name" not in action:
        raise ValueError("action must be a dict with a name")
    return {"command": str(action["name"]), "source": "decision_engine"}
