from collections import deque
from dataclasses import dataclass, asdict
import time

@dataclass
class MemoryItem:
    content: str
    source: str
    confidence: float
    created_step: int
    tokens: tuple[str, ...]
    recalled: int = 0

class WorkingMemory:
    def __init__(self, capacity=64):
        if capacity < 1: raise ValueError("capacity must be positive")
        self.capacity = int(capacity)
        self.items = deque(maxlen=capacity)

    def add(self, content, source="observation", confidence=1.0, step=0):
        if not isinstance(content, str) or not content.strip():
            raise ValueError("content must be a non-empty string")
        confidence = float(confidence)
        if not 0 <= confidence <= 1: raise ValueError("confidence must be in [0,1]")
        tokens = tuple(sorted(set(content.lower().split())))
        item = MemoryItem(content, str(source), confidence, int(step), tokens)
        self.items.append(item)
        return item

    def retrieve(self, query, limit=5):
        q = set(str(query).lower().split())
        scored = []
        for item in self.items:
            overlap = len(q.intersection(item.tokens)) / max(1, len(q.union(item.tokens)))
            score = overlap * item.confidence
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        out = []
        for score, item in scored[:max(0, int(limit))]:
            item.recalled += 1
            out.append({"score": score, **asdict(item)})
        return out

    def to_dict(self):
        return {"capacity": self.capacity, "items": [asdict(x) for x in self.items]}

    @classmethod
    def from_dict(cls, data):
        obj = cls(int(data["capacity"]))
        for raw in data["items"]:
            raw["tokens"] = tuple(raw["tokens"])
            obj.items.append(MemoryItem(**raw))
        return obj
