import math

def finite_vector(values, limit=20.0):
    result = []
    for value in values:
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("input values must be finite")
        result.append(max(-limit, min(limit, number)))
    return result

def bounded_steps(steps, maximum):
    steps = int(steps)
    if steps < 0 or steps > maximum:
        raise ValueError(f"steps must be in [0, {maximum}]")
    return steps
