import json
import numpy as np
from hbse.config.defaults import SimulationConfig
from hbse.neural.izhikevich import IzhikevichPopulation
from hbse.synapses.network import SparseSynapticNetwork
from hbse.memory.working import WorkingMemory
from hbse.cognition.world_model import WorldModel
from hbse.learning.prediction_error import PredictionErrorLearner
from hbse.motivation.goals import GoalSystem
from hbse.security.limits import finite_vector, bounded_steps

class HBSEngine:
    STATE_VERSION = 1
    def __init__(self, config=None):
        self.config = config or SimulationConfig()
        self.config.validate()
        self.rng = np.random.default_rng(self.config.seed)
        self.neurons = IzhikevichPopulation.create(self.config.neuron_count, self.rng)
        self.network = SparseSynapticNetwork.random(
            self.config.neuron_count, self.config.connection_probability, self.rng)
        self.memory = WorkingMemory(self.config.memory_capacity)
        self.world = WorldModel()
        self.learner = PredictionErrorLearner()
        self.goals = GoalSystem()
        self.step_index = 0
        self.event_log = []
        self.last_current = np.zeros(self.config.neuron_count, dtype=np.float64)
        self.last_spike_count = 0

    def step(self, external_current=None):
        if external_current is None:
            external_current = np.zeros(self.config.neuron_count, dtype=np.float64)
        else:
            external_current = np.asarray(finite_vector(external_current, self.config.max_input), dtype=np.float64)
        if external_current.shape != (self.config.neuron_count,):
            raise ValueError(f"external_current must have {self.config.neuron_count} values")
        synaptic_current = self.network.deliver(self.neurons.last_spikes)
        current = external_current + synaptic_current
        spikes = self.neurons.step(current, self.config.dt_ms, self.config.refractory_steps)
        self.network.update_plasticity(spikes)
        self.step_index += 1
        self.last_current = current.copy()
        self.last_spike_count = int(spikes.sum())
        event = {"step": self.step_index, "spikes": self.last_spike_count,
                 "mean_current": float(np.mean(current)), "synapses": len(self.network.weights)}
        self.event_log.append(event)
        return event

    def run(self, steps=100):
        steps = bounded_steps(steps, self.config.max_steps_per_call)
        return [self.step() for _ in range(steps)]

    def observe(self, key, value, source="environment", confidence=1.0):
        result = self.world.observe(key, value)
        self.memory.add(f"{key} {value}", source=source, confidence=confidence, step=self.step_index)
        self.event_log.append({"step": self.step_index, "type": "observation", "key": str(key),
                               "prediction_error": result["prediction_error"]})
        return result

    def status(self):
        return {"version": self.STATE_VERSION, "step": self.step_index,
                "neurons": self.config.neuron_count, "synapses": len(self.network.weights),
                "last_spike_count": self.last_spike_count,
                "mean_voltage_mv": float(np.mean(self.neurons.v)),
                "memory_items": len(self.memory.items),
                "world_features": len(self.world.means)}

    def snapshot(self):
        return {
            "state_version": self.STATE_VERSION,
            "config": self.config.__dict__,
            "step_index": self.step_index,
            "rng_state": self.rng.bit_generator.state,
            "neurons": {k: getattr(self.neurons, k).tolist() for k in
                        ("a","b","c","d","v","u","refractory","last_spikes")},
            "network": {"pre": self.network.pre.tolist(), "post": self.network.post.tolist(),
                        "weights": self.network.weights.tolist(), "delays": self.network.delays.tolist(),
                        "excitatory": self.network.excitatory.tolist(),
                        "queue": [x.tolist() for x in self.network.queue],
                        "last_pre": self.network.last_pre.tolist(), "last_post": self.network.last_post.tolist()},
            "memory": self.memory.to_dict(),
            "world": {"learning_rate": self.world.learning_rate, "means": self.world.means,
                      "uncertainty": self.world.uncertainty, "observations": self.world.observations},
            "learner": {"rate": self.learner.rate, "values": [[list(k), v] for k,v in self.learner.values.items()]},
            "goals": self.goals.goals, "event_log": self.event_log,
            "last_current": self.last_current.tolist(), "last_spike_count": self.last_spike_count
        }

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.snapshot(), f, indent=2, allow_nan=False)

    @classmethod
    def load(cls, path):
        with open(path, "r", encoding="utf-8") as f: data = json.load(f)
        if data.get("state_version") != cls.STATE_VERSION:
            raise ValueError("unsupported state version")
        cfg = SimulationConfig(**data["config"])
        obj = cls(cfg)
        obj.step_index = int(data["step_index"])
        obj.rng.bit_generator.state = data["rng_state"]
        for k, values in data["neurons"].items():
            setattr(obj.neurons, k, np.asarray(values, dtype=bool if k == "last_spikes" else (np.int32 if k == "refractory" else np.float64)))
        n = data["network"]
        obj.network = SparseSynapticNetwork(obj.config.neuron_count, n["pre"], n["post"], n["weights"], n["delays"], n["excitatory"])
        from collections import deque
        obj.network.queue = deque(np.asarray(x, dtype=np.float64) for x in n["queue"])
        obj.network.last_pre = np.asarray(n["last_pre"], dtype=np.float64)
        obj.network.last_post = np.asarray(n["last_post"], dtype=np.float64)
        obj.memory = WorkingMemory.from_dict(data["memory"])
        obj.world.learning_rate = data["world"]["learning_rate"]
        obj.world.means = data["world"]["means"]; obj.world.uncertainty = data["world"]["uncertainty"]
        obj.world.observations = data["world"]["observations"]
        obj.learner.rate = data["learner"]["rate"]
        obj.learner.values = {(x[0], x[1]): v for x, v in data["learner"]["values"]}
        obj.goals.goals = data["goals"]; obj.event_log = data["event_log"]
        obj.last_current = np.asarray(data["last_current"], dtype=np.float64)
        obj.last_spike_count = int(data["last_spike_count"])
        return obj
