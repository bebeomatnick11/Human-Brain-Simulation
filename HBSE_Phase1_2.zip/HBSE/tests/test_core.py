import numpy as np
import pytest
from hbse.config.defaults import SimulationConfig
from hbse.simulation.engine import HBSEngine
from hbse.memory.working import WorkingMemory
from hbse.cognition.world_model import WorldModel

def test_deterministic_seed():
    a = HBSEngine(SimulationConfig(seed=42, neuron_count=32))
    b = HBSEngine(SimulationConfig(seed=42, neuron_count=32))
    assert a.network.pre.tolist() == b.network.pre.tolist()
    assert a.network.weights.tolist() == b.network.weights.tolist()
    assert a.run(10) == b.run(10)

def test_neural_step_and_shape_validation():
    engine = HBSEngine(SimulationConfig(neuron_count=16))
    event = engine.step(np.full(16, 12.0))
    assert event["step"] == 1
    with pytest.raises(ValueError):
        engine.step([1.0])

def test_memory_provenance_and_retrieval():
    memory = WorkingMemory(2)
    memory.add("blue object", source="camera", confidence=0.9, step=3)
    memory.add("green object", source="sensor", confidence=0.8, step=4)
    result = memory.retrieve("blue object")
    assert result and result[0]["source"] == "camera"
    memory.add("red object")
    assert len(memory.items) == 2

def test_world_model_prediction_error():
    model = WorldModel(learning_rate=0.5)
    first = model.observe("x", 1.0)
    second = model.observe("x", 0.0)
    assert first["prediction_error"] == 0.0
    assert second["prediction_error"] < 0.0
    assert model.means["x"] == 0.5

def test_snapshot_roundtrip(tmp_path):
    engine = HBSEngine(SimulationConfig(seed=5, neuron_count=24))
    engine.observe("temperature", 0.3)
    engine.run(5)
    path = tmp_path / "state.json"
    engine.save(path)
    restored = HBSEngine.load(path)
    assert restored.status() == engine.status()
    assert restored.run(5) == engine.run(5)

def test_input_limits():
    engine = HBSEngine(SimulationConfig(neuron_count=8))
    with pytest.raises(ValueError):
        engine.step([float("nan")] * 8)
    with pytest.raises(ValueError):
        engine.run(100001)


def test_affective_state_is_bounded_and_dynamic():
    from hbse.emotion.status import AffectiveState
    state = AffectiveState()
    out = state.update(prediction_error=0.9, controllability=0.2)
    assert 0 <= out["arousal"] <= 1
    assert 0 <= out["stress"] <= 1
    assert out["valence"] > 0
