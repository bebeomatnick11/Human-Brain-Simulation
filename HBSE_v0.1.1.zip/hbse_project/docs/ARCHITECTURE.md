# HBSE architecture and implementation phases

## Data flow in v0.1.0

```text
LineWorld observation
        │
        ├──> Gaussian population encoder ──> LIF spiking network
        │                                  └──> spike count metric
        │
        └──> epsilon-greedy Q policy ──> environment action
                     │                         │
                     ├── TD update <── reward + next state
                     └── transition ──> predictive world model / surprise
                                               │
                                  ┌────────────┴──────────┐
                                  v                       v
                         working + episodic memory    goal progress
                                  └────────────┬──────────┘
                                               v
                                     global workspace
                                               │
                                     inspection + metrics
```

The present integration is intentionally asymmetric: environment position stimulates the neural population, while the tabular Q policy selects actions. This lets the project test neural dynamics and cognition in one repeatable executable but does **not** imply that cognition is emergent from the spiking network. Replacing the tabular policy with a validated neural action-selection loop is a separate research objective.

## Scheduler contract

A scheduled component implements `update(context: dict, dt_s: float) -> None`. Each cognitive tick constructs a fresh context, then executes tasks sorted by `(priority, name)`. The `neural_dynamics` task advances `neural_substeps` LIF steps; with the default configuration this is 50 x 1 ms per 50 ms cognitive tick. This is an explicit multi-rate approximation, not a claim that every brain process shares a fixed clock.

Current ordered tasks:

1. `perception` (priority 10): encode the observed position.
2. `neural_dynamics` (20): integrate the network and count spikes.
3. `decision_and_learning` (30): choose action, step environment, update world model and Q values.
4. `goal_state` (40): calculate current goal progress.
5. `memory_encoding` (50): encode the transition with source/provenance.
6. `global_workspace` (60): compete and broadcast salient items.

## State and failure boundaries

- Components own their state and expose `state_dict` / `load_state_dict` where state must survive restarts.
- Checkpoint format is JSON schema version 1. Writes use a temporary file followed by atomic replacement.
- Deserialization checks schema, dimensions, configuration, bounded numerical values, and required keys. No `pickle` is used.
- Memory capacity is bounded. Working memory items expire by age; episodic memory uses oldest-item eviction once capacity is reached. The first version does not silently claim that this eviction is equivalent to biological forgetting.
- A checkpoint preserves experiment state but is not cryptographically signed. Do not load checkpoint files from untrusted parties in a sensitive deployment.

## Target system tree (roadmap)

Future directories are introduced as executable modules, rather than empty scaffolding:

```text
hbse/
├── neural/                 # LIF, AdEx/Hodgkin-Huxley adapters, population dynamics
├── synapses/               # delays, short/long-term plasticity, STDP variants
├── brain_regions/          # regional models + connectivity assumptions
├── perception/             # multimodal encoders with source evidence
├── cognition/              # world model, causal/inference tasks
├── attention/              # sustained/selective attention allocation
├── memory/                 # sensory/working/episodic/semantic/procedural/spatial
├── emotion/                # appraisal, valence/arousal, temporal dynamics
├── motivation/             # goals, drives, simulated homeostasis
├── personality/            # trait/state/value separation
├── social_cognition/       # belief models, uncertainty about other agents
├── learning/               # supervised, unsupervised, RL, continual-learning gates
├── sleep/                  # offline replay and consolidation experiments
├── virtual_body/           # simulated interoceptive variables
├── self_model/             # resource/competence/state estimates
├── global_workspace/       # competition and inter-module broadcast
├── imagination/            # counterfactual rollouts with source labels
├── decision/               # candidate generation, cost/risk, safety constraints
├── motor_control/          # actions and feedback loops
├── environment/            # sandboxed, deterministic experiments
├── data/                   # schema, data governance and dataset adapters
├── simulation/             # scheduler, snapshots and experiment runner
├── visualization/          # activity, memory and metric inspection
├── benchmarks/             # baselines, test cases and performance reports
├── tests/                  # unit/integration/regression/scientific-validation tests
├── security/               # permissions, audit, resource budgets, data deletion
├── api/                    # optional local API boundary
└── config/                 # validated experiment profiles
```

## Phases

### Phase 1 — scope and architecture (delivered)

- Evidence vs analogy taxonomy, module ownership, scheduler contract, resource bounds and testable success criteria are documented.
- Technology: Python 3.11+, NumPy, JSON checkpoints, pytest. The first tier runs on CPU; a GPU is unnecessary.
- Default model: 64 neurons and a sparse random graph; it is intentionally small. Exact synapse count is seeded and is reported at runtime.

### Phase 2 — core simulation (implemented in this release)

- Deterministic scheduler, sparse LIF network, delayed signed synapses, optional STDP, position encoder, working/episodic memory, world model, goal, Q-learning, global workspace, checkpoint/resume, metrics and automated tests.
- Validation is by unit and integration tests. Task-learning outcomes should be reported from actual execution and never filled with expected numbers.

### Phase 3 — cognitive and affective systems

Add a continuous-valued appraisal model with separate transient affect and mood dynamics, goal conflict and simulated body state; first build independent tests and then couple these to attention, memory retrieval and policy. Add semantic memory and confidence-calibrated language adapters only behind interfaces, without equating language output with the full brain.

### Phase 4 — biological detail

Add an explicitly selected neural tier (e.g. AdEx or Hodgkin–Huxley using appropriate numerical integration) and data-backed regional connectivity. Preserve the current core behind stable interfaces. Do not introduce molecular detail where no measurements or parameters support it.

### Phase 5 — scientific validation

Use controlled seeds, held-out conditions, baselines, ablations, repeated trials, uncertainty intervals, resource profiling and regression gates. Track both successes and regressions; do not infer global fidelity from a single task.

### Phase 6 — expansion

Scale network sizes only after sparse/event-driven profiling, validate memory/runtime growth, add checkpoint migrations, and introduce GPU/distributed execution only where measured bottlenecks justify it.
