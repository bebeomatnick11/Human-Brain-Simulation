# Scientific scope, evidence classes, and limits

## Evidence classes used by HBSE

- **Mechanism implemented:** equations or algorithms are executable and unit-testable.
- **Empirical abstraction:** parameters or outputs summarize observed data, but resolution is much coarser than biology.
- **Functional analogy:** a component is inspired by a broad brain function but is not an anatomical replica.
- **Research proposal:** a target for later work, not implemented in v0.1.0.
- **Unresolved:** the project does not use software behavior as evidence that a disputed or inaccessible phenomenon has been reproduced.

## Implemented mechanisms

### LIF membrane equation

The network integrates the reduced form

`tau_m * dV/dt = -(V - V_rest) + R_m * I`

with Euler updates, a fixed threshold, reset voltage, and a refractory counter. Voltage is expressed in mV, time in ms, current in nA, and resistance in MOhm. The equation is useful for network dynamics but does not explicitly represent sodium/potassium channel gating, dendritic compartments, metabolic costs, or biological cell diversity.

### Sparse delayed synapses

A seeded Bernoulli graph determines the initial directed edges. Each source neuron is assigned excitatory or inhibitory sign; edge delay is an integer number of neural steps. Spikes schedule weighted current impulses into a ring buffer. This is an engineered random graph, not a measured connectome.

### Optional pair-based STDP

Pre- and post-synaptic traces decay exponentially. Co-activity modifies edge magnitude within fixed bounds. This is a compact phenomenological plasticity rule; it omits calcium, receptor kinetics, cell-type specificity, neuromodulator dependence, homeostatic plasticity, and many experimentally observed STDP variants.

### Tabular cognition loop

Q-learning updates `Q(s,a)` by the temporal-difference error. The world model estimates transition distributions from counts plus a small prior and reports a bounded predictive error. The task is fully discrete and observable. It cannot establish general reasoning, language understanding, causal discovery, or human-like memory.

## Broad brain functions not reproduced in this release

| Target | Status | Next valid step |
|---|---|---|
| Ion-channel action potentials | Not implemented | Add and validate a named conductance-based model with published parameters |
| Receptor-specific neurotransmission | Not implemented | Specify cell/receptor types, kinetics, concentrations and supported data |
| Anatomically grounded regional networks | Not implemented | Select a documented circuit/connectome and preserve uncertainty in mappings |
| Vision, hearing, touch and multimodal binding | Not implemented | Use evaluated local models/datasets and record sensory transformation limits |
| Human-like episodic/semantic consolidation | Not established | Add separate memory benchmarks and compare with published task baselines |
| Emotional experience / subjective feeling | Not testable from these state variables | Keep computational affect distinct from any claim of subjective experience |
| Sleep stages and dreams | Not implemented | Start with offline replay/consolidation tasks; do not label it biological sleep |
| Theory of mind and empathy | Not implemented | Model explicit beliefs about agents and benchmark against controlled tasks |
| Global workspace / functional awareness | Partial functional analogy only | Evaluate information broadcast and reportability; do not infer phenomenal consciousness |
| Full human brain emulation | Not delivered | Requires far more detailed structure, data, models and validation than this prototype |

## Validation principles

1. Unit tests verify the code's stated contract (e.g. input shape, transition probability, checkpoint reproducibility).
2. Integration tests verify that state flows across components and resume agrees with uninterrupted execution.
3. Behavior benchmarks compare against simple baselines under fixed seeds and held-out configurations.
4. Hardware benchmarks report the actual host, software versions, elapsed time, neuron/synapse counts and configuration.
5. Scientific claims require external correspondence with empirical results—not merely self-consistency of the implementation.

No performance or learning metric in the code is pre-populated as a scientific result. CLI output comes from the run that was actually executed.

## Further reading used to set the model boundary

- Brian 2 documentation, “Models and neuron groups” (equation-based neuron populations and stochastic terms): <https://brian2.readthedocs.io/en/stable/user/models.html>
- NEST documentation, “All about synapses and connections” (network structure, synapse models, delay/plasticity choices): <https://nest-simulator.readthedocs.io/en/stable/synapses/index.html>
- Hodgkin & Huxley (1952), “A quantitative description of membrane current and its application to conduction and excitation in nerve,” *The Journal of Physiology*, DOI: <https://doi.org/10.1113/jphysiol.1952.sp004764>

These references describe modelling methods and biological mechanisms. They do not validate HBSE as a whole-brain model.
