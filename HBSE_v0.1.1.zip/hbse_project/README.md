# Human Brain Simulation Engine (HBSE)

**Version 0.1.0 — runnable research prototype, not a reconstructed human brain.**

HBSE is a local, inspectable computational neuroscience scaffold. This first release delivers an end-to-end executable loop: a sparse recurrent leaky integrate-and-fire (LIF) network, optional pair-based STDP, position population coding, a tabular predictive world model, bounded working memory, episodic transition memory, goal progress, Q-learning, global-workspace-style salience competition, an ordered scheduler, metrics, and JSON checkpoint/resume.

The cognitive behavior is deliberately limited to a one-dimensional navigation task. The neural activity and cognitive task are coupled through an input encoding and run together, but the neural network does **not** currently generate the policy or represent the complete task in a validated biological manner. No claim of human-like general intelligence, subjective emotion, pain, dreaming, consciousness, or whole-brain fidelity is made.

## Quick start

Requirements: Python 3.11+ and NumPy 1.24+. No network access, account, paid API key, GPU, or model download is required.

```bash
cd hbse_project
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
python -m pip install -e '.[test]'
python -m hbse --steps 300 --pretty
```

Run tests:

```bash
pytest
```

Run a benchmark with measured wall-clock throughput:

```bash
python -m hbse --steps 300 --benchmark --pretty
```

Save and resume a checkpoint:

```bash
python -m hbse --steps 100 --checkpoint run.json --pretty
python -m hbse --resume run.json --steps 100 --pretty
```

Use custom settings with `--config config/default.json`. A resumed run uses the checkpoint's configuration; `--config` and `--seed` must not be supplied with `--resume`.

## What's implemented

| Component | Executable mechanism | Scope/limit |
|---|---|---|
| Scheduler | Stable priority order, fixed cognitive timestep, task periods | No asynchronous parallel scheduler yet |
| Neurons | Vectorized LIF membrane integration, threshold, reset, refractory period | No ion channels, dendrites, morphology, or conductance kinetics |
| Network/synapses | Sparse source-target edges, signed weights, integer delays, delay ring buffer | Random toy connectivity, not connectomics-based |
| Plasticity | Optional pair-based STDP traces and bounded weight update | Phenomenological rule, not molecular plasticity |
| Perception | Gaussian population/place-code from discrete position | Synthetic input, not vision/audio/somatosensory processing |
| Working memory | Bounded capacity, TTL expiry, activation decay, tag retrieval | Not a validated human working-memory model |
| Episodic memory | Timestamped experiences, source/provenance, confidence, retrieval | In-memory store with bounded capacity; sensitive-data controls need a later layer |
| World model | Empirical transition counts, smoothed next-state probabilities, prediction error | Tabular and task-specific; not open-world causal inference |
| Motivation/goals | Explicit target, priority, urgency and progress | One demonstrator goal; no biological homeostasis |
| Learning | Q-learning with epsilon-greedy action choice and TD error | Small discrete task, not general learning |
| Global workspace | Salience competition and bounded broadcast with provenance | Functional analogy only; not evidence of consciousness |
| Checkpoint | Versioned JSON, atomic replace, shape/config checks, no pickle | Treat checkpoint files as sensitive research artifacts |
| Validation | Unit, integration, checkpoint determinism tests; actual runtime metrics | No benchmark evidence for human-level capabilities |

## Science and fidelity policy

HBSE separates three evidence classes:

1. **Established mathematical mechanism:** the implemented code follows an explicit equation or algorithm (e.g., LIF integration, tabular Q-learning, counts-based transition estimates).
2. **Functional analogy:** an information-processing component is named after a broad brain function, but it is not a validated anatomical or physiological reconstruction.
3. **Not implemented / not established:** whole-brain wiring, human connectome at synaptic resolution, multimodal perception, detailed neurotransmitter/receptor systems, realistic sleep architecture, autobiographical identity, subjective feelings, and phenomenal consciousness.

The region registry is intentionally labelled as functional analogy. Names like `hippocampal_memory` or `prefrontal_control` describe a research hypothesis at this abstraction level; they do not indicate that the relevant biological circuitry is simulated.

## Project layout

```text
hbse_project/
├── config/default.json
├── docs/
│   ├── ARCHITECTURE.md
│   └── SCIENTIFIC_SCOPE.md
├── hbse/
│   ├── core/               # scheduler and JSON checkpoint storage
│   ├── neural/             # LIF population and sparse spiking network
│   ├── synapses/           # optional pair STDP rule
│   ├── brain_regions/      # coarse, explicitly caveated registry
│   ├── perception/         # discrete population encoder
│   ├── cognition/          # tabular predictive world model
│   ├── memory/             # working and episodic stores
│   ├── motivation/         # goal state and progress
│   ├── learning/           # tabular Q-learning
│   ├── global_workspace/   # bounded salience broadcast
│   ├── environment/        # reproducible LineWorld
│   ├── simulation/         # integrated execution loop
│   ├── benchmarks/         # measured microbenchmark
│   ├── config.py
│   └── cli.py
└── tests/
```

The eventual architecture also calls for `emotion/`, `personality/`, `social_cognition/`, `sleep/`, `virtual_body/`, `self_model/`, `imagination/`, `decision/`, `motor_control/`, `visualization/`, `data/`, `security/`, and `api/`. These are specified in the roadmap, **not represented by empty placeholder modules in v0.1.0**. They should be added only with state/update rules, provenance, tests, and measurable behavior.

## Reproducibility and interpretation

- All stochastic initialization and exploration are seeded by default.
- Checkpoints preserve the Q table, neural state, synaptic weights, delay queue, memory, world model, workspace, environment, clocks, random state, and metrics history.
- The test suite checks checkpoint resume against an uninterrupted run on the small deterministic configuration.
- `--benchmark` reports measured machine-local runtime; throughput varies with Python, NumPy, CPU, network size, and configuration.
- A neuron count is not a fidelity score. Current results validate implementation behavior only, not correspondence to a human brain.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/SCIENTIFIC_SCOPE.md](docs/SCIENTIFIC_SCOPE.md).
