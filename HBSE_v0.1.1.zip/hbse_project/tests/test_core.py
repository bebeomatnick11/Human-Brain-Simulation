import numpy as np
import pytest

from hbse.config import BrainConfig
from hbse.core.scheduler import SimulationScheduler
from hbse.learning.q_learning import QLearningAgent
from hbse.memory.working import WorkingMemory
from hbse.neural.lif import LIFPopulation
from hbse.neural.network import SpikingNetwork


def test_config_rejects_invalid_values():
    with pytest.raises(ValueError):
        BrainConfig(num_neurons=1)
    with pytest.raises(ValueError):
        BrainConfig(epsilon=0.1, epsilon_min=0.2)


def test_scheduler_is_sorted_and_supports_periods():
    scheduler = SimulationScheduler(dt_s=0.1)
    calls = []
    scheduler.register("late", lambda ctx, dt: calls.append("late"), priority=20)
    scheduler.register("early", lambda ctx, dt: calls.append("early"), priority=10)
    scheduler.register("every_two", lambda ctx, dt: calls.append("two"), priority=15, period_steps=2)
    scheduler.step({})
    assert calls == ["early", "two", "late"]
    calls.clear()
    scheduler.step({})
    assert calls == ["early", "late"]
    assert scheduler.tick == 2
    assert scheduler.time_s == pytest.approx(0.2)


def test_lif_population_spikes_and_respects_input_shape():
    pop = LIFPopulation(2, dt_ms=1.0)
    fired = False
    for _ in range(40):
        fired = bool(pop.step(np.array([3.0, 0.0])).any()) or fired
    assert fired
    with pytest.raises(ValueError):
        pop.step(np.zeros(3))


def test_network_is_deterministic_for_same_seed():
    left = SpikingNetwork(12, seed=22, connection_probability=0.2)
    right = SpikingNetwork(12, seed=22, connection_probability=0.2)
    current = np.full(12, 2.5)
    left_spikes, right_spikes = [], []
    for _ in range(20):
        left_spikes.append(left.step(current))
        right_spikes.append(right.step(current))
    assert all(np.array_equal(a, b) for a, b in zip(left_spikes, right_spikes))
    assert left.n_synapses == right.n_synapses


def test_q_learning_updates_value():
    import random
    agent = QLearningAgent(3, 2, rng=random.Random(1), alpha=0.5, gamma=0.9, epsilon=0.0, epsilon_min=0.0)
    error = agent.learn(0, 1, 1.0, 1, True)
    assert error == pytest.approx(1.0)
    assert agent.q_values[0][1] == pytest.approx(0.5)


def test_working_memory_expires_and_retrieves_by_tag():
    memory = WorkingMemory(capacity=3, ttl_s=5, tau_s=2)
    memory.add({"x": 1}, time_s=0, tags=["fact"])
    memory.add({"x": 2}, time_s=2, tags=["event"])
    results = memory.retrieve(now_s=3, tags=["fact"])
    assert len(results) == 1
    assert results[0]["content"] == {"x": 1}
    memory.expire(6)
    assert len(memory) == 1  # item at t=2 is retained through t=7


def test_optional_stdp_tracks_spike_history():
    network = SpikingNetwork(16, seed=9, connection_probability=0.2, use_stdp=True)
    for _ in range(30):
        network.step(np.full(16, 3.0))
    assert network.stdp is not None
    assert np.any(network.stdp.pre_trace > 0)
    assert np.all(network.weight_magnitude >= network.stdp.min_weight)
    assert np.all(network.weight_magnitude <= network.stdp.max_weight)
