from hbse.cognition.world_model import TabularWorldModel
from hbse.global_workspace.workspace import GlobalWorkspace, WorkspaceCandidate
from hbse.memory.episodic import EpisodicMemory
from hbse.motivation.goals import GoalSystem


def test_world_model_prediction_error_decreases_for_repeated_transition():
    model = TabularWorldModel(3, 2)
    initial_error = model.observe(0, 1, 1, 0.0)
    errors = [model.observe(0, 1, 1, 0.0) for _ in range(10)]
    assert errors[-1] < initial_error
    assert model.predict_next(0, 1) == 1


def test_episodic_memory_records_provenance_and_retrieves():
    memory = EpisodicMemory(capacity=3)
    memory.encode({"state": 1, "action": 0}, time_s=0.5, source="experienced_transition")
    match = memory.retrieve({"state": 1})
    assert len(match) == 1
    assert match[0]["source"] == "experienced_transition"
    assert match[0]["retrieval_count"] == 1


def test_goal_progress_and_workspace_competition():
    goals = GoalSystem(5)
    goals.update(2)
    assert goals.goals[0].progress == 0.5
    workspace = GlobalWorkspace(capacity=1)
    chosen = workspace.broadcast([
        WorkspaceCandidate("weak", {}, 0.2, "derived"),
        WorkspaceCandidate("strong", {}, 0.9, "observed"),
    ], tick=4)
    assert len(chosen) == 1
    assert chosen[0]["channel"] == "strong"
