from hbse.config import BrainConfig
from hbse.simulation.engine import SimulationEngine


def compact_config():
    return BrainConfig(
        seed=13,
        num_neurons=24,
        connection_probability=0.12,
        neural_substeps=5,
        cognitive_dt_s=0.005,
        world_size=5,
        episodic_memory_capacity=100,
        max_working_memory=8,
    )


def test_engine_runs_all_core_loops():
    engine = SimulationEngine(compact_config())
    output = engine.run(20)
    assert output["simulation_steps"] == 20
    assert output["q_updates"] == 20
    assert output["synapses"] > 0
    assert engine.network.step_index == 20 * compact_config().neural_substeps
    assert len(engine.episodic_memory) == 20
    assert len(engine.workspace.last_broadcast) == 3
    assert output["spikes_total"] >= 0


def test_checkpoint_resume_matches_uninterrupted_run(tmp_path):
    config = compact_config()
    uninterrupted = SimulationEngine(config)
    uninterrupted.run(25)

    first = SimulationEngine(config)
    first.run(12)
    checkpoint = tmp_path / "engine.json"
    first.save_checkpoint(str(checkpoint))
    resumed = SimulationEngine.from_checkpoint(str(checkpoint))
    resumed.run(13)

    assert resumed.metrics() == uninterrupted.metrics()
    assert resumed.agent.q_values == uninterrupted.agent.q_values
    assert resumed.workspace.last_broadcast == uninterrupted.workspace.last_broadcast


def test_checkpoint_schema_rejects_unknown_version(tmp_path):
    import json
    from hbse.core.persistence import CheckpointStore, CheckpointError
    path = tmp_path / "bad.json"
    path.write_text(json.dumps({"schema_version": 999, "payload": {}}), encoding="utf-8")
    try:
        CheckpointStore.load(path)
    except CheckpointError:
        pass
    else:
        raise AssertionError("unsupported schema should be rejected")
