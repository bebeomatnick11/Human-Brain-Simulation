"""Global-workspace style competition and broadcast."""
