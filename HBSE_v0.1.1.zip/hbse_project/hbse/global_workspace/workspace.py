"""A limited-capacity salience competition and broadcast buffer."""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Iterable


@dataclass(slots=True)
class WorkspaceCandidate:
    channel: str
    content: Any
    salience: float
    provenance: str
    confidence: float = 1.0

    def __post_init__(self) -> None:
        if not self.channel:
            raise ValueError("candidate channel must be non-empty")
        if not 0 <= self.salience <= 1 or not 0 <= self.confidence <= 1:
            raise ValueError("salience and confidence must be in [0, 1]")


class GlobalWorkspace:
    """Selects a few candidate items; this is a functional analogue, not consciousness."""

    def __init__(self, capacity: int = 3, history_capacity: int = 100) -> None:
        if capacity < 1 or history_capacity < 1:
            raise ValueError("workspace capacities must be positive")
        self.capacity = int(capacity)
        self.history_capacity = int(history_capacity)
        self.last_broadcast: list[dict[str, Any]] = []
        self.history: list[dict[str, Any]] = []

    def broadcast(self, candidates: Iterable[WorkspaceCandidate], *, tick: int) -> list[dict[str, Any]]:
        items = list(candidates)
        # Stable tie-breaks make repeated runs reproducible.
        items.sort(key=lambda item: (-item.salience, item.channel))
        selected = [asdict(item) | {"tick": int(tick)} for item in items[: self.capacity]]
        self.last_broadcast = selected
        self.history.extend(selected)
        self.history = self.history[-self.history_capacity :]
        return selected

    def state_dict(self) -> dict[str, Any]:
        return {"last_broadcast": self.last_broadcast, "history": self.history}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        last = state.get("last_broadcast", [])
        history = state.get("history", [])
        if not isinstance(last, list) or len(last) > self.capacity:
            raise ValueError("invalid workspace last broadcast")
        if not isinstance(history, list) or len(history) > self.history_capacity:
            raise ValueError("invalid workspace history")
        self.last_broadcast = last
        self.history = history
