"""Goal and motivation models."""
