"""Explicit, bounded goal representation for task-directed behavior."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(slots=True)
class Goal:
    goal_id: str
    description: str
    target_state: int
    priority: float = 1.0
    urgency: float = 0.0
    progress: float = 0.0
    active: bool = True
    satisfied: bool = False

    @property
    def score(self) -> float:
        return self.priority * (1.0 + max(0.0, self.urgency)) * (1.0 - 0.5 * self.progress)


class GoalSystem:
    def __init__(self, world_size: int, target_state: int | None = None) -> None:
        if world_size < 2:
            raise ValueError("world_size must be at least 2")
        target = world_size - 1 if target_state is None else target_state
        if not 0 <= target < world_size:
            raise ValueError("target_state out of range")
        self.world_size = int(world_size)
        self.goals = [Goal("reach_target", "Reach the environment's terminal state", target)]
        self.current_state = 0

    def update(self, state: int, *, done: bool = False) -> None:
        if not 0 <= state < self.world_size:
            raise ValueError("state out of range")
        self.current_state = int(state)
        for goal in self.goals:
            distance = abs(goal.target_state - state)
            max_distance = max(1, self.world_size - 1)
            goal.progress = 1.0 - distance / max_distance
            goal.satisfied = bool(done and state == goal.target_state)
            if goal.satisfied:
                goal.progress = 1.0

    def current_goal(self) -> Goal | None:
        active = [goal for goal in self.goals if goal.active and not goal.satisfied]
        return max(active, key=lambda goal: goal.score) if active else None

    def state_dict(self) -> dict[str, Any]:
        return {"world_size": self.world_size, "current_state": self.current_state, "goals": [asdict(g) for g in self.goals]}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if int(state["world_size"]) != self.world_size:
            raise ValueError("goal-system world size mismatch")
        goals = state.get("goals", [])
        if not isinstance(goals, list):
            raise ValueError("invalid goal checkpoint")
        restored = [Goal(**item) for item in goals]
        if any(not 0 <= item.target_state < self.world_size for item in restored):
            raise ValueError("goal checkpoint target out of range")
        self.goals = restored
        self.current_state = int(state["current_state"])
