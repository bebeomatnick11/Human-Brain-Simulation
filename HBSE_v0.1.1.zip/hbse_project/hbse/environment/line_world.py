"""A tiny one-dimensional navigation task for learning and regression tests."""

from __future__ import annotations
from typing import Any


class LineWorld:
    """Agent starts at 0; action 0 moves left and action 1 moves right."""

    def __init__(self, size: int = 5, *, max_steps: int = 100) -> None:
        if size < 2 or max_steps < 1:
            raise ValueError("size must be >= 2 and max_steps positive")
        self.size = int(size)
        self.max_steps = int(max_steps)
        self.position = 0
        self.steps_in_episode = 0
        self.done = False

    def observe(self) -> int:
        return self.position

    def reset(self) -> int:
        self.position = 0
        self.steps_in_episode = 0
        self.done = False
        return self.observe()

    def step(self, action: int) -> tuple[int, float, bool]:
        if self.done:
            raise RuntimeError("episode is complete; call reset before stepping again")
        if action not in (0, 1):
            raise ValueError("action must be 0 (left) or 1 (right)")
        next_position = min(self.size - 1, max(0, self.position + (1 if action == 1 else -1)))
        self.position = next_position
        self.steps_in_episode += 1
        done = self.position == self.size - 1 or self.steps_in_episode >= self.max_steps
        self.done = done
        reward = 1.0 if self.position == self.size - 1 else -0.02
        if self.steps_in_episode >= self.max_steps and self.position != self.size - 1:
            reward -= 0.1
        return self.position, reward, done

    def state_dict(self) -> dict[str, Any]:
        return {"size": self.size, "max_steps": self.max_steps, "position": self.position,
                "steps_in_episode": self.steps_in_episode, "done": self.done}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if int(state["size"]) != self.size or int(state["max_steps"]) != self.max_steps:
            raise ValueError("environment checkpoint configuration mismatch")
        position = int(state["position"])
        steps = int(state["steps_in_episode"])
        if not 0 <= position < self.size or not 0 <= steps <= self.max_steps:
            raise ValueError("invalid environment checkpoint state")
        self.position, self.steps_in_episode, self.done = position, steps, bool(state["done"])
