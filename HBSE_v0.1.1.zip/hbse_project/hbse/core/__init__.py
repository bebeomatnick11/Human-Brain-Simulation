"""Simulation scheduling, persistence, and core interfaces."""
