"""Safe, versioned JSON checkpoint storage (no pickle or executable payloads)."""

from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any

CHECKPOINT_SCHEMA_VERSION = 1


class CheckpointError(ValueError):
    """Raised when a checkpoint is malformed or from an unsupported version."""


class CheckpointStore:
    @staticmethod
    def save(path: str | Path, payload: dict[str, Any]) -> Path:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        document = {"schema_version": CHECKPOINT_SCHEMA_VERSION, "payload": payload}
        # Validate serializability before touching the destination file.
        serialized = json.dumps(document, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        temp_name: str | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=destination.parent,
                prefix=f".{destination.name}.", suffix=".tmp", delete=False,
            ) as handle:
                temp_name = handle.name
                handle.write(serialized)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, destination)
            temp_name = None
        finally:
            if temp_name is not None:
                try:
                    os.unlink(temp_name)
                except FileNotFoundError:
                    pass
        return destination

    @staticmethod
    def load(path: str | Path) -> dict[str, Any]:
        try:
            with Path(path).open("r", encoding="utf-8") as handle:
                document = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            raise CheckpointError(f"cannot read checkpoint: {exc}") from exc
        if not isinstance(document, dict):
            raise CheckpointError("checkpoint root must be an object")
        if document.get("schema_version") != CHECKPOINT_SCHEMA_VERSION:
            raise CheckpointError(f"unsupported checkpoint schema: {document.get('schema_version')!r}")
        payload = document.get("payload")
        if not isinstance(payload, dict):
            raise CheckpointError("checkpoint payload must be an object")
        return payload
