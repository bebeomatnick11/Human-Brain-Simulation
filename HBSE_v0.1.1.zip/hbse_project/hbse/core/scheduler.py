"""A deterministic, fixed-step scheduler for multi-rate simulation components."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

UpdateFunction = Callable[[dict[str, Any], float], None]


@dataclass(slots=True)
class ScheduledTask:
    name: str
    update: UpdateFunction
    priority: int = 100
    period_steps: int = 1
    enabled: bool = True


class SimulationScheduler:
    """Runs registered callbacks in a deterministic order.

    A callback gets a shared per-tick context and the cognitive tick duration in
    seconds. Fine-grained neural integration belongs inside a neural callback,
    allowing a 1 ms neural step to coexist with a slower cognitive update.
    """

    def __init__(self, dt_s: float = 0.05) -> None:
        if dt_s <= 0:
            raise ValueError("dt_s must be positive")
        self.dt_s = float(dt_s)
        self.tick = 0
        self.time_s = 0.0
        self._tasks: list[ScheduledTask] = []
        self._names: set[str] = set()

    def register(
        self,
        name: str,
        update: UpdateFunction,
        *,
        priority: int = 100,
        period_steps: int = 1,
    ) -> None:
        if not name or name in self._names:
            raise ValueError(f"task name must be non-empty and unique: {name!r}")
        if period_steps < 1:
            raise ValueError("period_steps must be at least 1")
        self._tasks.append(ScheduledTask(name, update, int(priority), int(period_steps)))
        self._tasks.sort(key=lambda item: (item.priority, item.name))
        self._names.add(name)

    def set_enabled(self, name: str, enabled: bool) -> None:
        for task in self._tasks:
            if task.name == name:
                task.enabled = bool(enabled)
                return
        raise KeyError(f"no scheduled task named {name!r}")

    @property
    def task_names(self) -> tuple[str, ...]:
        return tuple(task.name for task in self._tasks)

    def step(self, context: dict[str, Any] | None = None) -> dict[str, Any]:
        ctx = {} if context is None else context
        ctx.setdefault("tick", self.tick)
        ctx.setdefault("time_s", self.time_s)
        for task in self._tasks:
            if task.enabled and self.tick % task.period_steps == 0:
                task.update(ctx, self.dt_s)
        self.tick += 1
        self.time_s = self.tick * self.dt_s
        return ctx

    def restore_clock(self, tick: int, time_s: float | None = None) -> None:
        if tick < 0:
            raise ValueError("tick cannot be negative")
        self.tick = int(tick)
        expected = self.tick * self.dt_s
        if time_s is not None and abs(float(time_s) - expected) > 1e-8:
            raise ValueError("checkpoint time does not agree with tick and dt_s")
        self.time_s = expected
