"""Online tabular transition model with calibrated empirical surprise."""

from __future__ import annotations

from collections import defaultdict
import math
from typing import Any


class TabularWorldModel:
    """Learns P(next_state | state, action) by counting observed transitions.

    Surprise is 1 - the smoothed predictive probability assigned to the event.
    This is a task-specific predictive statistic, not a general measure of
    human surprise or a complete causal model.
    """

    def __init__(self, n_states: int, n_actions: int, *, prior_count: float = 0.5) -> None:
        if n_states < 1 or n_actions < 1 or prior_count <= 0:
            raise ValueError("model dimensions and prior_count must be positive")
        self.n_states = int(n_states)
        self.n_actions = int(n_actions)
        self.prior_count = float(prior_count)
        self.counts: dict[str, list[int]] = defaultdict(lambda: [0] * self.n_states)
        self.reward_sums: dict[str, float] = defaultdict(float)
        self.transition_totals: dict[str, int] = defaultdict(int)
        self.prediction_errors: list[float] = []

    @staticmethod
    def _key(state: int, action: int) -> str:
        return f"{int(state)}:{int(action)}"

    def predict_distribution(self, state: int, action: int) -> list[float]:
        if not 0 <= state < self.n_states or not 0 <= action < self.n_actions:
            raise ValueError("state/action out of range")
        key = self._key(state, action)
        values = self.counts[key]
        denominator = sum(values) + self.prior_count * self.n_states
        return [(value + self.prior_count) / denominator for value in values]

    def predict_next(self, state: int, action: int) -> int:
        probabilities = self.predict_distribution(state, action)
        return max(range(self.n_states), key=lambda idx: probabilities[idx])

    def surprise(self, state: int, action: int, next_state: int) -> float:
        if not 0 <= next_state < self.n_states:
            raise ValueError("next_state out of range")
        probability = self.predict_distribution(state, action)[next_state]
        return float(min(1.0, max(0.0, 1.0 - probability)))

    def observe(self, state: int, action: int, next_state: int, reward: float) -> float:
        error = self.surprise(state, action, next_state)
        key = self._key(state, action)
        self.counts[key][next_state] += 1
        self.transition_totals[key] += 1
        self.reward_sums[key] += float(reward)
        self.prediction_errors.append(error)
        if len(self.prediction_errors) > 1000:
            self.prediction_errors = self.prediction_errors[-1000:]
        return error

    def mean_recent_error(self, window: int = 100) -> float:
        values = self.prediction_errors[-max(1, window):]
        return float(sum(values) / len(values)) if values else 0.0

    def state_dict(self) -> dict[str, Any]:
        return {
            "counts": {key: list(values) for key, values in self.counts.items()},
            "reward_sums": dict(self.reward_sums),
            "transition_totals": dict(self.transition_totals),
            "prediction_errors": list(self.prediction_errors),
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        counts = state.get("counts", {})
        for key, values in counts.items():
            if len(values) != self.n_states or any(int(v) < 0 for v in values):
                raise ValueError("invalid world-model transition counts")
        self.counts = defaultdict(lambda: [0] * self.n_states, {k: [int(v) for v in vals] for k, vals in counts.items()})
        self.reward_sums = defaultdict(float, {k: float(v) for k, v in state.get("reward_sums", {}).items()})
        self.transition_totals = defaultdict(int, {k: int(v) for k, v in state.get("transition_totals", {}).items()})
        errors = [float(v) for v in state.get("prediction_errors", [])]
        if any(not math.isfinite(v) or not 0 <= v <= 1 for v in errors):
            raise ValueError("invalid world-model prediction error values")
        self.prediction_errors = errors[-1000:]
