"""World-model and cognitive-state components."""
