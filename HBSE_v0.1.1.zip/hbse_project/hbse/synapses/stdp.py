"""Pair-based spike-timing-dependent plasticity (STDP) approximation.

The rule is a configurable phenomenological learning rule, not a molecular
model of synaptic plasticity. Edge weights are stored as non-negative
magnitudes; a separate sign vector determines excitatory/inhibitory effect.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


class PairSTDP:
    def __init__(
        self,
        n_neurons: int,
        *,
        dt_ms: float = 1.0,
        tau_pre_ms: float = 20.0,
        tau_post_ms: float = 20.0,
        a_plus: float = 0.004,
        a_minus: float = 0.0045,
        min_weight: float = 0.001,
        max_weight: float = 1.0,
    ) -> None:
        if n_neurons < 1 or dt_ms <= 0 or tau_pre_ms <= 0 or tau_post_ms <= 0:
            raise ValueError("invalid STDP time or size parameter")
        if min_weight < 0 or max_weight <= min_weight:
            raise ValueError("invalid STDP weight bounds")
        self.dt_ms = float(dt_ms)
        self.tau_pre_ms = float(tau_pre_ms)
        self.tau_post_ms = float(tau_post_ms)
        self.a_plus = float(a_plus)
        self.a_minus = float(a_minus)
        self.min_weight = float(min_weight)
        self.max_weight = float(max_weight)
        self.pre_trace: FloatArray = np.zeros(n_neurons, dtype=np.float64)
        self.post_trace: FloatArray = np.zeros(n_neurons, dtype=np.float64)

    def update(
        self,
        spikes: NDArray[np.bool_],
        source: IntArray,
        target: IntArray,
        magnitudes: FloatArray,
    ) -> FloatArray:
        events = np.asarray(spikes, dtype=np.bool_)
        if events.shape != self.pre_trace.shape:
            raise ValueError("spike vector does not match STDP population")
        self.pre_trace *= np.exp(-self.dt_ms / self.tau_pre_ms)
        self.post_trace *= np.exp(-self.dt_ms / self.tau_post_ms)
        potentiation = self.a_plus * events[source] * self.post_trace[target]
        depression = self.a_minus * events[target] * self.pre_trace[source]
        updated = np.clip(magnitudes + potentiation - depression, self.min_weight, self.max_weight)
        self.pre_trace += events.astype(np.float64)
        self.post_trace += events.astype(np.float64)
        return updated

    def state_dict(self) -> dict[str, object]:
        return {"pre_trace": self.pre_trace.tolist(), "post_trace": self.post_trace.tolist()}

    def load_state_dict(self, state: dict[str, object]) -> None:
        pre = np.asarray(state["pre_trace"], dtype=np.float64)
        post = np.asarray(state["post_trace"], dtype=np.float64)
        if pre.shape != self.pre_trace.shape or post.shape != self.post_trace.shape:
            raise ValueError("STDP checkpoint trace shape mismatch")
        self.pre_trace, self.post_trace = pre, post
