"""Synaptic plasticity rules."""
