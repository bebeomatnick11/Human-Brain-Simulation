"""HBSE: a small, auditable computational brain simulation research scaffold."""

from hbse.config import BrainConfig
from hbse.simulation.engine import SimulationEngine

__version__ = "0.1.0"
__all__ = ["BrainConfig", "SimulationEngine", "__version__"]
