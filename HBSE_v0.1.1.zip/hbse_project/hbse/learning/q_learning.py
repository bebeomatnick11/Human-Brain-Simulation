"""Tabular Q-learning agent with seeded epsilon-greedy exploration."""

from __future__ import annotations

import random
from typing import Any, Sequence


class QLearningAgent:
    def __init__(
        self,
        n_states: int,
        n_actions: int,
        *,
        rng: random.Random,
        alpha: float = 0.25,
        gamma: float = 0.95,
        epsilon: float = 0.15,
        epsilon_min: float = 0.03,
        epsilon_decay: float = 0.997,
    ) -> None:
        if n_states < 1 or n_actions < 1:
            raise ValueError("n_states and n_actions must be positive")
        if not 0 < alpha <= 1 or not 0 <= gamma <= 1:
            raise ValueError("alpha must be in (0,1], gamma in [0,1]")
        if not 0 <= epsilon_min <= epsilon <= 1 or not 0 < epsilon_decay <= 1:
            raise ValueError("invalid exploration parameters")
        self.n_states = int(n_states)
        self.n_actions = int(n_actions)
        self.rng = rng
        self.alpha = float(alpha)
        self.gamma = float(gamma)
        self.epsilon = float(epsilon)
        self.epsilon_min = float(epsilon_min)
        self.epsilon_decay = float(epsilon_decay)
        self.q_values = [[0.0] * n_actions for _ in range(n_states)]
        self.update_count = 0

    def select_action(self, state: int, *, explore: bool = True, valid_actions: Sequence[int] | None = None) -> int:
        if not 0 <= state < self.n_states:
            raise ValueError("state out of range")
        actions = list(valid_actions if valid_actions is not None else range(self.n_actions))
        if not actions or any(action < 0 or action >= self.n_actions for action in actions):
            raise ValueError("valid_actions must contain legal action indices")
        if explore and self.rng.random() < self.epsilon:
            return self.rng.choice(actions)
        best = max(self.q_values[state][action] for action in actions)
        ties = [action for action in actions if abs(self.q_values[state][action] - best) <= 1e-12]
        return self.rng.choice(ties)

    def learn(self, state: int, action: int, reward: float, next_state: int, done: bool) -> float:
        if not 0 <= state < self.n_states or not 0 <= next_state < self.n_states:
            raise ValueError("state out of range")
        if not 0 <= action < self.n_actions:
            raise ValueError("action out of range")
        current = self.q_values[state][action]
        bootstrap = 0.0 if done else max(self.q_values[next_state])
        target = float(reward) + self.gamma * bootstrap
        td_error = target - current
        self.q_values[state][action] = current + self.alpha * td_error
        self.update_count += 1
        return td_error

    def end_episode(self) -> None:
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def state_dict(self) -> dict[str, Any]:
        return {"q_values": self.q_values, "epsilon": self.epsilon, "update_count": self.update_count}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        rows = state.get("q_values")
        if not isinstance(rows, list) or len(rows) != self.n_states:
            raise ValueError("Q-learning checkpoint state dimension mismatch")
        if any(not isinstance(row, list) or len(row) != self.n_actions for row in rows):
            raise ValueError("Q-learning checkpoint action dimension mismatch")
        values = [[float(v) for v in row] for row in rows]
        if any(not __import__("math").isfinite(v) for row in values for v in row):
            raise ValueError("Q-learning checkpoint contains non-finite values")
        self.q_values = values
        epsilon = float(state["epsilon"])
        if not self.epsilon_min <= epsilon <= 1:
            raise ValueError("checkpoint epsilon out of range")
        self.epsilon = epsilon
        self.update_count = int(state["update_count"])
