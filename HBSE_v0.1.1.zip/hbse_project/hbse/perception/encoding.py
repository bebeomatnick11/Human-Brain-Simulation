"""Simple population/place-code encoding for a discrete position observation."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def encode_position(
    position: int,
    world_size: int,
    n_neurons: int,
    *,
    peak_current_na: float = 2.0,
    tuning_width: float = 0.12,
) -> NDArray[np.float64]:
    """Convert a discrete position to overlapping Gaussian population activity.

    This is an engineered place-code demonstration, not a claim about the
    precise firing fields or cell types of a biological hippocampus.
    """
    if world_size < 2 or n_neurons < 1 or not 0 <= position < world_size:
        raise ValueError("invalid position/world/network dimensions")
    if peak_current_na < 0 or tuning_width <= 0:
        raise ValueError("peak_current_na must be non-negative and tuning_width positive")
    centers = np.linspace(0.0, float(world_size - 1), n_neurons)
    scale = max(tuning_width * (world_size - 1), 1e-9)
    response = np.exp(-0.5 * ((centers - float(position)) / scale) ** 2)
    return (peak_current_na * response).astype(np.float64)
