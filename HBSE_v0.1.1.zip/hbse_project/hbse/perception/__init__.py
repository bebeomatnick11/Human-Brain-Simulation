"""Low-level input encoding."""
