"""Explicitly scoped, non-anatomical registry of coarse functional hypotheses."""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True, slots=True)
class RegionSpec:
    region_id: str
    proposed_function: str
    inputs: tuple[str, ...]
    outputs: tuple[str, ...]
    model_level: str
    evidence_status: str
    limitation: str


DEFAULT_REGIONS = (
    RegionSpec("sensory_cortex", "encode and transform sensory-like input", ("environment",), ("perception", "workspace"), "abstract", "analogy", "No anatomical layers or sensory transduction model is present."),
    RegionSpec("hippocampal_memory", "support episode/context indexing", ("perception", "reward"), ("episodic_memory", "world_model"), "algorithmic", "functional_analogy", "The code stores episodes and transition counts; it is not a hippocampal microcircuit."),
    RegionSpec("prefrontal_control", "maintain the active task and bias selection", ("goals", "workspace", "memory"), ("decision",), "algorithmic", "functional_analogy", "No validated model of prefrontal subregions or long-range anatomy is implemented."),
    RegionSpec("basal_ganglia_selection", "compare candidate actions under reward feedback", ("state", "reward"), ("motor_action",), "algorithmic", "functional_analogy", "Tabular Q-learning is not a biological basal-ganglia model."),
)


class RegionRegistry:
    def __init__(self, regions: tuple[RegionSpec, ...] = DEFAULT_REGIONS) -> None:
        ids = [region.region_id for region in regions]
        if len(set(ids)) != len(ids):
            raise ValueError("region IDs must be unique")
        self._regions = {region.region_id: region for region in regions}

    def get(self, region_id: str) -> RegionSpec:
        return self._regions[region_id]

    def list_regions(self) -> list[dict[str, Any]]:
        return [asdict(region) for region in self._regions.values()]
