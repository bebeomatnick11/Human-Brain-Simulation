"""Coarse functional region registry; entries are research abstractions."""
