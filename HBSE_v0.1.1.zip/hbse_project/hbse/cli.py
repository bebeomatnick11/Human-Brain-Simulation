"""Command line interface for running and inspecting HBSE."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from hbse.benchmarks.run import run_benchmark
from hbse.config import BrainConfig
from hbse.simulation.engine import SimulationEngine


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hbse", description="Human Brain Simulation Engine prototype")
    parser.add_argument("--steps", type=int, default=300, help="cognitive ticks to execute")
    parser.add_argument("--seed", type=int, default=None, help="override configured random seed")
    parser.add_argument("--config", type=Path, default=None, help="optional JSON configuration")
    parser.add_argument("--resume", type=Path, default=None, help="resume a JSON checkpoint")
    parser.add_argument("--checkpoint", type=Path, default=None, help="save checkpoint after execution")
    parser.add_argument("--benchmark", action="store_true", help="include measured wall-clock throughput")
    parser.add_argument("--pretty", action="store_true", help="pretty-print JSON output")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.steps < 0:
        print("error: --steps must be non-negative", file=sys.stderr)
        return 2
    try:
        if args.resume:
            if args.config or args.seed is not None:
                raise ValueError("--resume uses the checkpoint configuration; do not also pass --config or --seed")
            engine = SimulationEngine.from_checkpoint(str(args.resume))
            start_tick = engine.scheduler.tick
            engine.run(args.steps)
            output = engine.metrics()
            output["resumed_from_tick"] = start_tick
        else:
            config = BrainConfig.from_json(args.config) if args.config else BrainConfig()
            if args.seed is not None:
                config = BrainConfig.from_dict(config.to_dict() | {"seed": args.seed})
            if args.benchmark:
                output = run_benchmark(args.steps, config=config) if args.steps > 0 else SimulationEngine(config).metrics()
                engine = None
            else:
                engine = SimulationEngine(config)
                engine.run(args.steps)
                output = engine.metrics()
        if args.checkpoint:
            if engine is None:
                raise ValueError("cannot save a checkpoint from benchmark-only mode; omit --benchmark or run normal mode")
            engine.save_checkpoint(str(args.checkpoint))
            output["checkpoint_path"] = str(args.checkpoint)
        print(json.dumps(output, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except (ValueError, OSError, RuntimeError, KeyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
