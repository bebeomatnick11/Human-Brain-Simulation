"""Microbenchmark: report measured runtime and behavior without hard-coded claims."""

from __future__ import annotations

import json
import time
from typing import Any

from hbse.config import BrainConfig
from hbse.simulation.engine import SimulationEngine


def run_benchmark(steps: int = 300, *, config: BrainConfig | None = None) -> dict[str, Any]:
    if steps < 1:
        raise ValueError("steps must be positive")
    engine = SimulationEngine(config or BrainConfig())
    start = time.perf_counter()
    engine.run(steps)
    elapsed = time.perf_counter() - start
    result = engine.metrics()
    result["benchmark"] = {
        "wall_time_s": round(elapsed, 6),
        "cognitive_steps_per_second": round(steps / elapsed, 3) if elapsed > 0 else None,
        "steps_requested_this_run": steps,
        "method": "single process; includes neural substeps and cognitive components; excludes startup",
    }
    return result


if __name__ == "__main__":
    print(json.dumps(run_benchmark(), ensure_ascii=False, indent=2))
