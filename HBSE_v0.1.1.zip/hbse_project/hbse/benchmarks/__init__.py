"""Reproducible performance and behavior benchmark entry points."""
