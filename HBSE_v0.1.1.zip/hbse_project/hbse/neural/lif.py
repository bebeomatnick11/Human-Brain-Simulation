"""Vectorized leaky integrate-and-fire population model.

Units: voltage in mV, time in ms, current in nA, resistance in MOhm.
This is a reduced, phenomenological model; it omits ionic channel dynamics.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]
BoolArray = NDArray[np.bool_]


class LIFPopulation:
    def __init__(
        self,
        size: int,
        *,
        dt_ms: float = 1.0,
        tau_m_ms: float = 20.0,
        resistance_mohm: float = 10.0,
        rest_mv: float = -65.0,
        reset_mv: float = -65.0,
        threshold_mv: float = -50.0,
        refractory_ms: float = 2.0,
    ) -> None:
        if size < 1 or dt_ms <= 0 or tau_m_ms <= 0 or resistance_mohm <= 0:
            raise ValueError("size and physical time/scale parameters must be positive")
        if threshold_mv <= reset_mv:
            raise ValueError("threshold_mv must be above reset_mv")
        self.size = int(size)
        self.dt_ms = float(dt_ms)
        self.tau_m_ms = float(tau_m_ms)
        self.resistance_mohm = float(resistance_mohm)
        self.rest_mv = float(rest_mv)
        self.reset_mv = float(reset_mv)
        self.threshold_mv = float(threshold_mv)
        self.refractory_ms = float(refractory_ms)
        self.voltage_mv: FloatArray = np.full(self.size, self.rest_mv, dtype=np.float64)
        self.refractory_left_ms: FloatArray = np.zeros(self.size, dtype=np.float64)
        self.spikes: BoolArray = np.zeros(self.size, dtype=np.bool_)

    def step(self, input_current_na: FloatArray) -> BoolArray:
        current = np.asarray(input_current_na, dtype=np.float64)
        if current.shape != (self.size,):
            raise ValueError(f"input_current_na must have shape ({self.size},)")
        if not np.all(np.isfinite(current)):
            raise ValueError("input current must be finite")

        refractory = self.refractory_left_ms > 0.0
        self.refractory_left_ms[refractory] = np.maximum(
            0.0, self.refractory_left_ms[refractory] - self.dt_ms
        )
        self.voltage_mv[refractory] = self.reset_mv
        active = ~refractory
        derivative = (
            -(self.voltage_mv - self.rest_mv) + self.resistance_mohm * current
        ) / self.tau_m_ms
        self.voltage_mv[active] += self.dt_ms * derivative[active]

        fired = (self.voltage_mv >= self.threshold_mv) & (self.refractory_left_ms <= 0.0)
        self.voltage_mv[fired] = self.reset_mv
        self.refractory_left_ms[fired] = self.refractory_ms
        self.spikes = fired
        return fired.copy()

    def state_dict(self) -> dict[str, object]:
        return {
            "voltage_mv": self.voltage_mv.tolist(),
            "refractory_left_ms": self.refractory_left_ms.tolist(),
            "spikes": self.spikes.astype(int).tolist(),
        }

    def load_state_dict(self, state: dict[str, object]) -> None:
        voltage = np.asarray(state["voltage_mv"], dtype=np.float64)
        refractory = np.asarray(state["refractory_left_ms"], dtype=np.float64)
        spikes = np.asarray(state["spikes"], dtype=np.bool_)
        if voltage.shape != (self.size,) or refractory.shape != (self.size,) or spikes.shape != (self.size,):
            raise ValueError("LIF checkpoint array shape mismatch")
        if not np.all(np.isfinite(voltage)) or not np.all(np.isfinite(refractory)):
            raise ValueError("LIF checkpoint contains non-finite values")
        self.voltage_mv = voltage
        self.refractory_left_ms = refractory
        self.spikes = spikes
