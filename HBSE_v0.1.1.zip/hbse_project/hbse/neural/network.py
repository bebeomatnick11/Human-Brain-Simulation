"""Sparse recurrent spiking network with delayed synaptic events."""

from __future__ import annotations

import copy
import numpy as np
from numpy.typing import NDArray

from hbse.neural.lif import LIFPopulation
from hbse.synapses.stdp import PairSTDP

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


class SpikingNetwork:
    """A small sparse LIF network suitable for experiments and unit tests.

    Connectivity is sampled once at initialization. Delays are integer neural
    time steps. Source-neuron sign determines excitatory/inhibitory effect.
    """

    def __init__(
        self,
        n_neurons: int = 64,
        *,
        seed: int = 7,
        connection_probability: float = 0.06,
        inhibitory_fraction: float = 0.2,
        dt_ms: float = 1.0,
        noise_std: float = 0.0,
        use_stdp: bool = False,
        max_delay_steps: int = 5,
    ) -> None:
        if n_neurons < 2:
            raise ValueError("n_neurons must be at least 2")
        if not 0 <= connection_probability <= 1 or not 0 <= inhibitory_fraction <= 1:
            raise ValueError("probabilities must be in [0, 1]")
        if noise_std < 0 or max_delay_steps < 1:
            raise ValueError("invalid noise or delay parameter")
        self.n_neurons = int(n_neurons)
        self.dt_ms = float(dt_ms)
        self.noise_std = float(noise_std)
        self.rng = np.random.default_rng(seed)
        self.population = LIFPopulation(n_neurons, dt_ms=dt_ms)

        mask = self.rng.random((n_neurons, n_neurons)) < connection_probability
        np.fill_diagonal(mask, False)
        self.source, self.target = (np.asarray(v, dtype=np.int64) for v in np.where(mask))
        self.inhibitory = self.rng.random(n_neurons) < inhibitory_fraction
        self.sign = np.where(self.inhibitory[self.source], -1.0, 1.0).astype(np.float64)
        self.weight_magnitude: FloatArray = self.rng.uniform(0.05, 0.25, size=len(self.source)).astype(np.float64)
        self.delays: IntArray = self.rng.integers(1, max_delay_steps + 1, size=len(self.source), dtype=np.int64)
        self.max_delay_steps = int(max_delay_steps)
        self.delay_buffer: FloatArray = np.zeros((max_delay_steps + 1, n_neurons), dtype=np.float64)
        self.step_index = 0
        self.total_spikes = 0
        self.stdp = PairSTDP(n_neurons, dt_ms=dt_ms) if use_stdp else None
        self.use_stdp = bool(use_stdp)

    @property
    def n_synapses(self) -> int:
        return int(len(self.source))

    @property
    def weights(self) -> FloatArray:
        """Return signed edge weights; modifying the returned array has no effect."""
        return self.sign * self.weight_magnitude

    def step(self, external_current_na: FloatArray | None = None) -> NDArray[np.bool_]:
        if external_current_na is None:
            external = np.zeros(self.n_neurons, dtype=np.float64)
        else:
            external = np.asarray(external_current_na, dtype=np.float64)
            if external.shape != (self.n_neurons,):
                raise ValueError(f"external_current_na must have shape ({self.n_neurons},)")
            if not np.all(np.isfinite(external)):
                raise ValueError("external current must be finite")

        slot = self.step_index % self.delay_buffer.shape[0]
        synaptic_current = self.delay_buffer[slot].copy()
        self.delay_buffer[slot].fill(0.0)
        current = external + synaptic_current
        if self.noise_std:
            current += self.rng.normal(0.0, self.noise_std, size=self.n_neurons)

        spikes = self.population.step(current)
        if self.n_synapses:
            active_edges = spikes[self.source]
            if np.any(active_edges):
                due_slots = (self.step_index + self.delays[active_edges]) % self.delay_buffer.shape[0]
                signed_weights = self.sign[active_edges] * self.weight_magnitude[active_edges]
                np.add.at(self.delay_buffer, (due_slots, self.target[active_edges]), signed_weights)
        if self.stdp is not None:
            self.weight_magnitude = self.stdp.update(
                spikes, self.source, self.target, self.weight_magnitude
            )
        self.total_spikes += int(np.count_nonzero(spikes))
        self.step_index += 1
        return spikes

    def state_dict(self) -> dict[str, object]:
        return {
            "population": self.population.state_dict(),
            "source": self.source.tolist(),
            "target": self.target.tolist(),
            "sign": self.sign.tolist(),
            "delays": self.delays.tolist(),
            "inhibitory": self.inhibitory.astype(int).tolist(),
            "weight_magnitude": self.weight_magnitude.tolist(),
            "delay_buffer": self.delay_buffer.tolist(),
            "step_index": self.step_index,
            "total_spikes": self.total_spikes,
            "rng_state": copy.deepcopy(self.rng.bit_generator.state),
            "stdp": self.stdp.state_dict() if self.stdp is not None else None,
        }

    def load_state_dict(self, state: dict[str, object]) -> None:
        source = np.asarray(state["source"], dtype=np.int64)
        target = np.asarray(state["target"], dtype=np.int64)
        sign = np.asarray(state["sign"], dtype=np.float64)
        delays = np.asarray(state["delays"], dtype=np.int64)
        inhibitory = np.asarray(state["inhibitory"], dtype=np.bool_)
        magnitudes = np.asarray(state["weight_magnitude"], dtype=np.float64)
        buffer = np.asarray(state["delay_buffer"], dtype=np.float64)
        edge_count = len(magnitudes)
        if any(array.shape != (edge_count,) for array in (source, target, sign, delays)):
            raise ValueError("network checkpoint edge arrays have inconsistent dimensions")
        if inhibitory.shape != (self.n_neurons,) or buffer.shape != self.delay_buffer.shape:
            raise ValueError("network checkpoint population/delay-buffer shape mismatch")
        if (np.any(source < 0) or np.any(source >= self.n_neurons)
                or np.any(target < 0) or np.any(target >= self.n_neurons)):
            raise ValueError("network checkpoint contains an invalid neuron index")
        if np.any(delays < 1) or np.any(delays > self.max_delay_steps):
            raise ValueError("network checkpoint contains an invalid synaptic delay")
        if np.any(~np.isin(sign, [-1.0, 1.0])):
            raise ValueError("synapse signs must be -1 or +1")
        if not np.all(np.isfinite(magnitudes)) or not np.all(np.isfinite(buffer)):
            raise ValueError("network checkpoint contains non-finite values")
        if np.any(magnitudes < 0):
            raise ValueError("synaptic magnitudes must be non-negative")
        self.population.load_state_dict(state["population"])
        self.source, self.target, self.sign, self.delays = source, target, sign, delays
        self.inhibitory = inhibitory
        self.weight_magnitude = magnitudes
        self.delay_buffer = buffer
        self.step_index = int(state["step_index"])
        self.total_spikes = int(state["total_spikes"])
        self.rng.bit_generator.state = copy.deepcopy(state["rng_state"])
        saved_stdp = state.get("stdp")
        if (saved_stdp is None) != (self.stdp is None):
            raise ValueError("checkpoint STDP setting differs from configuration")
        if self.stdp is not None and isinstance(saved_stdp, dict):
            self.stdp.load_state_dict(saved_stdp)
