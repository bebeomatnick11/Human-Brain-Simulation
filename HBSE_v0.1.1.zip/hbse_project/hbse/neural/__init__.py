"""Spiking neuron and network models."""
