"""Memory stores with explicit provenance and bounded retention."""
