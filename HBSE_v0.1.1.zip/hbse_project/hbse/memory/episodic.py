"""Bounded episodic experience log with provenance, confidence, and stable IDs."""

from __future__ import annotations

from collections import deque
from typing import Any


class EpisodicMemory:
    def __init__(self, capacity: int = 10000) -> None:
        if capacity < 1:
            raise ValueError("capacity must be positive")
        self.capacity = int(capacity)
        self._items: deque[dict[str, Any]] = deque(maxlen=capacity)
        self._next_id = 1

    def encode(
        self,
        content: dict[str, Any],
        *,
        time_s: float,
        source: str = "experienced",
        confidence: float = 1.0,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if time_s < 0 or not 0 <= confidence <= 1:
            raise ValueError("time_s must be non-negative and confidence in [0, 1]")
        item = {
            "id": self._next_id,
            "time_s": float(time_s),
            "source": str(source),
            "confidence": float(confidence),
            "content": content,
            "context": context or {},
            "retrieval_count": 0,
        }
        self._items.append(item)
        self._next_id += 1
        return item

    def retrieve(self, query: dict[str, Any], *, limit: int = 5) -> list[dict[str, Any]]:
        """Return episodes whose content shares the most queried key/value pairs."""
        if limit < 1:
            return []
        ranked: list[tuple[float, dict[str, Any]]] = []
        for item in self._items:
            content = item["content"]
            matches = sum(1 for key, value in query.items() if content.get(key) == value)
            if matches:
                score = matches / max(len(query), 1) * item["confidence"]
                ranked.append((score, item))
        ranked.sort(key=lambda pair: (pair[0], pair[1]["time_s"]), reverse=True)
        output = []
        for score, item in ranked[:limit]:
            item["retrieval_count"] += 1
            output.append({**item, "match_score": score})
        return output

    def __len__(self) -> int:
        return len(self._items)

    def state_dict(self) -> dict[str, Any]:
        return {"items": list(self._items), "next_id": self._next_id}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        items = state.get("items")
        if not isinstance(items, list) or len(items) > self.capacity:
            raise ValueError("invalid episodic-memory checkpoint")
        self._items = deque(items, maxlen=self.capacity)
        self._next_id = int(state["next_id"])
