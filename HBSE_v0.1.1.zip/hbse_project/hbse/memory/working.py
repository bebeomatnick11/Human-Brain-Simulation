"""Bounded working memory with TTL-based decay and tag-based retrieval."""

from __future__ import annotations

from collections import deque
import math
from typing import Any


class WorkingMemory:
    def __init__(self, capacity: int = 16, *, tau_s: float = 10.0, ttl_s: float = 30.0) -> None:
        if capacity < 1 or tau_s <= 0 or ttl_s <= 0:
            raise ValueError("capacity and time constants must be positive")
        self.capacity = int(capacity)
        self.tau_s = float(tau_s)
        self.ttl_s = float(ttl_s)
        self._items: deque[dict[str, Any]] = deque(maxlen=capacity)
        self._next_id = 1

    def add(
        self,
        content: Any,
        *,
        time_s: float,
        tags: list[str] | None = None,
        source: str = "observed",
        confidence: float = 1.0,
    ) -> dict[str, Any]:
        if time_s < 0 or not 0 <= confidence <= 1:
            raise ValueError("time_s must be non-negative and confidence in [0, 1]")
        item = {
            "id": self._next_id,
            "content": content,
            "time_s": float(time_s),
            "tags": list(tags or []),
            "source": str(source),
            "confidence": float(confidence),
        }
        self._next_id += 1
        self._items.append(item)
        self.expire(time_s)
        return dict(item)

    def expire(self, now_s: float) -> int:
        before = len(self._items)
        retained = [item for item in self._items if 0 <= now_s - item["time_s"] <= self.ttl_s]
        self._items = deque(retained[-self.capacity :], maxlen=self.capacity)
        return before - len(self._items)

    def retrieve(self, *, now_s: float, tags: list[str] | None = None, limit: int = 5) -> list[dict[str, Any]]:
        if limit < 1:
            return []
        self.expire(now_s)
        required = set(tags or [])
        scored: list[tuple[float, dict[str, Any]]] = []
        for item in self._items:
            if required and not required.issubset(set(item["tags"])):
                continue
            age = max(0.0, now_s - item["time_s"])
            activation = item["confidence"] * math.exp(-age / self.tau_s)
            scored.append((activation, item))
        scored.sort(key=lambda pair: (pair[0], pair[1]["time_s"]), reverse=True)
        return [{**item, "activation": score} for score, item in scored[:limit]]

    def __len__(self) -> int:
        return len(self._items)

    def state_dict(self) -> dict[str, Any]:
        return {"items": list(self._items), "next_id": self._next_id}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        items = state.get("items")
        if not isinstance(items, list) or len(items) > self.capacity:
            raise ValueError("invalid working-memory checkpoint")
        self._items = deque(items, maxlen=self.capacity)
        self._next_id = int(state["next_id"])
