"""Multi-component simulation engine."""
