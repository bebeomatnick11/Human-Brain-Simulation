"""Runnable HBSE core: multi-rate neural dynamics plus a small cognitive task."""

from __future__ import annotations

import copy
import random
from typing import Any

from hbse.cognition.world_model import TabularWorldModel
from hbse.config import BrainConfig
from hbse.core.persistence import CheckpointStore
from hbse.core.scheduler import SimulationScheduler
from hbse.environment.line_world import LineWorld
from hbse.global_workspace.workspace import GlobalWorkspace, WorkspaceCandidate
from hbse.learning.q_learning import QLearningAgent
from hbse.memory.episodic import EpisodicMemory
from hbse.memory.working import WorkingMemory
from hbse.motivation.goals import GoalSystem
from hbse.neural.network import SpikingNetwork
from hbse.perception.encoding import encode_position


def _tuple_tree(value: Any) -> Any:
    """Convert JSON-decoded nested lists back into tuples for random.setstate."""
    if isinstance(value, list):
        return tuple(_tuple_tree(item) for item in value)
    return value


class SimulationEngine:
    """Coordinates executable, observable components in deterministic phases.

    The cognitive task is deliberately small (navigation on a one-dimensional
    line). Its purpose is to verify state, learning, memory, prediction error,
    neural activity, and checkpointing end-to-end—not to claim general cognition.
    """

    CHECKPOINT_COMPONENTS = {
        "neural", "world_model", "agent", "environment", "working_memory",
        "episodic_memory", "goals", "workspace", "scheduler", "rng",
    }

    def __init__(self, config: BrainConfig | None = None) -> None:
        self.config = config or BrainConfig()
        self.rng = random.Random(self.config.seed)
        self.environment = LineWorld(self.config.world_size)
        self.world_model = TabularWorldModel(self.config.world_size, 2)
        self.agent = QLearningAgent(
            self.config.world_size, 2, rng=self.rng,
            alpha=self.config.q_learning_alpha,
            gamma=self.config.q_learning_gamma,
            epsilon=self.config.epsilon,
            epsilon_min=self.config.epsilon_min,
            epsilon_decay=self.config.epsilon_decay,
        )
        self.network = SpikingNetwork(
            self.config.num_neurons,
            seed=self.config.seed + 1009,
            connection_probability=self.config.connection_probability,
            inhibitory_fraction=self.config.inhibitory_fraction,
            dt_ms=self.config.neural_dt_ms,
            noise_std=self.config.noise_std,
            use_stdp=self.config.use_stdp,
        )
        self.working_memory = WorkingMemory(self.config.max_working_memory)
        self.episodic_memory = EpisodicMemory(self.config.episodic_memory_capacity)
        self.goals = GoalSystem(self.config.world_size)
        self.workspace = GlobalWorkspace(capacity=3, history_capacity=200)
        self.scheduler = SimulationScheduler(self.config.cognitive_dt_s)

        self.episode_return = 0.0
        self.completed_returns: list[float] = []
        self.completed_success: list[bool] = []
        self.reward_history: list[float] = []
        self._last_context: dict[str, Any] = {}
        self.scheduler.register("perception", self._update_perception, priority=10)
        self.scheduler.register("neural_dynamics", self._update_neural, priority=20)
        self.scheduler.register("decision_and_learning", self._update_decision, priority=30)
        self.scheduler.register("goal_state", self._update_goals, priority=40)
        self.scheduler.register("memory_encoding", self._update_memory, priority=50)
        self.scheduler.register("global_workspace", self._update_workspace, priority=60)

    def _update_perception(self, context: dict[str, Any], dt_s: float) -> None:
        del dt_s
        position = int(context["observation"])
        context["input_current_na"] = encode_position(
            position, self.config.world_size, self.config.num_neurons
        )
        context["input_provenance"] = "environment_observation"

    def _update_neural(self, context: dict[str, Any], dt_s: float) -> None:
        del dt_s
        total = 0
        current = context["input_current_na"]
        for _ in range(self.config.neural_substeps):
            spikes = self.network.step(current)
            total += int(spikes.sum())
        context["spike_count"] = total
        context["neural_time_ms"] = self.network.step_index * self.config.neural_dt_ms

    def _update_decision(self, context: dict[str, Any], dt_s: float) -> None:
        del dt_s
        state = int(context["observation"])
        action = self.agent.select_action(state)
        next_state, reward, done = self.environment.step(action)
        prediction_error = self.world_model.observe(state, action, next_state, reward)
        td_error = self.agent.learn(state, action, reward, next_state, done)
        self.episode_return += reward
        self.reward_history.append(reward)
        self.reward_history = self.reward_history[-1000:]
        if done:
            self.completed_returns.append(self.episode_return)
            self.completed_success.append(next_state == self.config.world_size - 1)
            self.completed_returns = self.completed_returns[-1000:]
            self.completed_success = self.completed_success[-1000:]
            self.episode_return = 0.0
            self.agent.end_episode()

        context.update({
            "action": action,
            "action_name": "left" if action == 0 else "right",
            "next_observation": next_state,
            "reward": float(reward),
            "done": bool(done),
            "prediction_error": float(prediction_error),
            "td_error": float(td_error),
            "q_values": list(self.agent.q_values[state]),
        })

    def _update_goals(self, context: dict[str, Any], dt_s: float) -> None:
        del dt_s
        self.goals.update(int(context["next_observation"]), done=bool(context["done"]))
        goal = self.goals.current_goal()
        context["goal_progress"] = max((item.progress for item in self.goals.goals), default=0.0)
        context["current_goal"] = None if goal is None else goal.goal_id

    def _update_memory(self, context: dict[str, Any], dt_s: float) -> None:
        del dt_s
        time_s = float(context["time_s"])
        episode = {
            "state": int(context["observation"]),
            "action": int(context["action"]),
            "reward": float(context["reward"]),
            "next_state": int(context["next_observation"]),
            "done": bool(context["done"]),
            "prediction_error": float(context["prediction_error"]),
        }
        self.episodic_memory.encode(
            episode,
            time_s=time_s,
            source="experienced_transition",
            confidence=1.0,
            context={"task": "line_world", "tick": int(context["tick"])},
        )
        tags = ["transition"]
        if context["reward"] > 0:
            tags.append("reward")
        if context["prediction_error"] > 0.4:
            tags.append("surprising")
        self.working_memory.add(
            episode, time_s=time_s, tags=tags,
            source="observed_transition", confidence=1.0,
        )
        self.working_memory.expire(time_s)

    def _update_workspace(self, context: dict[str, Any], dt_s: float) -> None:
        del dt_s
        position = int(context["observation"])
        candidates = [
            WorkspaceCandidate(
                "observation", {"position": position},
                salience=min(1.0, 0.25 + 0.05 * abs(position)),
                provenance="observed", confidence=1.0,
            ),
            WorkspaceCandidate(
                "prediction_error", {"value": float(context["prediction_error"])},
                salience=float(context["prediction_error"]),
                provenance="derived_from_transition", confidence=0.9,
            ),
            WorkspaceCandidate(
                "reward", {"value": float(context["reward"])},
                salience=min(1.0, abs(float(context["reward"]))),
                provenance="environment_feedback", confidence=1.0,
            ),
            WorkspaceCandidate(
                "goal_progress", {"value": float(context["goal_progress"])},
                salience=min(1.0, 0.2 + 0.7 * float(context["goal_progress"])),
                provenance="computed_from_state", confidence=0.85,
            ),
            WorkspaceCandidate(
                "action", {"action": context["action_name"]},
                salience=0.2 + 0.2 * float(context["goal_progress"]),
                provenance="agent_decision", confidence=0.8,
            ),
        ]
        context["workspace_broadcast"] = self.workspace.broadcast(candidates, tick=int(context["tick"]))
        context["working_memory_size"] = len(self.working_memory)
        context["episodic_memory_size"] = len(self.episodic_memory)

    def step(self) -> dict[str, Any]:
        """Advance one cognitive tick and return an inspectable per-tick record."""
        if self.environment.done:
            self.environment.reset()
        context: dict[str, Any] = {
            "tick": self.scheduler.tick,
            "time_s": self.scheduler.time_s,
            "observation": self.environment.observe(),
        }
        self._last_context = self.scheduler.step(context)
        return dict(self._last_context)

    def run(self, steps: int) -> dict[str, Any]:
        if steps < 0:
            raise ValueError("steps must be non-negative")
        for _ in range(steps):
            self.step()
        return self.metrics()

    def metrics(self) -> dict[str, Any]:
        recent_success = self.completed_success[-20:]
        recent_returns = self.completed_returns[-20:]
        recent_rewards = self.reward_history[-100:]
        return {
            "engine": "HBSE",
            "scope": "prototype; not a whole-human-brain reconstruction",
            "simulation_steps": self.scheduler.tick,
            "simulation_time_s": round(self.scheduler.time_s, 6),
            "neural_time_ms": round(self.network.step_index * self.config.neural_dt_ms, 6),
            "neurons": self.network.n_neurons,
            "synapses": self.network.n_synapses,
            "spikes_total": self.network.total_spikes,
            "q_updates": self.agent.update_count,
            "epsilon": round(self.agent.epsilon, 6),
            "episodes_completed": len(self.completed_returns),
            "success_rate_last_20_episodes": (
                round(sum(recent_success) / len(recent_success), 4) if recent_success else None
            ),
            "mean_return_last_20_episodes": (
                round(sum(recent_returns) / len(recent_returns), 4) if recent_returns else None
            ),
            "mean_reward_last_100_steps": (
                round(sum(recent_rewards) / len(recent_rewards), 5) if recent_rewards else None
            ),
            "mean_prediction_error_last_100": round(self.world_model.mean_recent_error(100), 5),
            "working_memory_items": len(self.working_memory),
            "episodic_memory_items": len(self.episodic_memory),
            "workspace_broadcast_count": len(self.workspace.last_broadcast),
            "stdp_enabled": self.network.use_stdp,
        }

    def snapshot(self) -> dict[str, Any]:
        return {
            "config": self.config.to_dict(),
            "scheduler": {"tick": self.scheduler.tick, "time_s": self.scheduler.time_s},
            "rng": list(self.rng.getstate()),
            "neural": self.network.state_dict(),
            "world_model": self.world_model.state_dict(),
            "agent": self.agent.state_dict(),
            "environment": self.environment.state_dict(),
            "working_memory": self.working_memory.state_dict(),
            "episodic_memory": self.episodic_memory.state_dict(),
            "goals": self.goals.state_dict(),
            "workspace": self.workspace.state_dict(),
            "episode_return": self.episode_return,
            "completed_returns": self.completed_returns,
            "completed_success": self.completed_success,
            "reward_history": self.reward_history,
        }

    def restore(self, snapshot: dict[str, Any]) -> None:
        required = {"config", "scheduler", "rng"} | self.CHECKPOINT_COMPONENTS
        # scheduler is present both as clock and as a component marker; validate the actual payload keys.
        missing = required - set(snapshot)
        if missing:
            raise ValueError(f"checkpoint missing components: {sorted(missing)}")
        checkpoint_config = BrainConfig.from_dict(snapshot["config"])
        if checkpoint_config.to_dict() != self.config.to_dict():
            raise ValueError("checkpoint configuration differs from current engine configuration")
        self.network.load_state_dict(snapshot["neural"])
        self.world_model.load_state_dict(snapshot["world_model"])
        self.agent.load_state_dict(snapshot["agent"])
        self.environment.load_state_dict(snapshot["environment"])
        self.working_memory.load_state_dict(snapshot["working_memory"])
        self.episodic_memory.load_state_dict(snapshot["episodic_memory"])
        self.goals.load_state_dict(snapshot["goals"])
        self.workspace.load_state_dict(snapshot["workspace"])
        scheduler_state = snapshot["scheduler"]
        self.scheduler.restore_clock(int(scheduler_state["tick"]), float(scheduler_state["time_s"]))
        self.rng.setstate(_tuple_tree(snapshot["rng"]))
        self.episode_return = float(snapshot.get("episode_return", 0.0))
        self.completed_returns = [float(v) for v in snapshot.get("completed_returns", [])][-1000:]
        self.completed_success = [bool(v) for v in snapshot.get("completed_success", [])][-1000:]
        self.reward_history = [float(v) for v in snapshot.get("reward_history", [])][-1000:]
        if len(self.completed_returns) != len(self.completed_success):
            raise ValueError("checkpoint episode return/success history length mismatch")
        if any(not -1000.0 <= value <= 1000.0 for value in self.completed_returns + self.reward_history):
            raise ValueError("checkpoint reward value outside allowed range")

    def save_checkpoint(self, path: str) -> str:
        return str(CheckpointStore.save(path, self.snapshot()))

    @classmethod
    def from_checkpoint(cls, path: str) -> "SimulationEngine":
        payload = CheckpointStore.load(path)
        config_values = payload.get("config")
        if not isinstance(config_values, dict):
            raise ValueError("checkpoint configuration is missing")
        engine = cls(BrainConfig.from_dict(config_values))
        engine.restore(payload)
        return engine
