"""Configuration validation for HBSE."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class BrainConfig:
    seed: int = 7
    num_neurons: int = 64
    connection_probability: float = 0.06
    inhibitory_fraction: float = 0.2
    neural_dt_ms: float = 1.0
    neural_substeps: int = 50
    cognitive_dt_s: float = 0.05
    max_working_memory: int = 16
    episodic_memory_capacity: int = 10000
    q_learning_alpha: float = 0.25
    q_learning_gamma: float = 0.95
    epsilon: float = 0.15
    epsilon_min: float = 0.03
    epsilon_decay: float = 0.997
    world_size: int = 5
    noise_std: float = 0.0
    use_stdp: bool = False

    def __post_init__(self) -> None:
        if self.seed < 0:
            raise ValueError("seed must be non-negative")
        if self.num_neurons < 2:
            raise ValueError("num_neurons must be at least 2")
        if not 0.0 <= self.connection_probability <= 1.0:
            raise ValueError("connection_probability must be in [0, 1]")
        if not 0.0 <= self.inhibitory_fraction <= 1.0:
            raise ValueError("inhibitory_fraction must be in [0, 1]")
        if self.neural_dt_ms <= 0 or self.neural_substeps < 1:
            raise ValueError("neural_dt_ms and neural_substeps must be positive")
        if self.cognitive_dt_s <= 0:
            raise ValueError("cognitive_dt_s must be positive")
        if self.max_working_memory < 1 or self.episodic_memory_capacity < 1:
            raise ValueError("memory capacities must be positive")
        if not 0 < self.q_learning_alpha <= 1:
            raise ValueError("q_learning_alpha must be in (0, 1]")
        if not 0 <= self.q_learning_gamma <= 1:
            raise ValueError("q_learning_gamma must be in [0, 1]")
        if not 0 <= self.epsilon <= 1 or not 0 <= self.epsilon_min <= 1:
            raise ValueError("epsilon values must be in [0, 1]")
        if self.epsilon_min > self.epsilon:
            raise ValueError("epsilon_min cannot exceed epsilon")
        if not 0 < self.epsilon_decay <= 1:
            raise ValueError("epsilon_decay must be in (0, 1]")
        if self.world_size < 2:
            raise ValueError("world_size must be at least 2")
        if self.noise_std < 0:
            raise ValueError("noise_std cannot be negative")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "BrainConfig":
        allowed = set(cls.__dataclass_fields__)
        unknown = set(values) - allowed
        if unknown:
            raise ValueError(f"unknown configuration keys: {sorted(unknown)}")
        return cls(**values)

    @classmethod
    def from_json(cls, path: str | Path) -> "BrainConfig":
        with Path(path).open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        if not isinstance(value, dict):
            raise ValueError("configuration root must be a JSON object")
        return cls.from_dict(value)
