# HBSE v0.1.0 — validation run record

These are observations from the container run used to package this version, not performance guarantees for other computers.

## Environment

- Python: 3.13.5
- Platform: Linux x86_64 (`Linux-6.18.44-x86_64-with-glibc2.41`)
- NumPy: 2.3.5
- GPU: not used

## Automated tests

Command: `python -m pytest`

Result: **13 passed in 0.06 s**.

The suite covers configuration validation, stable scheduler ordering/periods, LIF input validation and firing, seeded network determinism, STDP traces and weight bounds, Q-value updates, working-memory TTL/tag retrieval, predictive-model error, episodic provenance, goal progress, workspace competition, integrated scheduler/network/memory updates, checkpoint-resume equivalence, and checkpoint schema rejection.

`python -m compileall -q hbse tests` also completed successfully.

## Measured 120-tick run

Command: `run_benchmark(steps=120, config=BrainConfig())`

| Metric | Observed value |
|---|---:|
| Cognitive ticks | 120 |
| Elapsed wall time | 0.135808 s |
| Throughput | 883.598 cognitive ticks/s |
| Neurons | 64 |
| Synapses | 249 |
| Spikes | 1,096 |
| Q updates | 120 |
| Completed line-world episodes | 21 |
| Success rate of last 20 episodes | 1.0 |
| Mean return of last 20 episodes | 0.923 |
| Mean predictive error, last 100 transitions | 0.18284 |

This is a single seeded run in a small task with an uncomplicated optimal policy. It does not establish general learning, human-level reasoning, biological accuracy, or whole-brain reconstruction. Runtime will change with CPU, interpreter, NumPy version, parameters, and system load.

## Checkpoint smoke test

Saved a checkpoint after 20 ticks and resumed for 5 ticks. The CLI reported 25 total ticks and 25 Q updates. An automated test separately confirms that a split 12+13-tick run produces the same metrics, Q table, and latest broadcast as an uninterrupted 25-tick run under the tested deterministic configuration.
