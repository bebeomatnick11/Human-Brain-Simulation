# HBSE — Giai đoạn 1: Đánh giá khoa học, kiến trúc, lộ trình

## 1. Mục tiêu khoa học
Xây dựng nền tảng mô phỏng **nhiều cấp độ** các cơ chế thần kinh–nhận thức, mỗi cơ chế là mô hình tính toán có thể kiểm thử và đo lường.
Đây **không** phải bản sao não người và **không** tuyên bố có ý thức hay trải nghiệm chủ quan.

## 2. Đánh giá tính khả thi
| Nhóm cơ chế | Trạng thái | Ghi chú |
|---|---|---|
| Neuron spiking (Izhikevich), synapse E/I có trễ, STDP | **Đã triển khai (GĐ2)** | Mô hình hiện tượng luận, không phải Hodgkin–Huxley |
| Điều biến thần kinh (dopamine/noradrenaline) | **Triển khai một phần** | Chỉ là *độ lợi chức năng* (RPE→tốc độ học, bất ngờ→nhiễu/khám phá). Chưa có đặc thù vùng/thụ thể |
| Bộ nhớ làm việc, episodic (nguồn gốc, quên lũy thừa, tái củng cố) | **Đã triển khai (GĐ2)** | Semantic/procedural/spatial/prospective: GĐ3 |
| Mô hình thế giới dự đoán + sai số dự đoán | **Đã triển khai (GĐ2)** | Bảng rời rạc; chưa có mô hình sinh |
| Nội cân bằng, mục tiêu, học tăng cường | **Đã triển khai (GĐ2)** | Phần thưởng = giảm drive (homeostatic RL) |
| Cơ thể ảo tối thiểu + nội cảm | **Đã triển khai (GĐ2)** | 2 biến; không có cảm giác |
| Lưu/phục hồi bit-exact, ngân sách tài nguyên, kiểm tra toàn vẹn | **Đã triển khai (GĐ2)** | JSON + NPZ + SHA-256, không dùng pickle |
| Cảm xúc (valence/arousal/dominance, appraisal), nhân cách, nhận thức xã hội | Kế hoạch GĐ3 | Mô hình tính toán, không phải bằng chứng cảm xúc chủ quan |
| Vùng não chức năng (hạch nền, hồi hải mã, hạnh nhân…) | Kế hoạch GĐ3–4 | Mô hình chức năng, không phải bản sao giải phẫu |
| Giấc ngủ/củng cố, tưởng tượng, global workspace, self-model | Kế hoạch GĐ3–5 | Chỉ là tương tự tính toán |
| Ý thức chủ quan, qualia, cảm giác đau/đói thật | **Không thể xác nhận** | Câu hỏi khoa học mở; hệ thống không tuyên bố |
| Mô phỏng ~8.6×10^10 neuron / ~10^14 synapse chi tiết | **Ngoài khả năng hiện tại** | Không có đủ dữ liệu connectome người, cũng không đủ phần cứng |

## 3. Kiến trúc tổng thể (tier)
- **Tier 1** nhận thức/hành vi cấp cao: Q-learning, mô hình thế giới, nội cân bằng, mục tiêu *(đang điều khiển hành vi)*.
- **Tier 2** mạng neuron trừu tượng *(GĐ3)*.
- **Tier 3** spiking + synapse động: `neural/`, `synapses/` *(chạy song song, chịu điều biến; chưa nằm trong vòng điều khiển hành vi)*.
- **Tier 4** đa vùng não *(GĐ4)*. **Tier 5** chi tiết sinh học theo dữ liệu *(GĐ4+)*.

Tick = 1 ms. `Scheduler` gọi từng tác vụ theo chu kỳ riêng (mạng: mỗi tick; tác tử: mỗi 10 tick).
Luồng tín hiệu: quan sát + nội cảm → trạng thái → chọn mục tiêu → chọn hành động → môi trường → cơ thể → phần thưởng nội cân bằng → sai số TD (dopamine-proxy) và bất ngờ (noradrenaline-proxy) → điều biến mạng spiking, mức khám phá → WM → củng cố sang episodic.

## 4. Cấu trúc thư mục
Xem `hbse/`. Các thư mục đã có mã: `neural/ synapses/ cognition/ memory/ motivation/ learning/ virtual_body/ environment/ simulation/ security/ benchmarks/` và `tests/`. Các thư mục còn trống (`emotion/ personality/ social_cognition/ sleep/ imagination/ global_workspace/ self_model/ decision/ motor_control/ brain_regions/ perception/ attention/ visualization/ api/ data/`) là chỗ dành cho GĐ3+, **chưa có chức năng**.

## 5. Công nghệ
Python 3.12 + NumPy (vector hóa, thưa ở mức mặt nạ). Không cần API key, không cần mạng, không cần GPU. Lý do: tái lập dễ, phụ thuộc tối thiểu. GPU/Numba/NEST/Brian2 là adapter tùy chọn ở GĐ4.

## 6. Phần cứng
Đo trên 1 vCPU, 4 GB RAM (xem `benchmark_results.json`). Mạng 200 neuron chạy nhanh hơn thời gian thực.

## 7. Lộ trình
GĐ2 (xong) → GĐ3 cảm xúc/nhân cách/semantic memory/quyết định đa tiêu chí → GĐ4 đóng vòng điều khiển bằng mạng spiking, đa vùng, synapse chi tiết → GĐ5 kiểm chứng rộng, so với đường cơ sở → GĐ6 mở rộng theo số đo.

## 8. Giới hạn đã biết (GĐ2)
1. Hành vi do Q-learning bảng, **chưa do mạng spiking**.
2. Môi trường lưới nhỏ; kết quả học không suy ra được cho nhận thức người.
3. STDP dùng thời điểm spike không trễ; chỉ E→E dẻo; không có cân bằng nội môi synapse.
4. Phần thưởng tò mò dùng độ mới (đếm thăm), không dùng surprisal (tránh noisy-TV).
5. Ablation (mục benchmark) cho thấy cơ chế nào thực sự giúp ích; cơ chế không giúp ích được ghi nhận đúng như vậy.
