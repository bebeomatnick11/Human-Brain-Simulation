"""Giới hạn tài nguyên: mô phỏng dừng khi hết ngân sách (tick hoặc thời gian thực), không tự mở rộng quyền."""
from __future__ import annotations
import time


class BudgetExceeded(Exception):
    pass


class ResourceBudget:
    def __init__(self, max_ticks: int | None = None, max_wall_s: float | None = None):
        self.max_ticks, self.max_wall_s = max_ticks, max_wall_s
        self._t0 = time.perf_counter()
        self.ticks_used = 0

    def charge(self, ticks: int = 1) -> None:
        self.ticks_used += ticks
        if self.max_ticks is not None and self.ticks_used > self.max_ticks:
            raise BudgetExceeded(f"vượt ngân sách tick ({self.max_ticks})")
        if self.max_wall_s is not None and time.perf_counter() - self._t0 > self.max_wall_s:
            raise BudgetExceeded(f"vượt ngân sách thời gian ({self.max_wall_s}s)")
