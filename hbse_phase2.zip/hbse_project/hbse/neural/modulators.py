"""Điều biến thần kinh dạng 'độ lợi' (gain). ĐÂY LÀ TƯƠNG TỰ CHỨC NĂNG, không phải mô hình thụ thể.
- dopamine: xung theo sai số dự đoán phần thưởng (RPE) -> nhân tốc độ học STDP.
- noradrenaline: xung theo sự bất ngờ của mô hình thế giới -> nhân biên độ nhiễu nền và mức khám phá.
Chưa có đặc thù theo vùng não/loại thụ thể (xem docs: giới hạn)."""
from __future__ import annotations
import math
import numpy as np


class Neuromodulators:
    def __init__(self, tau_da: float = 15.0, tau_ne: float = 30.0):
        self.tau_da, self.tau_ne = tau_da, tau_ne
        self.dopamine = 1.0
        self.noradrenaline = 1.0

    def dopamine_pulse(self, rpe: float) -> None:
        self.dopamine = float(np.clip(self.dopamine + 0.5 * math.tanh(rpe), 0.2, 3.0))

    def surprise_pulse(self, surprise_norm: float) -> None:
        self.noradrenaline = float(np.clip(self.noradrenaline + 0.5 * surprise_norm, 0.5, 2.5))

    def decay(self) -> None:
        self.dopamine = 1.0 + (self.dopamine - 1.0) * math.exp(-1.0 / self.tau_da)
        self.noradrenaline = 1.0 + (self.noradrenaline - 1.0) * math.exp(-1.0 / self.tau_ne)

    def state_dict(self) -> dict:
        return {"dopamine": self.dopamine, "noradrenaline": self.noradrenaline}

    def load_state_dict(self, s: dict) -> None:
        self.dopamine, self.noradrenaline = float(s["dopamine"]), float(s["noradrenaline"])
