"""Quần thể neuron Izhikevich (2003): RS cho kích thích, FS cho ức chế.
Mô hình spiking hiệu quả về tính toán; KHÔNG phải mô hình Hodgkin-Huxley chi tiết."""
from __future__ import annotations
import numpy as np


class IzhikevichPopulation:
    def __init__(self, n_exc: int, n_inh: int, rng: np.random.Generator):
        self.n_exc, self.n_inh, self.n = n_exc, n_inh, n_exc + n_inh
        re, ri = rng.random(n_exc), rng.random(n_inh)
        self.a = np.concatenate([0.02 * np.ones(n_exc), 0.02 + 0.08 * ri])
        self.b = np.concatenate([0.2 * np.ones(n_exc), 0.25 - 0.05 * ri])
        self.c = np.concatenate([-65.0 + 15.0 * re ** 2, -65.0 * np.ones(n_inh)])
        self.d = np.concatenate([8.0 - 6.0 * re ** 2, 2.0 * np.ones(n_inh)])
        self.v = -65.0 * np.ones(self.n)
        self.u = self.b * self.v

    def step(self, current: np.ndarray, dt: float = 1.0) -> np.ndarray:
        v = self.v
        for _ in range(2):  # hai nửa bước cho phương trình v để ổn định số
            v = v + 0.5 * dt * (0.04 * v * v + 5.0 * v + 140.0 - self.u + current)
        v = np.minimum(v, 30.0)
        u = self.u + dt * self.a * (self.b * v - self.u)
        fired = v >= 30.0
        self.v = np.where(fired, self.c, v)
        self.u = np.where(fired, u + self.d, u)
        return fired

    def state_dict(self) -> dict:
        return {"v": self.v.copy(), "u": self.u.copy()}

    def load_state_dict(self, s: dict) -> None:
        self.v, self.u = np.array(s["v"]), np.array(s["u"])
