"""Mạng spiking E/I có độ trễ + STDP. Tier 3 trong lộ trình."""
from __future__ import annotations
import numpy as np
from ..config import NetConfig
from .izhikevich import IzhikevichPopulation
from ..synapses.delayed_stdp import DelayedSTDPSynapses


class SpikingNetwork:
    def __init__(self, cfg: NetConfig, rng: np.random.Generator):
        self.cfg, self.rng = cfg, rng
        self.pop = IzhikevichPopulation(cfg.n_exc, cfg.n_inh, rng)
        self.syn = DelayedSTDPSynapses(cfg.n_exc, cfg.n_inh, cfg, rng)
        self.n = self.pop.n
        self.ticks = 0
        self.count_exc = 0
        self.count_inh = 0
        self.last_spikes = np.zeros(self.n, dtype=bool)

    def step(self, ext_current=0.0, noise_gain: float = 1.0, lr_scale: float = 1.0) -> np.ndarray:
        c = self.cfg
        noise = self.rng.standard_normal(self.n)
        noise[:c.n_exc] *= c.noise_exc
        noise[c.n_exc:] *= c.noise_inh
        I = noise * noise_gain + self.syn.input_current() + ext_current
        spikes = self.pop.step(I)
        if c.plasticity:
            self.syn.apply_stdp(spikes, lr_scale)
            if (self.ticks + 1) % c.homeostasis_period == 0:
                self.syn.homeostatic_scaling()
        self.syn.record(spikes)
        self.ticks += 1
        self.count_exc += int(spikes[:c.n_exc].sum())
        self.count_inh += int(spikes[c.n_exc:].sum())
        self.last_spikes = spikes
        return spikes

    def mean_rates_hz(self) -> tuple:
        sec = max(self.ticks, 1) / 1000.0
        return (self.count_exc / self.cfg.n_exc / sec, self.count_inh / self.cfg.n_inh / sec)

    def state_dict(self) -> dict:
        return {"pop": self.pop.state_dict(), "syn": self.syn.state_dict(), "ticks": self.ticks,
                "count_exc": self.count_exc, "count_inh": self.count_inh,
                "rng": self.rng.bit_generator.state, "last_spikes": self.last_spikes.copy()}

    def load_state_dict(self, s: dict) -> None:
        self.pop.load_state_dict(s["pop"]); self.syn.load_state_dict(s["syn"])
        self.ticks, self.count_exc, self.count_inh = int(s["ticks"]), int(s["count_exc"]), int(s["count_inh"])
        self.rng.bit_generator.state = s["rng"]
        self.last_spikes = np.array(s["last_spikes"], dtype=bool)
