"""Môi trường lưới ngẫu nhiên: thức ăn tái sinh, vùng nguy hiểm, hành động có thể bị trượt.
Hành động: 0=lên 1=xuống 2=trái 3=phải 4=ăn. Quan sát: (ô, thức_ăn_sẵn_sàng) mã hóa thành 1 số nguyên."""
from __future__ import annotations
import numpy as np
from ..config import EnvConfig

MOVES = {0: (-1, 0), 1: (1, 0), 2: (0, -1), 3: (0, 1)}


class GridWorld:
    n_actions = 5

    def __init__(self, cfg: EnvConfig):
        self.cfg, self.size = cfg, cfg.size
        self.food = tuple(cfg.food)
        self.hazards = {tuple(h) for h in cfg.hazards}
        self.n_states = cfg.size * cfg.size * 2
        self.pos = [0, 0]
        self.food_ready = True
        self.steps = 0

    def obs(self) -> int:
        return (self.pos[0] * self.size + self.pos[1]) * 2 + int(self.food_ready)

    def cell(self) -> int:
        return self.pos[0] * self.size + self.pos[1]

    def reset(self, rng: np.random.Generator) -> int:
        while True:
            p = [int(rng.integers(0, self.size)), int(rng.integers(0, self.size))]
            if tuple(p) not in self.hazards:
                break
        self.pos, self.food_ready, self.steps = p, True, 0
        return self.obs()

    def step(self, action: int, rng: np.random.Generator) -> dict:
        c = self.cfg
        slipped = moved = ate = False
        if action < 4 and rng.random() < c.slip:
            action, slipped = int(rng.integers(0, 4)), True
        if action < 4:
            dr, dc = MOVES[action]
            nr = min(max(self.pos[0] + dr, 0), self.size - 1)
            nc = min(max(self.pos[1] + dc, 0), self.size - 1)
            moved = [nr, nc] != self.pos
            self.pos = [nr, nc]
        elif tuple(self.pos) == self.food and self.food_ready:
            ate, self.food_ready = True, False
        if not ate and not self.food_ready and rng.random() < c.regrow_p:
            self.food_ready = True
        self.steps += 1
        return {"obs": self.obs(), "moved": moved, "ate": ate, "slipped": slipped,
                "hazard": tuple(self.pos) in self.hazards}

    def state_dict(self) -> dict:
        return {"pos": list(self.pos), "food_ready": self.food_ready, "steps": self.steps}

    def load_state_dict(self, s: dict) -> None:
        self.pos, self.food_ready, self.steps = list(s["pos"]), bool(s["food_ready"]), int(s["steps"])
