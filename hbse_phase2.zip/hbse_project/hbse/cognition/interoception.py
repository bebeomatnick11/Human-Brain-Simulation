"""Nội cảm tối thiểu: tác tử 'cảm nhận' năng lượng cơ thể mô phỏng qua 3 mức rời rạc (thấp/trung bình/cao).
Không có nội cảm thì giá trị của hành động 'ăn' không thể phụ thuộc trạng thái cơ thể (quan sát bán phần)."""
N_BINS = 3


def energy_bin(energy: float) -> int:
    return 0 if energy < 0.4 else (1 if energy < 0.7 else 2)


def encode_state(env_obs: int, energy: float) -> int:
    return env_obs * N_BINS + energy_bin(energy)
