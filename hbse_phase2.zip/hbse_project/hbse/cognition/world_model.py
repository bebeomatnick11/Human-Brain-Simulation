"""Mô hình thế giới dự đoán: P(s'|s,a) ước lượng bằng đếm Dirichlet. Sai số dự đoán = surprisal (nat).
Giới hạn: bảng rời rạc, chỉ phù hợp quan sát rời rạc; nhiễu ngẫu nhiên của môi trường cũng tạo 'bất ngờ'
(vấn đề noisy-TV) nên phần thưởng tò mò dùng độ mới (đếm thăm), không dùng surprisal."""
from __future__ import annotations
import math
import numpy as np


class WorldModel:
    def __init__(self, n_states: int, n_actions: int, prior: float = 0.1):
        self.S, self.A, self.prior = n_states, n_actions, prior
        self.counts = np.zeros((n_states, n_actions, n_states))

    def predict(self, s: int, a: int) -> np.ndarray:
        c = self.counts[s, a] + self.prior
        return c / c.sum()

    def surprise(self, s: int, a: int, s2: int) -> float:
        return float(-math.log(self.predict(s, a)[s2]))

    def update(self, s: int, a: int, s2: int) -> float:
        """Trả về surprisal chuẩn hóa về [0,1] (chia cho log S), rồi cập nhật mô hình."""
        sur = self.surprise(s, a, s2) / math.log(self.S)
        self.counts[s, a, s2] += 1.0
        return min(sur, 1.0)

    def visits(self, s: int, a: int) -> float:
        return float(self.counts[s, a].sum())

    def novelty(self, s: int) -> float:
        return float(np.mean(1.0 / np.sqrt(self.counts[s].sum(axis=1) + 1.0)))

    def entropy(self, s: int, a: int) -> float:
        p = self.predict(s, a)
        return float(-(p * np.log(p)).sum())

    def state_dict(self) -> dict:
        return {"counts": self.counts.copy()}

    def load_state_dict(self, s: dict) -> None:
        self.counts = np.array(s["counts"])
