"""Cơ thể ảo tối thiểu: hai biến nội cân bằng (năng lượng, toàn vẹn). Là biến mô phỏng, không có cảm giác."""
from __future__ import annotations
import numpy as np
from ..config import BodyConfig


class VirtualBody:
    def __init__(self, cfg: BodyConfig):
        self.cfg = cfg
        self.energy, self.integrity = cfg.energy_setpoint, cfg.integrity_setpoint

    def reset(self) -> None:
        self.energy, self.integrity = self.cfg.energy_setpoint, self.cfg.integrity_setpoint

    def levels(self) -> np.ndarray:
        return np.array([self.energy, self.integrity])

    def update(self, moved: bool, ate: bool, hazard: bool) -> None:
        c = self.cfg
        e = self.energy - c.metabolic_rate - (c.move_cost if moved else 0.0) + (c.eat_gain if ate else 0.0)
        i = self.integrity - c.hazard_damage if hazard else self.integrity + c.integrity_regen
        self.energy, self.integrity = float(min(max(e, 0.0), 1.0)), float(min(max(i, 0.0), 1.0))

    @property
    def alive(self) -> bool:
        return self.energy > 0.0 and self.integrity > 0.0

    def state_dict(self) -> dict:
        return {"energy": self.energy, "integrity": self.integrity}

    def load_state_dict(self, s: dict) -> None:
        self.energy, self.integrity = float(s["energy"]), float(s["integrity"])
