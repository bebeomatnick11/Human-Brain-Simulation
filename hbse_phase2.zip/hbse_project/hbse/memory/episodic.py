"""Bộ nhớ episodic: mỗi bản ghi có nguồn gốc (observed/inferred/imagined), độ tin cậy, ngữ cảnh vector,
độ ổn định. Quên = độ mạnh suy giảm theo luật lũy thừa; bản ghi yếu chỉ bị ARCHIVE (đảo ngược được), không bị xóa.
Truy xuất = độ tương đồng cosine x độ mạnh; nhớ lại -> tái củng cố (tăng độ ổn định).
Hiệu năng: ngữ cảnh/độ ổn định/lần truy cập cuối giữ trong mảng NumPy tăng dung lượng gấp đôi (truy xuất vector hóa)."""
from __future__ import annotations
import numpy as np

SOURCES = ("observed", "inferred", "imagined")


class EpisodicMemory:
    def __init__(self, dim: int, tau: float = 200.0, power: float = 0.5, reconsolidation_gain: float = 1.3,
                 stability_cap: float = 1e4):
        self.dim, self.tau, self.power, self.gain = dim, tau, power, reconsolidation_gain
        self.stability_cap = stability_cap
        self.records: list = []
        self._alloc(64)

    def _alloc(self, cap: int) -> None:
        n = len(self.records)
        old = getattr(self, "_buf", None)
        self._buf = np.zeros((cap, self.dim)); self._norm = np.zeros(cap)
        self._stab = np.ones(cap); self._last = np.zeros(cap); self._arch = np.zeros(cap, dtype=bool)
        if old is not None and n:
            self._buf[:n], self._norm[:n] = old[:n], self._norm_old[:n]
            self._stab[:n], self._last[:n], self._arch[:n] = self._stab_old[:n], self._last_old[:n], self._arch_old[:n]

    def _grow(self) -> None:
        self._norm_old, self._stab_old, self._last_old, self._arch_old = self._norm, self._stab, self._last, self._arch
        self._alloc(len(self._buf) * 2)

    def encode(self, content: dict, context, t: int, source: str = "observed",
               confidence: float = 1.0, salience: float = 1.0) -> int:
        assert source in SOURCES, f"source phải thuộc {SOURCES}"
        ctx = np.asarray(context, dtype=float)
        assert ctx.shape == (self.dim,)
        rid = len(self.records)
        if rid >= len(self._buf):
            self._grow()
        self.records.append({"id": rid, "content": content, "t": int(t), "source": source,
                             "confidence": float(confidence), "salience": float(salience),
                             "stability": 1.0 + float(salience), "last_access": int(t),
                             "retrievals": 0, "archived": False, "links": []})
        self._buf[rid], self._norm[rid] = ctx, np.linalg.norm(ctx)
        self._stab[rid], self._last[rid], self._arch[rid] = 1.0 + float(salience), int(t), False
        return rid

    def _strengths(self, now: int, n: int) -> np.ndarray:
        age = np.maximum(0.0, now - self._last[:n])
        return (1.0 + age / (self.tau * self._stab[:n])) ** (-self.power)

    def strength(self, rec: dict, now: int) -> float:
        age = max(0, now - rec["last_access"])
        return float((1.0 + age / (self.tau * rec["stability"])) ** (-self.power))

    def retrieve(self, cue, now: int, k: int = 3, include_archived: bool = False, noise: float = 0.0,
                 rng: np.random.Generator | None = None, reconsolidate: bool = True) -> list:
        n = len(self.records)
        if n == 0:
            return []
        q = np.asarray(cue, dtype=float)
        if noise > 0:
            q = q + rng.normal(0.0, noise, q.shape)
        sims = self._buf[:n] @ q / (self._norm[:n] * np.linalg.norm(q) + 1e-12)
        st = self._strengths(now, n)
        scores = np.where(include_archived | ~self._arch[:n], sims * st, -np.inf)
        k = min(k, n)
        top = np.argpartition(-scores, k - 1)[:k]
        top = top[np.argsort(-scores[top])]
        out = []
        for i in top:
            if not np.isfinite(scores[i]):
                break
            r = self.records[i]
            out.append((float(sims[i]), float(st[i]), dict(r)))
            if reconsolidate:
                r["stability"] = min(r["stability"] * self.gain, self.stability_cap)
                r["last_access"], r["retrievals"] = int(now), r["retrievals"] + 1
                self._stab[i], self._last[i] = r["stability"], r["last_access"]
        return out

    def archive_weak(self, now: int, threshold: float = 0.2) -> int:
        n = len(self.records)
        weak = np.flatnonzero((self._strengths(now, n) < threshold) & ~self._arch[:n])
        for i in weak:
            self.records[i]["archived"] = True
            self._arch[i] = True
        return int(weak.size)

    def find_conflicts(self) -> list:
        """Cặp bản ghi chưa archive có cùng 'key' nhưng 'value' khác nhau."""
        seen, out = {}, []
        for r in self.records:
            k = r["content"].get("key")
            if r["archived"] or k is None:
                continue
            for other in seen.get(k, []):
                if other["content"].get("value") != r["content"].get("value"):
                    out.append((other["id"], r["id"]))
            seen.setdefault(k, []).append(r)
        return out

    def state_dict(self) -> dict:
        n = len(self.records)
        return {"records": [dict(r) for r in self.records], "contexts": self._buf[:n].copy()}

    def load_state_dict(self, s: dict) -> None:
        self.records = [dict(r) for r in s["records"]]
        n = len(self.records)
        self._buf = None  # tránh sao chép dữ liệu cũ
        self._alloc(max(64, 1 << max(n - 1, 1).bit_length()))
        ctx = np.array(s["contexts"]).reshape(n, self.dim)
        self._buf[:n] = ctx
        self._norm[:n] = np.linalg.norm(ctx, axis=1) if n else 0
        for i, r in enumerate(self.records):
            self._stab[i], self._last[i], self._arch[i] = r["stability"], r["last_access"], r["archived"]
