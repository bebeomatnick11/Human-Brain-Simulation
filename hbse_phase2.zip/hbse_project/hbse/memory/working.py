"""Bộ nhớ làm việc: dung lượng giới hạn, kích hoạt phân rã theo hàm mũ. Mục rời đi được trả về để củng cố."""
from __future__ import annotations
import math


class WorkingMemory:
    def __init__(self, capacity: int = 7, decay: float = 0.15, floor: float = 0.05):
        self.capacity, self.decay, self.floor = capacity, decay, floor
        self.items: list = []

    def store(self, key: str, content: dict, salience: float, t: int, context=None, source: str = "observed") -> list:
        for it in self.items:
            if it["key"] == key:
                it.update(content=content, activation=max(it["activation"], salience),
                          salience=max(it["salience"], salience), t=t, context=context, source=source)
                return []
        self.items.append({"key": key, "content": content, "activation": float(salience),
                           "salience": float(salience), "t": int(t), "context": context, "source": source})
        if len(self.items) > self.capacity:
            weakest = min(self.items, key=lambda x: x["activation"])
            self.items.remove(weakest)
            return [weakest]
        return []

    def tick(self) -> list:
        f = math.exp(-self.decay)
        for it in self.items:
            it["activation"] *= f
        gone = [it for it in self.items if it["activation"] < self.floor]
        self.items = [it for it in self.items if it["activation"] >= self.floor]
        return gone

    def state_dict(self) -> dict:
        return {"items": [dict(it) for it in self.items]}

    def load_state_dict(self, s: dict) -> None:
        self.items = [dict(it) for it in s["items"]]
