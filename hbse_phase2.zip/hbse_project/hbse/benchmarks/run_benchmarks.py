"""Benchmark suite. Mỗi mục: giả thuyết, điều kiện, chỉ số, đường cơ sở. Số liệu in ra là số đo thật của lần chạy này.
Chạy từng phần: python -m hbse.benchmarks.run_benchmarks --part network|memory|system|learning:<variant>|merge"""
from __future__ import annotations
import json, os, resource, sys, tempfile, time
import numpy as np
from ..config import SimConfig, NetConfig, LearnConfig
from ..neural.network import SpikingNetwork
from ..memory.episodic import EpisodicMemory
from ..simulation.engine import BrainSimulation
from .evaluate import evaluate_policy


def ms(x):
    x = np.asarray(x, float)
    return {"mean": round(float(x.mean()), 3), "std": round(float(x.std()), 3), "n": int(x.size)}


def bench_network():
    """H: mạng E/I giữ tốc độ bắn sinh lý (1-30 Hz), không phát nổ, kể cả khi bật STDP."""
    out = {}
    for plastic in (False, True):
        cfg = NetConfig(plasticity=plastic)
        net = SpikingNetwork(cfg, np.random.default_rng(1))
        w0 = net.syn.mean_plastic_weight()
        t0 = time.perf_counter()
        for _ in range(5000):
            net.step()
        dt = time.perf_counter() - t0
        re, ri = net.mean_rates_hz()
        out[f"plasticity={plastic}"] = {
            "neurons": net.n, "synapses": int((net.syn.Wd != 0).sum()), "sim_ms": 5000,
            "rate_exc_hz": round(re, 2), "rate_inh_hz": round(ri, 2),
            "ticks_per_s": round(5000 / dt), "realtime_factor": round(5000 / dt / 1000, 2),
            "mean_plastic_w_before": round(w0, 3), "mean_plastic_w_after": round(net.syn.mean_plastic_weight(), 3),
            "finite": bool(np.isfinite(net.pop.v).all())}
    return out


VARIANTS = {
    "baseline": {},
    "no_modulation": {"modulation": False},
    "no_curiosity": {"learn": LearnConfig(curiosity_weight=0.0)},
    "episodic_control_0.5": {"learn": LearnConfig(episodic_control_weight=0.5)},
}


def bench_learning_variant(name, seeds, steps):
    """H: tác tử học nội cân bằng sống sót lâu hơn đường cơ sở ngẫu nhiên. Ablation cho biết từng cơ chế có ích không."""
    surv, st, dev = [], [], []
    for seed in seeds:
        if name == "random_policy":
            cfg = SimConfig(seed=seed, enable_network=False)
            ev = evaluate_policy(np.zeros_like(BrainSimulation(cfg).q.Q), cfg, episodes=100, epsilon=1.0)
        else:
            cfg = SimConfig(seed=seed, enable_network=False, **VARIANTS[name])
            sim = BrainSimulation(cfg)
            sim.run_agent_steps(steps)
            ev = evaluate_policy(sim.q.Q, cfg, episodes=100)
        surv.append(ev["survival_rate"]); st.append(ev["mean_steps"]); dev.append(ev["mean_energy_dev"])
    return {"survival_rate": ms(surv), "mean_steps": ms(st), "mean_energy_dev": ms(dev),
            "per_seed_survival": [round(x, 2) for x in surv],
            "conditions": {"train_agent_steps": steps, "seeds": list(seeds), "eval_episodes_per_seed": 100,
                           "eval": "greedy (random_policy: epsilon=1), chính sách đóng băng, seed đánh giá riêng"}}


def bench_memory():
    """H: truy xuất theo ngữ cảnh đúng hơn mức ngẫu nhiên khi có nhiễu; quên là archive theo luật lũy thừa."""
    rng = np.random.default_rng(0)
    out = {"retrieval_top1": {}}
    for n in (50, 500):
        ctx = rng.standard_normal((n, 34))
        mem = EpisodicMemory(34)
        for i, c in enumerate(ctx):
            mem.encode({"key": f"e{i}", "value": i}, c, 0)
        for noise in (0.0, 1.0, 2.0, 4.0):
            hits = sum(mem.retrieve(ctx[i], 0, k=1, noise=noise, rng=rng, reconsolidate=False)[0][2]["id"] == i
                       for i in range(n))
            out["retrieval_top1"][f"N={n},noise={noise}"] = {"acc": round(hits / n, 3), "chance": round(1 / n, 4)}
    mem = EpisodicMemory(34)
    for i in range(200):
        mem.encode({"key": f"e{i}", "value": i}, rng.standard_normal(34), 0, salience=0.5)
    out["fraction_archived_by_age_agent_steps"] = {}
    for age in (10, 100, 1000, 10000, 100000):
        m2 = EpisodicMemory(34); m2.load_state_dict(mem.state_dict())
        out["fraction_archived_by_age_agent_steps"][str(age)] = round(m2.archive_weak(age, 0.2) / 200, 3)
    return out


def bench_system(agent_steps):
    """Tài nguyên: toàn hệ thống (mạng + tác tử + bộ nhớ) và checkpoint."""
    sim = BrainSimulation(SimConfig(seed=0))
    t0 = time.perf_counter()
    sim.run_agent_steps(agent_steps)
    wall = time.perf_counter() - t0
    out = {"agent_steps": agent_steps, "sim_ticks": sim.scheduler.tick, "wall_s": round(wall, 2),
           "ticks_per_s": round(sim.scheduler.tick / wall), "profile": sim.scheduler.profile(),
           "peak_rss_mb": round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1),
           "final_metrics": sim.metrics()}
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "ck")
        t0 = time.perf_counter(); sim.save(p); ts = time.perf_counter() - t0
        t0 = time.perf_counter(); sim2 = BrainSimulation.load(p); tl = time.perf_counter() - t0
        out["checkpoint"] = {"save_s": round(ts, 3), "load_s": round(tl, 3),
                             "size_kb": round(sum(os.path.getsize(p + e) for e in (".json", ".npz")) / 1024, 1),
                             "bit_exact": bool(np.array_equal(sim.q.Q, sim2.q.Q) and
                                               np.array_equal(sim.net.syn.Wd, sim2.net.syn.Wd))}
    return out


PARTS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "docs", "bench_parts")


def save_part(name, obj):
    os.makedirs(PARTS_DIR, exist_ok=True)
    with open(os.path.join(PARTS_DIR, name + ".json"), "w") as f:
        json.dump(obj, f, indent=2)
    print(json.dumps({name: obj}, indent=2))


def main():
    """--part network|memory|system|learning:<variant>|merge"""
    part = sys.argv[sys.argv.index("--part") + 1]
    if part == "network":
        save_part("network", bench_network())
    elif part == "memory":
        save_part("memory", bench_memory())
    elif part == "system":
        save_part("system", bench_system(5000))
    elif part.startswith("learning:"):
        v = part.split(":", 1)[1]
        save_part("learning_" + v, bench_learning_variant(v, range(5), 30000))
    elif part == "merge":
        out = {"learning": {}}
        for fn in sorted(os.listdir(PARTS_DIR)):
            d = json.load(open(os.path.join(PARTS_DIR, fn)))
            if fn.startswith("learning_"):
                out["learning"][fn[9:-5]] = d
            else:
                out[fn[:-5]] = d
        with open(os.path.join(PARTS_DIR, "..", "benchmark_results.json"), "w") as f:
            json.dump(out, f, indent=2)
        print("merged:", list(out))


if __name__ == "__main__":
    main()
