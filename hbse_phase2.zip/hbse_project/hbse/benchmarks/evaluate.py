"""Đánh giá chính sách đóng băng trên môi trường mới (không học, không mạng), dùng chung lớp env/body/homeostasis."""
from __future__ import annotations
import numpy as np
from ..config import SimConfig
from ..environment.gridworld import GridWorld
from ..virtual_body.body import VirtualBody
from ..cognition.interoception import encode_state


def evaluate_policy(Q: np.ndarray, cfg: SimConfig, episodes: int = 100, epsilon: float = 0.0, seed: int = 12345) -> dict:
    rng = np.random.default_rng(seed)
    env, body = GridWorld(cfg.env), VirtualBody(cfg.body)
    steps, surv, dev = [], [], []
    for _ in range(episodes):
        body.reset()
        s, d = encode_state(env.reset(rng), body.energy), 0.0
        n = 0
        while True:
            if rng.random() < epsilon:
                a = int(rng.integers(0, env.n_actions))
            else:
                q = Q[s]
                a = int(rng.choice(np.flatnonzero(q >= q.max() - 1e-12)))
            r = env.step(a, rng)
            body.update(r["moved"], r["ate"], r["hazard"])
            s = encode_state(r["obs"], body.energy); n += 1; d += abs(body.energy - cfg.body.energy_setpoint)
            if not body.alive or env.steps >= cfg.env.max_steps:
                break
        steps.append(n); surv.append(body.alive); dev.append(d / n)
    return {"mean_steps": float(np.mean(steps)), "survival_rate": float(np.mean(surv)), "mean_energy_dev": float(np.mean(dev))}
