"""Cấu hình trung tâm. Mọi tham số đều serialize được sang JSON để tái lập thí nghiệm."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict


@dataclass
class NetConfig:
    n_exc: int = 160
    n_inh: int = 40
    p_connect: float = 0.2
    max_delay: int = 3            # ms (dt = 1 ms)
    w_exc_max: float = 2.0        # khởi tạo U(0, w_exc_max)
    w_inh_max: float = 4.0
    w_cap: float = 6.0            # trần trọng số sau STDP
    noise_exc: float = 5.0        # độ lệch chuẩn dòng nhiễu nền (kiểu Izhikevich 2003)
    noise_inh: float = 2.0
    plasticity: bool = True
    stdp_a_plus: float = 0.02
    stdp_a_minus: float = 0.024
    tau_trace_ms: float = 20.0
    homeostasis_eta: float = 0.2   # tốc độ synaptic scaling (Turrigiano) về tổng trọng số vào ban đầu
    homeostasis_period: int = 100  # mỗi bao nhiêu tick


@dataclass
class EnvConfig:
    size: int = 6
    food: list = field(default_factory=lambda: [0, 5])
    hazards: list = field(default_factory=lambda: [[2, 2], [3, 3], [1, 3]])
    slip: float = 0.1             # xác suất hành động di chuyển bị trượt ngẫu nhiên
    regrow_p: float = 0.1         # xác suất thức ăn mọc lại mỗi bước
    max_steps: int = 200


@dataclass
class BodyConfig:
    energy_setpoint: float = 0.8
    integrity_setpoint: float = 1.0
    metabolic_rate: float = 0.012
    move_cost: float = 0.006
    eat_gain: float = 0.35
    hazard_damage: float = 0.2
    integrity_regen: float = 0.01


@dataclass
class LearnConfig:
    alpha: float = 0.3
    gamma: float = 0.95
    eps0: float = 0.5
    eps_min: float = 0.05
    eps_decay: float = 0.98       # nhân theo mỗi episode
    reward_scale: float = 10.0
    curiosity_weight: float = 0.1
    episodic_control_weight: float = 0.0
    wm_capacity: int = 7
    wm_decay: float = 0.15
    consolidate_threshold: float = 0.3


@dataclass
class SimConfig:
    seed: int = 42
    agent_period_ticks: int = 10  # 1 quyết định mỗi 10 ms mô phỏng
    enable_network: bool = True
    modulation: bool = True       # dopamine/noradrenaline-proxy ảnh hưởng học & nhiễu
    net: NetConfig = field(default_factory=NetConfig)
    env: EnvConfig = field(default_factory=EnvConfig)
    body: BodyConfig = field(default_factory=BodyConfig)
    learn: LearnConfig = field(default_factory=LearnConfig)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SimConfig":
        d = dict(d)
        return cls(net=NetConfig(**d.pop("net")), env=EnvConfig(**d.pop("env")),
                   body=BodyConfig(**d.pop("body")), learn=LearnConfig(**d.pop("learn")), **d)
