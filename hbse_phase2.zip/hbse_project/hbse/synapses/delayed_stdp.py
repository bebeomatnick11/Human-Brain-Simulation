"""Synapse thưa có độ trễ + STDP dựa trên vết (trace) cho kết nối E->E.
Dấu (kích thích/ức chế) lưu riêng theo neuron tiền synapse (định luật Dale).
Giản lược đã biết: STDP dùng thời điểm spike không trễ; chỉ E->E có tính dẻo."""
from __future__ import annotations
import numpy as np
from ..config import NetConfig


class DelayedSTDPSynapses:
    def __init__(self, n_exc: int, n_inh: int, cfg: NetConfig, rng: np.random.Generator):
        n, D = n_exc + n_inh, cfg.max_delay
        self.cfg, self.n, self.n_exc, self.D = cfg, n, n_exc, D
        conn = rng.random((n, n)) < cfg.p_connect          # [post, pre]
        np.fill_diagonal(conn, False)
        delays = rng.integers(1, D + 1, size=(n, n))
        w = np.empty((n, n))
        w[:, :n_exc] = rng.random((n, n_exc)) * cfg.w_exc_max
        w[:, n_exc:] = rng.random((n, n_inh)) * cfg.w_inh_max
        self.Wd = np.zeros((D, n, n))                       # độ lớn trọng số theo từng độ trễ
        self.plastic = np.zeros((D, n, n), dtype=bool)
        for d in range(1, D + 1):
            m = conn & (delays == d)
            self.Wd[d - 1] = np.where(m, w, 0.0)
            self.plastic[d - 1] = m
        self.plastic[:, :, n_exc:] = False                  # tiền synapse ức chế: cố định
        self.plastic[:, n_exc:, :] = False                  # chỉ E->E dẻo
        self.sign = np.concatenate([np.ones(n_exc), -np.ones(n_inh)])
        self.hist = np.zeros((D + 1, n))
        self.t = 0
        self.x_pre = np.zeros(n)
        self.x_post = np.zeros(n)
        self.decay = float(np.exp(-1.0 / cfg.tau_trace_ms))
        self.target_in = (self.Wd * self.plastic).sum(axis=(0, 2))   # tổng trọng số E vào mỗi neuron hậu synapse

    def input_current(self) -> np.ndarray:
        I = np.zeros(self.n)
        for d in range(1, self.D + 1):
            s = self.hist[(self.t - d) % (self.D + 1)]
            if s.any():
                I += self.Wd[d - 1] @ (s * self.sign)
        return I

    def apply_stdp(self, spikes: np.ndarray, lr_scale: float = 1.0) -> None:
        c = self.cfg
        self.x_pre *= self.decay
        self.x_post *= self.decay
        idx = np.flatnonzero(spikes)
        if idx.size == 0:
            return
        # tăng cường: neuron hậu synapse vừa bắn, dùng vết của neuron tiền synapse
        old = self.Wd[:, idx, :]
        pm = self.plastic[:, idx, :]
        new = np.clip(old + lr_scale * c.stdp_a_plus * self.x_pre[None, None, :], 0.0, c.w_cap)
        self.Wd[:, idx, :] = np.where(pm, new, old)
        # suy giảm: neuron tiền synapse vừa bắn, dùng vết của neuron hậu synapse
        old = self.Wd[:, :, idx]
        pm = self.plastic[:, :, idx]
        new = np.clip(old - lr_scale * c.stdp_a_minus * self.x_post[None, :, None], 0.0, c.w_cap)
        self.Wd[:, :, idx] = np.where(pm, new, old)
        self.x_pre[idx] += 1.0
        self.x_post[idx] += 1.0

    def homeostatic_scaling(self) -> None:
        """Synaptic scaling nhân tính: kéo tổng trọng số kích thích vào mỗi neuron về mục tiêu ban đầu.
        Giữ hình dạng phân bố do STDP tạo ra nhưng ngăn trọng số sụp đổ hoặc phát nổ khi điều biến thay đổi tốc độ học."""
        cur = (self.Wd * self.plastic).sum(axis=(0, 2))
        ratio = np.where(self.target_in > 0, self.target_in / np.maximum(cur, 1e-9), 1.0)
        factor = 1.0 + self.cfg.homeostasis_eta * (np.clip(ratio, 0.5, 2.0) - 1.0)
        scaled = np.minimum(self.Wd * factor[None, :, None], self.cfg.w_cap)
        self.Wd = np.where(self.plastic, scaled, self.Wd)

    def record(self, spikes: np.ndarray) -> None:
        self.hist[self.t % (self.D + 1)] = spikes
        self.t += 1

    def mean_plastic_weight(self) -> float:
        mask = self.plastic.any(axis=0)
        return float(self.Wd.sum(axis=0)[mask].mean()) if mask.any() else 0.0

    def state_dict(self) -> dict:
        return {"Wd": self.Wd.copy(), "hist": self.hist.copy(), "t": int(self.t),
                "x_pre": self.x_pre.copy(), "x_post": self.x_post.copy()}

    def load_state_dict(self, s: dict) -> None:
        self.Wd, self.hist = np.array(s["Wd"]), np.array(s["hist"])
        self.t, self.x_pre, self.x_post = int(s["t"]), np.array(s["x_pre"]), np.array(s["x_post"])
