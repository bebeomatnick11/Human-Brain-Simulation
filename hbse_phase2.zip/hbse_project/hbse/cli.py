"""CLI: python -m hbse.cli run --agent-steps 20000 [--no-network] [--save out/ckpt]"""
import argparse, json, time
from .config import SimConfig
from .simulation.engine import BrainSimulation
from .security.limits import ResourceBudget


def main() -> None:
    p = argparse.ArgumentParser(prog="hbse")
    p.add_argument("cmd", choices=["run"])
    p.add_argument("--agent-steps", type=int, default=5000)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--no-network", action="store_true")
    p.add_argument("--max-wall-s", type=float, default=300.0, help="ngân sách thời gian thực")
    p.add_argument("--save")
    a = p.parse_args()
    sim = BrainSimulation(SimConfig(seed=a.seed, enable_network=not a.no_network))
    t0 = time.perf_counter()
    status = sim.run_agent_steps(a.agent_steps, ResourceBudget(max_wall_s=a.max_wall_s))
    print(json.dumps({"status": status, "wall_s": round(time.perf_counter() - t0, 2),
                      "metrics": sim.metrics(), "profile": sim.scheduler.profile()}, indent=2))
    if a.save:
        sim.save(a.save)


if __name__ == "__main__":
    main()
