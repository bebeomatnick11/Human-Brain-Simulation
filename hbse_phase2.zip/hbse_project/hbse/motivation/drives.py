"""Nội cân bằng + hệ thống mục tiêu.
Phần thưởng = mức giảm 'drive' D(h)=sum w_i (h*_i - h_i)^2 (học tăng cường nội cân bằng, Keramati & Gutkin 2014).
Mục tiêu hiện hành chọn theo độ cấp bách, có hysteresis để tránh dao động."""
from __future__ import annotations
import numpy as np

GOALS = ("restore_energy", "avoid_damage", "explore")


class Homeostasis:
    def __init__(self, setpoints, weights=None):
        self.sp = np.asarray(setpoints, dtype=float)
        self.w = np.ones_like(self.sp) if weights is None else np.asarray(weights, dtype=float)

    def drive(self, levels) -> float:
        return float(np.sum(self.w * (self.sp - np.asarray(levels)) ** 2))

    def reward(self, prev_levels, new_levels) -> float:
        return self.drive(prev_levels) - self.drive(new_levels)


class MotivationSystem:
    def __init__(self, homeostasis: Homeostasis, hysteresis: float = 0.15, curiosity_scale: float = 0.3):
        self.h, self.hyst, self.cs = homeostasis, hysteresis, curiosity_scale
        self.goal = "explore"

    def urgencies(self, levels, novelty: float) -> dict:
        deficit = np.maximum(self.h.sp - np.asarray(levels), 0.0) * self.h.w
        return {"restore_energy": float(deficit[0]), "avoid_damage": float(deficit[1]),
                "explore": float(self.cs * novelty)}

    def select(self, levels, novelty: float) -> str:
        u = self.urgencies(levels, novelty)
        best = max(GOALS, key=lambda g: u[g])
        if best != self.goal and u[best] > u[self.goal] * (1.0 + self.hyst):
            self.goal = best
        return self.goal

    def state_dict(self) -> dict:
        return {"goal": self.goal}

    def load_state_dict(self, s: dict) -> None:
        self.goal = s["goal"]
