"""BrainSimulation: ghép các module vào một vòng lặp scheduler.
Tick = 1 ms mô phỏng. Mạng spiking chạy mỗi tick; tác tử (nhận thức/hành vi) chạy mỗi `agent_period_ticks`.
LƯU Ý TRUNG THỰC: ở Giai đoạn 2, quyết định hành vi do Q-learning (Tier 1) đảm nhiệm; mạng spiking (Tier 3)
chịu điều biến bởi tín hiệu RPE/bất ngờ nhưng CHƯA nằm trong vòng điều khiển hành vi."""
from __future__ import annotations
import numpy as np
from ..config import SimConfig
from ..neural.network import SpikingNetwork
from ..neural.modulators import Neuromodulators
from ..environment.gridworld import GridWorld
from ..virtual_body.body import VirtualBody
from ..motivation.drives import Homeostasis, MotivationSystem
from ..cognition.world_model import WorldModel
from ..cognition.interoception import N_BINS, encode_state
from ..learning.td import QLearner
from ..memory.working import WorkingMemory
from ..memory.episodic import EpisodicMemory
from ..security.limits import ResourceBudget
from .scheduler import Scheduler
from . import serialize

CODE_DIM = 32
CTX_DIM = CODE_DIM + 2


class BrainSimulation:
    def __init__(self, cfg: SimConfig | None = None):
        self.cfg = cfg = cfg or SimConfig()
        s_net, s_env, s_agent, s_mem, s_code = np.random.SeedSequence(cfg.seed).spawn(5)
        self.rng_env, self.rng_agent, self.rng_mem = (np.random.default_rng(s) for s in (s_env, s_agent, s_mem))
        codes = np.random.default_rng(s_code).standard_normal((cfg.env.size ** 2 * 2, CODE_DIM))
        self.codes = codes / np.linalg.norm(codes, axis=1, keepdims=True)
        self.net = SpikingNetwork(cfg.net, np.random.default_rng(s_net))
        self.mod = Neuromodulators()
        self.env = GridWorld(cfg.env)
        self.body = VirtualBody(cfg.body)
        self.homeo = Homeostasis([cfg.body.energy_setpoint, cfg.body.integrity_setpoint])
        self.motivation = MotivationSystem(self.homeo)
        self.n_states = self.env.n_states * N_BINS
        self.world = WorldModel(self.n_states, self.env.n_actions)
        self.q = QLearner(self.n_states, self.env.n_actions, cfg.learn.alpha, cfg.learn.gamma)
        self.wm = WorkingMemory(cfg.learn.wm_capacity, cfg.learn.wm_decay)
        self.epi = EpisodicMemory(CTX_DIM)
        self.obs = encode_state(self.env.reset(self.rng_env), self.body.energy)
        self.agent_steps = 0
        self.episode = 0
        self._ep = self._new_ep()
        self.episodes: list = []          # tóm tắt các episode đã kết thúc
        self.scheduler = Scheduler()
        if cfg.enable_network:
            self.scheduler.add("network", 1, self._network_tick)
        self.scheduler.add("agent", cfg.agent_period_ticks, self._agent_tick)

    # ---------- vòng lặp ----------
    @staticmethod
    def _new_ep() -> dict:
        return {"steps": 0, "ret": 0.0, "eats": 0, "hazards": 0, "dev": 0.0}

    def _network_tick(self, tick: int) -> None:
        m = self.cfg.modulation
        self.net.step(noise_gain=self.mod.noradrenaline if m else 1.0,
                      lr_scale=self.mod.dopamine if m else 1.0)

    def _context(self, s: int, levels) -> np.ndarray:
        return np.concatenate([self.codes[s // N_BINS], levels])

    def _epsilon(self, goal: str) -> float:
        L = self.cfg.learn
        eps = max(L.eps_min, L.eps0 * L.eps_decay ** self.episode)
        eps *= 1.3 if goal == "explore" else 0.8
        if self.cfg.modulation:
            eps *= 0.6 + 0.4 * self.mod.noradrenaline
        return float(min(eps, 1.0))

    def _consolidate(self, items: list) -> None:
        for it in items:
            if it["salience"] >= self.cfg.learn.consolidate_threshold and it["context"] is not None:
                self.epi.encode(it["content"], it["context"], it["t"], it["source"],
                                confidence=1.0, salience=it["salience"])

    def _agent_tick(self, tick: int) -> None:
        L, now = self.cfg.learn, self.agent_steps
        s, levels = self.obs, self.body.levels().copy()
        goal = self.motivation.select(levels, self.world.novelty(s))
        ctx = self._context(s, levels)
        bias = None
        if L.episodic_control_weight > 0 and self.epi.records:
            bias = np.zeros(self.env.n_actions)
            for sim, st, rec in self.epi.retrieve(ctx, now, k=5):
                bias[rec["content"]["action"]] += L.episodic_control_weight * sim * rec["content"]["value"]
        a = self.q.act(s, self._epsilon(goal), self.rng_agent, bias)
        res = self.env.step(a, self.rng_env)
        self.body.update(res["moved"], res["ate"], res["hazard"])
        new_levels = self.body.levels()
        r_h = self.homeo.reward(levels, new_levels) * L.reward_scale
        r = r_h + L.curiosity_weight / np.sqrt(self.world.visits(s, a) + 1.0)
        s2 = encode_state(res["obs"], new_levels[0])
        surprise = self.world.update(s, a, s2)
        done = not self.body.alive
        delta = self.q.update(s, a, r, s2, done)
        self.mod.dopamine_pulse(delta)
        self.mod.surprise_pulse(surprise)
        self.mod.decay()
        # trí nhớ: WM giữ mục nổi bật; mục rời đi và đủ nổi bật được củng cố sang episodic
        salience = float(min(1.0, abs(delta) / 2.0 + surprise))
        content = {"key": f"cell:{self.env.cell()}", "action": int(a), "value": round(float(r_h), 4)}
        self._consolidate(self.wm.store(content["key"], content, salience, now, ctx))
        self._consolidate(self.wm.tick())
        ep = self._ep
        ep["steps"] += 1; ep["ret"] += float(r_h); ep["eats"] += int(res["ate"])
        ep["hazards"] += int(res["hazard"]); ep["dev"] += abs(new_levels[0] - self.cfg.body.energy_setpoint)
        self.obs = s2
        self.agent_steps += 1
        if done or self.env.steps >= self.cfg.env.max_steps:
            ep["survived"] = bool(not done)
            ep["dev"] /= max(ep["steps"], 1)
            self.episodes.append(ep)
            self.episode += 1
            self._ep = self._new_ep()
            self.body.reset()
            self.obs = encode_state(self.env.reset(self.rng_env), self.body.energy)

    # ---------- API ----------
    def run(self, n_ticks: int, budget: ResourceBudget | None = None) -> str:
        return self.scheduler.run(n_ticks, budget)

    def run_agent_steps(self, n: int, budget: ResourceBudget | None = None) -> str:
        return self.run(n * self.cfg.agent_period_ticks, budget)

    def metrics(self, last: int = 20) -> dict:
        eps = self.episodes[-last:]
        re, ri = self.net.mean_rates_hz() if self.cfg.enable_network else (0.0, 0.0)
        return {"ticks": self.scheduler.tick, "agent_steps": self.agent_steps, "episodes": self.episode,
                "survival_rate": float(np.mean([e["survived"] for e in eps])) if eps else None,
                "mean_ep_steps": float(np.mean([e["steps"] for e in eps])) if eps else None,
                "mean_energy_dev": float(np.mean([e["dev"] for e in eps])) if eps else None,
                "rate_exc_hz": re, "rate_inh_hz": ri,
                "mean_exc_weight": self.net.syn.mean_plastic_weight(),
                "dopamine": self.mod.dopamine, "noradrenaline": self.mod.noradrenaline,
                "goal": self.motivation.goal, "wm_items": len(self.wm.items), "episodic_records": len(self.epi.records)}

    # ---------- lưu / phục hồi ----------
    def state_dict(self) -> dict:
        return {"net": self.net.state_dict(), "mod": self.mod.state_dict(), "env": self.env.state_dict(),
                "body": self.body.state_dict(), "motivation": self.motivation.state_dict(),
                "world": self.world.state_dict(), "q": self.q.state_dict(), "wm": self.wm.state_dict(),
                "epi": self.epi.state_dict(), "scheduler": self.scheduler.state_dict(),
                "rng_env": self.rng_env.bit_generator.state, "rng_agent": self.rng_agent.bit_generator.state,
                "rng_mem": self.rng_mem.bit_generator.state,
                "obs": int(self.obs), "agent_steps": self.agent_steps, "episode": self.episode,
                "ep": dict(self._ep), "episodes": [dict(e) for e in self.episodes]}

    def load_state_dict(self, s: dict) -> None:
        self.net.load_state_dict(s["net"]); self.mod.load_state_dict(s["mod"])
        self.env.load_state_dict(s["env"]); self.body.load_state_dict(s["body"])
        self.motivation.load_state_dict(s["motivation"]); self.world.load_state_dict(s["world"])
        self.q.load_state_dict(s["q"]); self.wm.load_state_dict(s["wm"]); self.epi.load_state_dict(s["epi"])
        self.scheduler.load_state_dict(s["scheduler"])
        self.rng_env.bit_generator.state = s["rng_env"]; self.rng_agent.bit_generator.state = s["rng_agent"]
        self.rng_mem.bit_generator.state = s["rng_mem"]
        self.obs, self.agent_steps, self.episode = int(s["obs"]), int(s["agent_steps"]), int(s["episode"])
        self._ep, self.episodes = dict(s["ep"]), [dict(e) for e in s["episodes"]]

    def save(self, prefix: str) -> None:
        serialize.save(prefix, self.cfg.to_dict(), self.state_dict())

    @classmethod
    def load(cls, prefix: str) -> "BrainSimulation":
        cfg, state = serialize.load(prefix)
        sim = cls(SimConfig.from_dict(cfg))
        sim.load_state_dict(state)
        return sim
