"""Checkpoint an toàn: mảng -> .npz (không pickle), cấu trúc -> .json, kèm SHA-256 để kiểm tra toàn vẹn."""
from __future__ import annotations
import hashlib, json, os
import numpy as np

FORMAT_VERSION = 1


def pack(obj, arrays: dict):
    if isinstance(obj, np.ndarray):
        key = f"a{len(arrays)}"
        arrays[key] = obj
        return {"__nd__": key}
    if isinstance(obj, dict):
        return {str(k): pack(v, arrays) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [pack(v, arrays) for v in obj]
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    return obj


def unpack(obj, arrays):
    if isinstance(obj, dict):
        if set(obj) == {"__nd__"}:
            return arrays[obj["__nd__"]]
        return {k: unpack(v, arrays) for k, v in obj.items()}
    if isinstance(obj, list):
        return [unpack(v, arrays) for v in obj]
    return obj


def _sha(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def save(prefix: str, config: dict, state: dict) -> None:
    arrays: dict = {}
    doc = {"format": FORMAT_VERSION, "config": config, "state": pack(state, arrays)}
    tmp_j, tmp_n = prefix + ".json.tmp", prefix + ".tmp.npz"
    with open(tmp_j, "w") as f:
        json.dump(doc, f)
    np.savez_compressed(tmp_n, **arrays)
    os.replace(tmp_j, prefix + ".json")
    os.replace(tmp_n, prefix + ".npz")
    with open(prefix + ".sha256", "w") as f:
        json.dump({"json": _sha(prefix + ".json"), "npz": _sha(prefix + ".npz")}, f)


def load(prefix: str) -> tuple:
    with open(prefix + ".sha256") as f:
        expected = json.load(f)
    if _sha(prefix + ".json") != expected["json"] or _sha(prefix + ".npz") != expected["npz"]:
        raise ValueError("Checkpoint hỏng hoặc bị sửa: SHA-256 không khớp")
    with open(prefix + ".json") as f:
        doc = json.load(f)
    if doc["format"] != FORMAT_VERSION:
        raise ValueError(f"Phiên bản checkpoint không hỗ trợ: {doc['format']}")
    with np.load(prefix + ".npz", allow_pickle=False) as z:
        arrays = {k: z[k] for k in z.files}
    return doc["config"], unpack(doc["state"], arrays)
