"""Scheduler theo tick với chu kỳ riêng cho từng tác vụ; đo thời gian thực mỗi tác vụ; tôn trọng ngân sách."""
from __future__ import annotations
import time
from dataclasses import dataclass
from typing import Callable
from ..security.limits import ResourceBudget, BudgetExceeded


@dataclass
class Task:
    name: str
    period: int
    fn: Callable[[int], None]
    offset: int = 0
    calls: int = 0
    wall_s: float = 0.0


class Scheduler:
    def __init__(self):
        self.tasks: list = []
        self.tick = 0
        self.halted_reason: str | None = None

    def add(self, name: str, period: int, fn: Callable[[int], None], offset: int = 0) -> None:
        assert period >= 1
        self.tasks.append(Task(name, period, fn, offset))

    def run(self, n_ticks: int, budget: ResourceBudget | None = None) -> str:
        """Trả về 'ok' hoặc lý do dừng. Trạng thái giữ nguyên để chạy tiếp hoặc lưu."""
        self.halted_reason = None
        try:
            for _ in range(n_ticks):
                if budget:
                    budget.charge(1)
                for t in self.tasks:
                    if (self.tick - t.offset) % t.period == 0:
                        t0 = time.perf_counter()
                        t.fn(self.tick)
                        t.wall_s += time.perf_counter() - t0
                        t.calls += 1
                self.tick += 1
        except BudgetExceeded as e:
            self.halted_reason = str(e)
            return self.halted_reason
        return "ok"

    def profile(self) -> dict:
        return {t.name: {"calls": t.calls, "wall_s": round(t.wall_s, 4)} for t in self.tasks}

    def state_dict(self) -> dict:
        return {"tick": self.tick}

    def load_state_dict(self, s: dict) -> None:
        self.tick = int(s["tick"])
