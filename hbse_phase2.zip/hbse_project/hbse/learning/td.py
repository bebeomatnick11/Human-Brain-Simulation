"""Q-learning dạng bảng với sai số TD (tín hiệu kiểu RPE). Tier 1 (nhận thức/hành vi cấp cao)."""
from __future__ import annotations
import numpy as np


class QLearner:
    def __init__(self, n_states: int, n_actions: int, alpha: float, gamma: float):
        self.Q = np.zeros((n_states, n_actions))
        self.alpha, self.gamma = alpha, gamma

    def act(self, s: int, epsilon: float, rng: np.random.Generator, bias=None) -> int:
        if rng.random() < epsilon:
            return int(rng.integers(0, self.Q.shape[1]))
        q = self.Q[s] + (0.0 if bias is None else bias)
        best = np.flatnonzero(q >= q.max() - 1e-12)
        return int(rng.choice(best))

    def update(self, s: int, a: int, r: float, s2: int, done: bool) -> float:
        target = r if done else r + self.gamma * self.Q[s2].max()
        delta = target - self.Q[s, a]
        self.Q[s, a] += self.alpha * delta
        return float(delta)

    def state_dict(self) -> dict:
        return {"Q": self.Q.copy()}

    def load_state_dict(self, s: dict) -> None:
        self.Q = np.array(s["Q"])
