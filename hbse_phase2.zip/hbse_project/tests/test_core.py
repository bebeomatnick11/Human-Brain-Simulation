import os, tempfile, unittest
import numpy as np
from hbse.config import SimConfig, NetConfig, EnvConfig, BodyConfig
from hbse.environment.gridworld import GridWorld
from hbse.virtual_body.body import VirtualBody
from hbse.motivation.drives import Homeostasis, MotivationSystem
from hbse.cognition.world_model import WorldModel
from hbse.simulation.scheduler import Scheduler
from hbse.security.limits import ResourceBudget
from hbse.simulation.engine import BrainSimulation
from hbse.benchmarks.evaluate import evaluate_policy


class TestWorldAndBody(unittest.TestCase):
    def test_eating_requires_food_and_depletes_it(self):
        env = GridWorld(EnvConfig(slip=0.0, regrow_p=0.0)); rng = np.random.default_rng(0)
        env.reset(rng); env.pos = [0, 4]
        self.assertFalse(env.step(4, rng)["ate"])           # không đứng trên thức ăn
        env.pos = [0, 5]
        self.assertTrue(env.step(4, rng)["ate"])
        self.assertFalse(env.step(4, rng)["ate"])           # đã cạn, regrow_p=0

    def test_walls_and_hazards(self):
        env = GridWorld(EnvConfig(slip=0.0)); rng = np.random.default_rng(0)
        env.reset(rng); env.pos = [0, 0]
        self.assertFalse(env.step(0, rng)["moved"])         # va tường
        env.pos = [2, 1]
        self.assertTrue(env.step(3, rng)["hazard"])         # sang ô (2,2)

    def test_body_dies_and_clips(self):
        b = VirtualBody(BodyConfig())
        for _ in range(200):
            b.update(False, False, False)
        self.assertEqual(b.energy, 0.0); self.assertFalse(b.alive)
        b.reset(); b.update(False, True, False)
        self.assertLessEqual(b.energy, 1.0)

    def test_homeostatic_reward_sign(self):
        h = Homeostasis([0.8, 1.0])
        self.assertGreater(h.reward([0.3, 1.0], [0.65, 1.0]), 0)   # ăn khi đói: thưởng
        self.assertLess(h.reward([0.8, 1.0], [1.0, 1.0]), 0)       # ăn quá no: phạt
        self.assertLess(h.reward([0.8, 1.0], [0.8, 0.6]), 0)       # bị thương: phạt

    def test_goal_hysteresis(self):
        m = MotivationSystem(Homeostasis([0.8, 1.0]))
        self.assertEqual(m.select([0.8, 1.0], novelty=1.0), "explore")
        self.assertEqual(m.select([0.2, 1.0], novelty=1.0), "restore_energy")
        # thiếu hụt năng lượng 0.2; explore = 0.3*0.7 = 0.21 < 0.2*1.15 -> giữ mục tiêu cũ
        self.assertEqual(m.select([0.6, 1.0], novelty=0.7), "restore_energy")
        # explore = 0.3*1.0 = 0.30 > 0.23 -> đổi mục tiêu
        self.assertEqual(m.select([0.6, 1.0], novelty=1.0), "explore")

    def test_world_model_surprise_falls_with_experience(self):
        wm = WorldModel(10, 2)
        first = wm.update(1, 0, 2)
        for _ in range(30):
            last = wm.update(1, 0, 2)
        self.assertLess(last, first)
        self.assertGreater(wm.surprise(1, 0, 5), wm.surprise(1, 0, 2))


class TestScheduler(unittest.TestCase):
    def test_periods_and_offsets(self):
        calls = {"a": [], "b": []}
        s = Scheduler()
        s.add("a", 1, lambda t: calls["a"].append(t)); s.add("b", 5, lambda t: calls["b"].append(t), offset=2)
        s.run(12)
        self.assertEqual(len(calls["a"]), 12); self.assertEqual(calls["b"], [2, 7])

    def test_budget_halts_gracefully_and_resumes(self):
        s = Scheduler(); n = []
        s.add("x", 1, lambda t: n.append(t))
        status = s.run(100, ResourceBudget(max_ticks=10))
        self.assertIn("ngân sách", status); self.assertEqual(len(n), 10)
        self.assertEqual(s.run(5), "ok"); self.assertEqual(len(n), 15)


def small_cfg(**kw):
    return SimConfig(net=NetConfig(n_exc=40, n_inh=10), **kw)


class TestEngine(unittest.TestCase):
    def test_same_seed_same_trajectory(self):
        a, b = BrainSimulation(small_cfg(seed=9)), BrainSimulation(small_cfg(seed=9))
        a.run_agent_steps(300); b.run_agent_steps(300)
        self.assertTrue(np.array_equal(a.q.Q, b.q.Q))
        self.assertEqual(a.net.count_exc, b.net.count_exc)

    def test_checkpoint_roundtrip_is_bit_exact_and_continues_identically(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "ck")
            a = BrainSimulation(small_cfg(seed=3)); a.run_agent_steps(250); a.save(p)
            b = BrainSimulation.load(p)
            self.assertTrue(np.array_equal(a.q.Q, b.q.Q))
            self.assertTrue(np.array_equal(a.net.syn.Wd, b.net.syn.Wd))
            a.run_agent_steps(250); b.run_agent_steps(250)           # tiếp tục: phải trùng khớp tuyệt đối
            self.assertTrue(np.array_equal(a.q.Q, b.q.Q))
            self.assertTrue(np.array_equal(a.net.syn.Wd, b.net.syn.Wd))
            self.assertEqual(a.episodes, b.episodes)
            self.assertEqual(len(a.epi.records), len(b.epi.records))
            self.assertEqual(a.metrics(), b.metrics())

    def test_tampered_checkpoint_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "ck")
            BrainSimulation(small_cfg()).save(p)
            with open(p + ".json", "a") as f:
                f.write(" ")
            with self.assertRaises(ValueError):
                BrainSimulation.load(p)

    def test_budget_stops_engine(self):
        sim = BrainSimulation(small_cfg())
        status = sim.run(1000, ResourceBudget(max_ticks=50))
        self.assertIn("ngân sách", status); self.assertEqual(sim.scheduler.tick, 50)

    def test_agent_learns_better_than_random(self):
        cfg = SimConfig(seed=0, enable_network=False)
        sim = BrainSimulation(cfg); sim.run_agent_steps(30000)
        trained = evaluate_policy(sim.q.Q, cfg, episodes=50)
        rand = evaluate_policy(np.zeros_like(sim.q.Q), cfg, episodes=50, epsilon=1.0)
        self.assertGreater(trained["mean_steps"], 2 * rand["mean_steps"])
        self.assertLess(trained["mean_energy_dev"], rand["mean_energy_dev"])

    def test_memory_pipeline_populates_and_respects_capacity(self):
        sim = BrainSimulation(SimConfig(seed=1, enable_network=False)); sim.run_agent_steps(2000)
        self.assertLessEqual(len(sim.wm.items), sim.cfg.learn.wm_capacity)
        self.assertGreater(len(sim.epi.records), 0)
        self.assertTrue(all(r["source"] == "observed" for r in sim.epi.records))


if __name__ == "__main__":
    unittest.main()
