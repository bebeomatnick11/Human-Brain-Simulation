import unittest
import numpy as np
from hbse.memory.working import WorkingMemory
from hbse.memory.episodic import EpisodicMemory


class TestWorkingMemory(unittest.TestCase):
    def test_capacity_and_eviction_returns_weakest(self):
        wm = WorkingMemory(capacity=3)
        for i, sal in enumerate([0.9, 0.2, 0.8]):
            self.assertEqual(wm.store(f"k{i}", {"i": i}, sal, t=i), [])
        gone = wm.store("k3", {"i": 3}, 0.7, t=3)
        self.assertEqual([g["key"] for g in gone], ["k1"])
        self.assertEqual(len(wm.items), 3)

    def test_refresh_same_key_does_not_grow(self):
        wm = WorkingMemory(capacity=3)
        wm.store("a", {}, 0.5, 0); wm.store("a", {}, 0.9, 1)
        self.assertEqual(len(wm.items), 1)
        self.assertEqual(wm.items[0]["activation"], 0.9)

    def test_decay_releases_items_for_consolidation(self):
        wm = WorkingMemory(capacity=3, decay=0.5)
        wm.store("a", {}, 0.5, 0)
        released = []
        for _ in range(10):
            released += wm.tick()
        self.assertEqual([r["key"] for r in released], ["a"])
        self.assertEqual(wm.items, [])


class TestEpisodic(unittest.TestCase):
    def setUp(self):
        self.rng = np.random.default_rng(0)
        self.mem = EpisodicMemory(dim=32)
        self.ctx = self.rng.standard_normal((50, 32))
        for i, c in enumerate(self.ctx):
            self.mem.encode({"key": f"e{i}", "value": i}, c, t=0)

    def top1_accuracy(self, noise, now=0, n=50):
        hits = 0
        for i in range(n):
            r = self.mem.retrieve(self.ctx[i], now, k=1, noise=noise, rng=self.rng, reconsolidate=False)
            hits += bool(r) and r[0][2]["id"] == i
        return hits / n

    def test_exact_cue_retrieves_correct_episode(self):
        self.assertEqual(self.top1_accuracy(0.0), 1.0)

    def test_noise_degrades_but_beats_chance(self):
        acc = self.top1_accuracy(3.0)
        self.assertLess(acc, 1.0)
        self.assertGreater(acc, 3 * (1 / 50))

    def test_forgetting_is_archive_not_delete_and_reversible(self):
        n = len(self.mem.records)
        archived = self.mem.archive_weak(now=100000, threshold=0.2)
        self.assertGreater(archived, 0)
        self.assertEqual(len(self.mem.records), n)                      # không xóa
        self.assertEqual(self.mem.retrieve(self.ctx[0], 100000, k=1), [])
        r = self.mem.retrieve(self.ctx[0], 100000, k=1, include_archived=True)
        self.assertEqual(r[0][2]["id"], 0)

    def test_reconsolidation_slows_forgetting(self):
        rec = self.mem.records[0]
        s_before = self.mem.strength(rec, 500)
        self.mem.retrieve(self.ctx[0], 100, k=1)                        # nhớ lại ở t=100
        self.assertGreater(self.mem.strength(self.mem.records[0], 500), s_before)

    def test_source_labels_and_validation(self):
        rid = self.mem.encode({"key": "x"}, self.ctx[0], t=1, source="imagined")
        self.assertEqual(self.mem.records[rid]["source"], "imagined")
        with self.assertRaises(AssertionError):
            self.mem.encode({"key": "y"}, self.ctx[0], t=1, source="dream")

    def test_conflict_detection(self):
        self.mem.encode({"key": "e3", "value": 999}, self.ctx[3], t=2)
        self.assertIn((3, 50), self.mem.find_conflicts())

    def test_state_roundtrip(self):
        s = self.mem.state_dict()
        m2 = EpisodicMemory(dim=32); m2.load_state_dict(s)
        a = self.mem.retrieve(self.ctx[7], 5, k=3, reconsolidate=False)
        b = m2.retrieve(self.ctx[7], 5, k=3, reconsolidate=False)
        self.assertEqual([x[2]["id"] for x in a], [x[2]["id"] for x in b])


if __name__ == "__main__":
    unittest.main()
