import unittest
import numpy as np
from hbse.config import NetConfig
from hbse.neural.network import SpikingNetwork
from hbse.synapses.delayed_stdp import DelayedSTDPSynapses


def run(cfg, seed, ticks, **kw):
    net = SpikingNetwork(cfg, np.random.default_rng(seed))
    for _ in range(ticks):
        net.step(**kw)
    return net


class TestNetwork(unittest.TestCase):
    def test_stable_physiological_rates(self):
        net = run(NetConfig(), 1, 2000)
        re, ri = net.mean_rates_hz()
        self.assertTrue(np.isfinite(net.pop.v).all() and np.isfinite(net.pop.u).all())
        self.assertTrue(0.5 < re < 40.0, re)
        self.assertTrue(0.5 < ri < 80.0, ri)

    def test_deterministic_given_seed(self):
        a, b, c = run(NetConfig(), 3, 500), run(NetConfig(), 3, 500), run(NetConfig(), 4, 500)
        self.assertEqual(a.count_exc, b.count_exc)
        self.assertTrue(np.array_equal(a.syn.Wd, b.syn.Wd))
        self.assertNotEqual(a.count_exc, c.count_exc)

    def test_plastic_weights_stay_bounded_and_change(self):
        cfg = NetConfig()
        net = SpikingNetwork(cfg, np.random.default_rng(2))
        w0 = net.syn.Wd.copy()
        for _ in range(2000):
            net.step()
        W = net.syn.Wd
        self.assertTrue((W >= 0).all() and (W <= cfg.w_cap + 1e-9).all())
        self.assertFalse(np.array_equal(W, w0))
        # synapse không dẻo (tiền synapse ức chế) phải giữ nguyên
        self.assertTrue(np.array_equal(W[~net.syn.plastic], w0[~net.syn.plastic]))

    def test_homeostasis_prevents_weight_collapse_under_strong_modulation(self):
        # Lỗi thật từng gặp: noise_gain cao + lr_scale cao làm trọng số E->E sụp ~89% khi không có cân bằng nội môi.
        def mean_w_after(eta):
            cfg = NetConfig(homeostasis_eta=eta)
            net = SpikingNetwork(cfg, np.random.default_rng(11))
            w0 = net.syn.mean_plastic_weight()
            for _ in range(8000):
                net.step(noise_gain=2.5, lr_scale=3.0)
            return net.syn.mean_plastic_weight() / w0
        self.assertLess(mean_w_after(0.0), 0.5)             # không có cân bằng: sụp
        self.assertGreater(mean_w_after(0.2), 0.8)          # có cân bằng: ổn định (trong ±20%)

    def test_noise_gain_raises_rate(self):
        lo = run(NetConfig(plasticity=False), 5, 1500, noise_gain=0.8).mean_rates_hz()[0]
        hi = run(NetConfig(plasticity=False), 5, 1500, noise_gain=1.5).mean_rates_hz()[0]
        self.assertGreater(hi, lo)

    def test_dopamine_gain_scales_plasticity(self):
        def total_change(scale):
            net = SpikingNetwork(NetConfig(), np.random.default_rng(7))
            w0 = net.syn.Wd.copy()
            for _ in range(1000):
                net.step(lr_scale=scale)
            return np.abs(net.syn.Wd - w0).sum()
        self.assertGreater(total_change(3.0), total_change(0.2))


class TestSynapses(unittest.TestCase):
    def make(self, n_exc=2, n_inh=0, D=3):
        cfg = NetConfig(n_exc=n_exc, n_inh=n_inh, p_connect=1.0, max_delay=D)
        syn = DelayedSTDPSynapses(n_exc, n_inh, cfg, np.random.default_rng(0))
        syn.Wd[:] = 0.0
        return syn

    def test_stdp_sign_pre_then_post_potentiates(self):
        syn = self.make(D=1)
        syn.Wd[0, 1, 0] = 1.0                      # pre=0 -> post=1
        syn.apply_stdp(np.array([True, False])); syn.record(np.array([True, False]))
        for _ in range(4):
            syn.apply_stdp(np.array([False, False])); syn.record(np.array([False, False]))
        syn.apply_stdp(np.array([False, True]))
        self.assertGreater(syn.Wd[0, 1, 0], 1.0)

    def test_stdp_sign_post_then_pre_depresses(self):
        syn = self.make(D=1)
        syn.Wd[0, 1, 0] = 1.0
        syn.apply_stdp(np.array([False, True])); syn.record(np.array([False, True]))
        for _ in range(4):
            syn.apply_stdp(np.array([False, False])); syn.record(np.array([False, False]))
        syn.apply_stdp(np.array([True, False]))
        self.assertLess(syn.Wd[0, 1, 0], 1.0)

    def test_axonal_delay_exact(self):
        syn = self.make(D=3)
        syn.Wd[1, 1, 0] = 1.0                      # trễ 2 ms
        syn.record(np.array([1.0, 0.0]))           # spike ở tick 0
        self.assertEqual(syn.input_current()[1], 0.0)   # tick 1
        syn.record(np.zeros(2))
        self.assertEqual(syn.input_current()[1], 1.0)   # tick 2
        syn.record(np.zeros(2))
        self.assertEqual(syn.input_current()[1], 0.0)   # tick 3

    def test_inhibitory_presynaptic_gives_negative_current(self):
        syn = self.make(n_exc=1, n_inh=1, D=1)
        syn.Wd[0, 0, 1] = 2.0                      # pre ức chế (1) -> post (0)
        syn.record(np.array([0.0, 1.0]))
        self.assertEqual(syn.input_current()[0], -2.0)


if __name__ == "__main__":
    unittest.main()
