# HBSE — Human Brain Simulation Engine (Giai đoạn 1–2)

Nền tảng mô phỏng thần kinh–nhận thức nhiều cấp độ, chạy cục bộ, chỉ cần Python 3.10+ và NumPy (không API key, không mạng, không GPU).
**Không** phải bản sao não người; **không** tuyên bố có ý thức hay trải nghiệm chủ quan. Xem `docs/PHASE1_ARCHITECTURE.md`.

## Cài đặt và chạy
```bash
pip install -r requirements.txt
python -m unittest discover -s tests -t .                      # 34 kiểm thử
python -m hbse.cli run --agent-steps 5000 --save out/ckpt      # chạy mô phỏng đầy đủ (mạng + tác tử + bộ nhớ)
python -m hbse.cli run --agent-steps 30000 --no-network        # chỉ tầng nhận thức/hành vi (nhanh)
python -m hbse.benchmarks.run_benchmarks --part network        # network | memory | system | learning:<variant> | merge
```
Biến thể learning: `random_policy baseline no_modulation no_curiosity episodic_control_0.5`.

## Đã có (GĐ2)
Neuron Izhikevich E/I, synapse thưa có trễ, STDP + synaptic scaling, điều biến dạng độ lợi (RPE/bất ngờ),
bộ nhớ làm việc, bộ nhớ episodic (nguồn gốc, quên lũy thừa kiểu archive, tái củng cố, phát hiện mâu thuẫn),
mô hình thế giới dự đoán, nội cân bằng + mục tiêu, Q-learning, cơ thể ảo + nội cảm, môi trường lưới,
scheduler đa chu kỳ, ngân sách tài nguyên, checkpoint bit-exact có SHA-256.

## Chưa có
Cảm xúc, nhân cách, nhận thức xã hội, giấc ngủ, tưởng tượng, global workspace, self-model, vùng não chức năng.
Thư mục tương ứng tồn tại nhưng còn trống. Mạng spiking **chưa** điều khiển hành vi.

Số đo thật: `docs/benchmark_results.json`.
