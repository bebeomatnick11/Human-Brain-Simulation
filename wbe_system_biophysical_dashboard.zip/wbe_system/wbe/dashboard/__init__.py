"""Local web dashboard for observing actual WBE engine simulation results."""
