"""Local HTML dashboard backed by the real Parts 1-5 simulation engine.

Start with: python -m wbe.dashboard.server --host 127.0.0.1 --port 8000
This is a local research dashboard; it is not an internet-facing production server.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from wbe.connectome.loader import ConnectomeLoader
from wbe.core.interfaces import NeuronState, SynapseState
from wbe.initialization.factory import InitialStateFactory
from wbe.models.functional import FunctionalParameterMapper
from wbe.models.inference import InferenceConfig, ParameterInferenceEngine
from wbe.simulation.engine import SimulationConfig, SimulationEngine
from wbe.state.brain_state import BrainState, StateSource

ROOT = Path(__file__).resolve().parent
MAX_REQUEST_BYTES = 25 * 1024 * 1024


def run_engine_self_test() -> dict[str, Any]:
    """Exercise LIF integration and delivery of a delayed synaptic event."""
    neuron_params = {
        "model": "lif", "tau_m_ms": 20.0, "resistance_mohm": 1.0,
        "resting_potential_mv": -65.0, "reset_potential_mv": -65.0,
        "threshold_mv": -50.0, "refractory_ms": 2.0,
        "membrane_capacitance_nf": 1.0, "excitability": 1.0,
        "calcium_decay_ms": 100.0,
    }
    state = BrainState(neurons={
        1: NeuronState(neuron_id=1, v_m=-65.0, intrinsic=dict(neuron_params)),
        2: NeuronState(neuron_id=2, v_m=-65.0, intrinsic=dict(neuron_params)),
    }, synapses=[SynapseState(pre_id=1, post_id=2, weight=5.0, delay_ms=1.0, receptor_type="excitatory")])
    engine = SimulationEngine(SimulationConfig(dt_ms=1.0, update_plasticity=False))
    first = engine.step(state, {1: 400.0})
    second = engine.step(state, {})
    propagated = state.neurons[2].v_m > -65.000001
    passed = 1 in first.extra.get("spiking_neurons", []) and propagated and second.t_ms == 2.0
    return {
        "passed": bool(passed), "test": "LIF threshold/reset + delayed synaptic event",
        "source_spike_count": len(first.extra.get("spiking_neurons", [])),
        "receiver_voltage_mv": round(state.neurons[2].v_m, 5),
        "receiver_delta_mv": round(state.neurons[2].v_m + 65.0, 5),
        "checked_simulated_time_ms": state.t_ms,
        "note": "Checks numerical engine behavior only; does not validate biological realism.",
    }


class SimulationWorkbench:
    def __init__(self):
        self._lock = threading.RLock()
        self.factory = InitialStateFactory()
        self.state = self.factory.synthetic(n_neurons=80, n_synapses=320, seed=73)
        self.engine = SimulationEngine(SimulationConfig(dt_ms=1.0, update_plasticity=False))
        self.source_label = "synthetic demo network (not biological data)"
        self.parameter_report: dict[str, Any] | None = None
        self.history: list[dict[str, Any]] = []
        self.total_spike_events = 0
        self.run_count = 0
        self.last_run: dict[str, Any] = {"events": [], "summary": None}
        self.self_test = run_engine_self_test()

    def status(self) -> dict[str, Any]:
        with self._lock:
            n = list(self.state.neurons.values())
            preview_nodes = sorted(self.state.neurons)[:60]
            preview_set = set(preview_nodes)
            preview_edges = []
            for syn in self.state.synapses:
                if syn.pre_id in preview_set and syn.post_id in preview_set:
                    preview_edges.append({"source": int(syn.pre_id), "target": int(syn.post_id),
                                          "weight": float(syn.weight), "receptor_type": str(syn.receptor_type)})
                    if len(preview_edges) >= 180:
                        break
            recent_spikers = sorted({nid for event in self.last_run.get("events", [])[-200:]
                                     for nid in event.get("spiking_neurons", [])})
            return {
                "ok": True,
                "simulation_ready": True,
                "network_preview": {"nodes": [{"id": int(nid), "voltage_mv": round(float(self.state.neurons[nid].v_m), 3),
                    "last_spike_ms": self.state.neurons[nid].last_spike_ms,
                    "region": self.state.neurons[nid].region.value if hasattr(self.state.neurons[nid].region, "value") else str(self.state.neurons[nid].region),
                    "parameters": {key: self.state.neurons[nid].intrinsic.get(key) for key in ("tau_m_ms", "resistance_mohm", "membrane_capacitance_nf", "resting_potential_mv", "threshold_mv", "refractory_ms", "calcium_decay_ms") if key in self.state.neurons[nid].intrinsic},
                    "inference": dict(self.state.neurons[nid].meta.get("parameter_inference", {}))}
                    for nid in preview_nodes], "edges": preview_edges, "recent_spikers": recent_spikers},
                "engine": "wbe.simulation.engine.SimulationEngine / current_based_lif",
                "self_test": self.self_test,
                "source": self.source_label,
                "species": (self.parameter_report or {}).get("species", "unassigned"),
                "neuron_count": len(n),
                "synapse_count": len(self.state.synapses),
                "simulation_time_ms": round(float(self.state.t_ms), 4),
                "mean_voltage_mv": round(sum(x.v_m for x in n) / len(n), 4) if n else None,
                "active_neurons": sum(1 for x in n if x.last_spike_ms is not None),
                "total_spike_events": self.total_spike_events,
                "run_count": self.run_count,
                "parameter_inference": self.parameter_report,
                "provenance": self.state.extra.get("data_provenance", self.state.extra.get("connectome", {})),
                "last_run": self.last_run,
                "warnings": ["Synthetic mode is a functional test network, not a recorded or reconstructed brain."] if self.state.source == StateSource.SYNTHETIC else [],
            }

    def _load_dataset(self, dataset, species: str, report_source: str) -> dict[str, Any]:
        reference_csv = os.environ.get("WBE_PHYSIOLOGY_REFERENCE_CSV") or None
        params, report = ParameterInferenceEngine(InferenceConfig(species=species, reference_csv=reference_csv)).infer(dataset)
        state = self.factory.from_connectome(dataset, params)
        state.extra["parameter_inference"] = report.to_dict()
        state.extra["data_provenance"] = dict(dataset.metadata)
        # In this software, uncertainty=1-confidence is a bookkeeping proxy, not
        # a calibrated posterior probability.
        state.uncertainty.overall = max(0.0, min(1.0, 1.0 - report.mean_confidence))
        with self._lock:
            self.state = state
            self.engine = SimulationEngine(SimulationConfig(dt_ms=1.0, update_plasticity=False))
            self.source_label = report_source
            self.parameter_report = report.to_dict()
            self.total_spike_events = 0
            self.run_count = 0
            self.history = []
            self.last_run = {"events": [], "summary": None}
        return {"loaded": True, "connectome": dataset.summary(), "parameter_inference": report.to_dict(),
                "message": "Connectome loaded; missing physiological fields are estimates, not measured values."}

    def load_json_bytes(self, content: bytes, species: str = "fly") -> dict[str, Any]:
        if len(content) > MAX_REQUEST_BYTES:
            raise ValueError(f"Upload is larger than {MAX_REQUEST_BYTES // (1024*1024)} MiB")
        # JSON is parsed through the same validated public loader used by scripts.
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".json", delete=False) as handle:
            path = Path(handle.name)
            handle.write(content)
        try:
            ds = ConnectomeLoader.from_json(path, max_synapses=250_000)
        finally:
            path.unlink(missing_ok=True)
        if len(ds.neurons) > 20_000:
            raise ValueError("Dashboard loading limit is 20,000 neurons; use Python APIs for larger datasets")
        return self._load_dataset(ds, species, f"uploaded local connectome: {ds.metadata.get('source', 'metadata not specified')}")

    def load_flywire(self, data: dict[str, Any]) -> dict[str, Any]:
        from wbe.connectome.flywire_codex import download_connectome
        dataset_name = str(data.get("dataset", "fafb"))
        if dataset_name not in {"fafb", "banc"}:
            raise ValueError("dataset must be fafb or banc")
        max_neurons = min(5000, max(2, int(data.get("max_neurons", 200))))
        max_synapses = min(100_000, max(1, int(data.get("max_synapses", 5000))))
        output = Path("data") / f"flywire_{dataset_name}_sample.json"
        ds = download_connectome(output, dataset=dataset_name, max_neurons=max_neurons,
                                 max_synapses=max_synapses, cache_dir=Path("data") / "raw_connectome")
        result = self._load_dataset(ds, "fly", f"FlyWire Codex {dataset_name}: sampled induced subgraph")
        result["saved_json"] = str(output)
        return result

    def run(self, *, steps: int, target_id: int, amplitude_na: float, duration_steps: int) -> dict[str, Any]:
        if not (1 <= steps <= 2000):
            raise ValueError("steps must be between 1 and 2000")
        if not (-1000 <= amplitude_na <= 1000):
            raise ValueError("amplitude_na must be between -1000 and 1000 nA")
        if not (0 <= duration_steps <= steps):
            raise ValueError("duration_steps must be between 0 and steps")
        with self._lock:
            if target_id not in self.state.neurons:
                raise ValueError(f"Target neuron ID {target_id} is not in the current network")
            events: list[dict[str, Any]] = []
            run_spikes = 0
            n_total = len(self.state.neurons)
            for index in range(steps):
                sensory = {target_id: amplitude_na} if index < duration_steps and amplitude_na != 0 else {}
                result = self.engine.step(self.state, sensory_input=sensory)
                spike_ids = result.extra.get("spiking_neurons", [])
                spike_count = len(spike_ids)
                run_spikes += spike_count
                volts = [n.v_m for n in self.state.neurons.values()]
                item = {
                    "t_ms": round(float(result.t_ms), 4),
                    "spike_count": spike_count,
                    "spiking_neurons": spike_ids[:200],
                    "active_neurons": sum(1 for n in self.state.neurons.values() if n.last_spike_ms is not None),
                    "mean_voltage_mv": round(sum(volts) / len(volts), 5) if volts else None,
                    "mean_calcium": round(sum(n.calcium for n in self.state.neurons.values()) / n_total, 6) if n_total else 0,
                    "pending_events": result.extra.get("pending_events", 0),
                }
                events.append(item)
            self.total_spike_events += run_spikes
            self.run_count += 1
            self.history.extend(events)
            if len(self.history) > 4000:
                self.history = self.history[-4000:]
            duration_s = steps * self.engine.config.dt_ms / 1000.0
            summary = {
                "steps": steps, "simulated_duration_ms": round(steps * self.engine.config.dt_ms, 3),
                "run_spike_events": run_spikes,
                "spike_rate_hz_per_neuron": round(run_spikes / (n_total * duration_s), 5) if duration_s > 0 and n_total else 0,
                "active_neurons": sum(1 for n in self.state.neurons.values() if n.last_spike_ms is not None),
                "mean_voltage_mv": round(sum(n.v_m for n in self.state.neurons.values()) / n_total, 5) if n_total else None,
                "final_time_ms": round(self.state.t_ms, 4),
                "target_id": target_id, "stimulus_na": amplitude_na, "stimulus_duration_ms": duration_steps,
                "data_mode": self.source_label,
            }
            self.last_run = {"events": events, "summary": summary}
            return self.last_run


def make_handler(workbench: SimulationWorkbench):
    class Handler(BaseHTTPRequestHandler):
        server_version = "WBESimulationDashboard/0.3"

        def log_message(self, fmt, *args):
            # Keep console logs small and never print request bodies/tokens.
            print(f"[WBE dashboard] {self.address_string()} - {fmt % args}")

        def _send(self, status: int, payload: Any, content_type: str = "application/json; charset=utf-8"):
            body = payload if isinstance(payload, bytes) else (
                json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8") if content_type.startswith("application/json") else str(payload).encode("utf-8"))
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:")
            self.end_headers()
            self.wfile.write(body)

        def _body(self):
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                raise ValueError("Invalid Content-Length")
            if length < 0 or length > MAX_REQUEST_BYTES:
                raise ValueError(f"Request body exceeds {MAX_REQUEST_BYTES // (1024*1024)} MiB limit")
            raw = self.rfile.read(length) if length else b"{}"
            try:
                result = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                raise ValueError("Body must be valid UTF-8 JSON") from None
            if not isinstance(result, dict):
                raise ValueError("JSON body must be an object")
            return result

        def do_GET(self):
            path = urlparse(self.path).path
            if path == "/" or path == "/index.html":
                try:
                    body = (ROOT / "index.html").read_bytes()
                    self._send(200, body, "text/html; charset=utf-8")
                except OSError:
                    self._send(500, "Dashboard HTML missing", "text/plain; charset=utf-8")
            elif path == "/api/status":
                self._send(200, workbench.status())
            elif path == "/api/health":
                status = workbench.status()
                ok = status["simulation_ready"] and status["self_test"]["passed"]
                self._send(200 if ok else 503, {"ok": bool(ok), "self_test": status["self_test"]})
            else:
                self._send(404, {"error": "Not found"})

        def do_POST(self):
            path = urlparse(self.path).path
            try:
                data = self._body()
                if path == "/api/run":
                    result = workbench.run(steps=int(data.get("steps", 120)),
                        target_id=int(data.get("target_id", 0)),
                        amplitude_na=float(data.get("amplitude_na", 25.0)),
                        duration_steps=int(data.get("duration_steps", 30)))
                    self._send(200, {"ok": True, **result, "status": workbench.status()})
                elif path == "/api/reset":
                    neurons = min(2000, max(2, int(data.get("neurons", 80))))
                    edges = min(10000, max(0, int(data.get("synapses", 320))))
                    seed = int(data.get("seed", 73))
                    with workbench._lock:
                        workbench.state = workbench.factory.synthetic(neurons, edges, seed)
                        workbench.engine = SimulationEngine(SimulationConfig(dt_ms=1.0, update_plasticity=False))
                        workbench.source_label = "synthetic demo network (not biological data)"
                        workbench.parameter_report = None
                        workbench.total_spike_events = 0
                        workbench.run_count = 0
                        workbench.history = []
                        workbench.last_run = {"events": [], "summary": None}
                    self._send(200, {"ok": True, "status": workbench.status()})
                elif path == "/api/load-json":
                    # JSON is passed as a compact string within the request object.
                    raw = data.get("connectome_json")
                    if not isinstance(raw, str):
                        raise ValueError("connectome_json must be a JSON string")
                    species = str(data.get("species", "fly"))
                    if species not in {"fly", "human", "mouse", "mammal", "rat", "vertebrate"}:
                        raise ValueError("unsupported species prior")
                    result = workbench.load_json_bytes(raw.encode("utf-8"), species)
                    self._send(200, {"ok": True, **result, "status": workbench.status()})
                elif path == "/api/import/flywire":
                    result = workbench.load_flywire(data)
                    self._send(200, {"ok": True, **result, "status": workbench.status()})
                else:
                    self._send(404, {"error": "Not found"})
            except ValueError as exc:
                self._send(400, {"ok": False, "error": str(exc)})
            except Exception as exc:
                # Error messages may contain paths but never echo request bodies or API tokens.
                self._send(502, {"ok": False, "error": f"Operation failed: {type(exc).__name__}: {exc}"})

        def do_OPTIONS(self):
            self._send(204, b"", "text/plain; charset=utf-8")

    return Handler


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Run local WBE simulation dashboard")
    parser.add_argument("--host", default="127.0.0.1", help="Keep 127.0.0.1 for local-only use")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    if args.host not in {"127.0.0.1", "localhost", "::1"}:
        print("WARNING: Binding beyond loopback exposes this development dashboard to your network. Do not do this on public networks.")
    app = SimulationWorkbench()
    if not app.self_test["passed"]:
        print("FATAL: simulation engine startup self-test failed:", json.dumps(app.self_test))
        return 2
    server = ThreadingHTTPServer((args.host, args.port), make_handler(app))
    print(f"WBE simulation dashboard: http://{args.host}:{args.port}")
    print("Engine startup self-test PASSED. This confirms code execution, not biological validity.")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
