"""Part 4 result contract, re-exporting the stable shared model."""
from wbe.core.interfaces import SimulationStepResult
__all__ = ["SimulationStepResult"]
