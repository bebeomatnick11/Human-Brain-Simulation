"""Fetch bounded, reproducible FlyWire Codex subgraphs into WBE JSON.

Uses the official Codex static-download endpoints. A Codex API token is required
for resource downloads; set FLYWIRE_CODEX_API_TOKEN in the environment. Tokens
are never written to output files or logs. This downloads a sample/subgraph, not
the complete connectome and not a human connectome.
"""
from __future__ import annotations

import csv
import gzip
import json
import os
import random
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from wbe.connectome.loader import ConnectomeDataset, NeuronRecord, SynapseRecord

BASE = "https://codex.flywire.ai"
USER_AGENT = "WBE-System/0.3 (connectomics research; contact: local user)"


class CodexDownloadError(RuntimeError):
    pass


def _request(url: str, timeout_s: int = 90):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
    try:
        return urllib.request.urlopen(req, timeout=timeout_s)
    except urllib.error.HTTPError as exc:
        # Do not include full URL: API token is a query parameter.
        raise CodexDownloadError(f"Codex request failed with HTTP {exc.code}; check API token, dataset and product name") from None
    except (urllib.error.URLError, TimeoutError) as exc:
        raise CodexDownloadError(f"Could not reach FlyWire Codex: {type(exc).__name__}") from None


def list_products(dataset: str = "fafb", api_token: str | None = None) -> Any:
    token = api_token or os.environ.get("FLYWIRE_CODEX_API_TOKEN")
    params = {"dataset": dataset}
    if token:
        params["api_token"] = token
    url = BASE + "/api/download?" + urllib.parse.urlencode(params)
    with _request(url) as response:
        raw = response.read(10 * 1024 * 1024 + 1)
    if len(raw) > 10 * 1024 * 1024:
        raise CodexDownloadError("Codex product catalogue unexpectedly exceeded 10 MiB")
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        # New/unauthenticated frontends may return HTML rather than JSON.
        raise CodexDownloadError("Codex product catalogue did not return JSON. Check endpoint availability and token permissions.") from None


def _download_resource(dataset: str, product: str, token: str, destination: Path,
                       max_bytes: int = 2_000_000_000) -> Path:
    params = {"dataset": dataset, "data_product": product, "api_token": token}
    url = BASE + "/api/download_resource?" + urllib.parse.urlencode(params)
    destination.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    try:
        with _request(url, timeout_s=180) as response, destination.open("wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise CodexDownloadError(f"Download exceeded safety limit ({max_bytes // (1024*1024)} MiB): {product}")
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    if total == 0:
        destination.unlink(missing_ok=True)
        raise CodexDownloadError(f"Codex returned an empty resource for product '{product}'")
    # Some endpoints can provide an error JSON with HTTP 200.
    with destination.open("rb") as f:
        header = f.read(32)
    if header.lstrip().startswith(b"{"):
        try:
            content = json.loads(destination.read_text(encoding="utf-8"))
            detail = content.get("error") or content.get("message") or "unexpected JSON response"
        except (UnicodeDecodeError, json.JSONDecodeError):
            detail = "unexpected JSON response"
        destination.unlink(missing_ok=True)
        raise CodexDownloadError(f"Codex resource error for '{product}': {detail}")
    return destination


def _open_csv(path: Path):
    with path.open("rb") as raw:
        magic = raw.read(2)
    if magic == b"\x1f\x8b":
        return gzip.open(path, mode="rt", newline="", encoding="utf-8-sig", errors="replace")
    return path.open("r", newline="", encoding="utf-8-sig", errors="replace")


def _normalized_row(row: dict[str, Any]) -> dict[str, Any]:
    return {str(k).strip().lower(): v for k, v in row.items() if k is not None}


def _first(row: dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for key in keys:
        value = row.get(key.lower())
        if value not in (None, "", "null", "None", "nan"):
            return value
    return default


def _as_int(value: Any, field: str) -> int:
    try:
        # Codex root IDs are 64-bit integers; converting through float would lose
        # low-order bits above 2**53. Parse the decimal string as an integer first.
        value_text = str(value).strip()
        number = int(value_text)
        if str(number) != value_text and not value_text.isdigit():
            raise ValueError("not a decimal integer")
    except (TypeError, ValueError, OverflowError):
        raise CodexDownloadError(f"Missing/invalid {field} column value in Codex export") from None
    if number < 0:
        raise CodexDownloadError(f"Negative {field} value in Codex export")
    return number


def _validate_product_name(name: str) -> str:
    safe = "".join(ch for ch in name if ch.isalnum() or ch in "_-.")
    if not safe or safe != name:
        raise ValueError("Product names may contain only letters, digits, underscore, hyphen and period")
    return safe


def download_connectome(
    output_json: str | Path,
    *,
    dataset: str = "fafb",
    max_neurons: int = 500,
    max_synapses: int = 10_000,
    seed: int = 73,
    cache_dir: str | Path | None = None,
    connections_product: str = "connections_princeton",
    cell_types_product: str = "consolidated_cell_types",
    api_token: str | None = None,
    max_download_bytes: int = 2_000_000_000,
) -> ConnectomeDataset:
    """Download the official static CSV products and export an induced subgraph.

    The chosen neuron IDs are a deterministic reservoir sample from IDs observed
    in the connection file. The output contains edges whose endpoints both occur
    in that sample, optionally capped at ``max_synapses`` unique directed edges.
    It is not a whole-brain download; the raw source products are cached on disk.
    """
    token = api_token or os.environ.get("FLYWIRE_CODEX_API_TOKEN")
    if not token:
        raise CodexDownloadError(
            "FLYWIRE_CODEX_API_TOKEN is not set. Create/copy an API token from your Codex account page and set it in the environment."
        )
    if max_neurons < 2:
        raise ValueError("max_neurons must be >= 2")
    if max_synapses < 1:
        raise ValueError("max_synapses must be >= 1")
    connections_product = _validate_product_name(connections_product)
    cell_types_product = _validate_product_name(cell_types_product)
    cache = Path(cache_dir or (Path(output_json).parent / "raw_connectome"))
    cache.mkdir(parents=True, exist_ok=True)
    connections_path = cache / f"{dataset}_{connections_product}.csv.gz"
    cell_types_path = cache / f"{dataset}_{cell_types_product}.csv.gz"
    if not connections_path.exists():
        _download_resource(dataset, connections_product, token, connections_path, max_download_bytes)
    if not cell_types_path.exists():
        _download_resource(dataset, cell_types_product, token, cell_types_path, max_download_bytes)

    # Reservoir sample unique root IDs while streaming the connection file. This
    # avoids retaining millions of rows or selecting only IDs at the start of the
    # file. The `seen_ids` set is small compared with the whole raw synapse table.
    rng = random.Random(seed)
    seen_ids: set[int] = set()
    selected: list[int] = []
    with _open_csv(connections_path) as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise CodexDownloadError("Connections CSV has no header")
        for raw in reader:
            row = _normalized_row(raw)
            pre = _as_int(_first(row, ("pre_root_id", "pre_id", "bodyid_pre", "source", "pre")), "pre_root_id")
            post = _as_int(_first(row, ("post_root_id", "post_id", "bodyid_post", "target", "post")), "post_root_id")
            for nid in (pre, post):
                if nid in seen_ids:
                    continue
                seen_ids.add(nid)
                if len(selected) < max_neurons:
                    selected.append(nid)
                else:
                    replacement = rng.randrange(len(seen_ids))
                    if replacement < max_neurons:
                        selected[replacement] = nid
    selected_set = set(selected)
    if len(selected_set) < 2:
        raise CodexDownloadError("Not enough neuron IDs found in the downloaded connection resource")

    # Collect only within-sample directed pairs and aggregate records split by
    # neuropil. We do not call the synapse count a measured synaptic conductance.
    pairs: dict[tuple[int, int], dict[str, Any]] = {}
    truncated = False
    with _open_csv(connections_path) as f:
        reader = csv.DictReader(f)
        for raw in reader:
            row = _normalized_row(raw)
            pre = _as_int(_first(row, ("pre_root_id", "pre_id", "bodyid_pre", "source", "pre")), "pre_root_id")
            post = _as_int(_first(row, ("post_root_id", "post_id", "bodyid_post", "target", "post")), "post_root_id")
            if pre == post or pre not in selected_set or post not in selected_set:
                continue
            count_raw = _first(row, ("syn_count", "synapse_count", "connection_count", "weight", "count"), 1)
            try:
                count = max(1, int(float(count_raw)))
            except (TypeError, ValueError):
                count = 1
            key = (pre, post)
            if key not in pairs:
                if len(pairs) >= max_synapses:
                    truncated = True
                    break
                pairs[key] = {"count": 0, "nt_type": "unknown", "nt_type_verified": "", "neuropils": set(), "raw_rows": 0}
            item = pairs[key]
            item["count"] += count
            item["raw_rows"] += 1
            nt = str(_first(row, ("nt_type", "neurotransmitter", "transmitter"), "unknown")).strip()
            nt_verified = str(_first(row, ("nt_type_verified", "verified_nt_type"), "")).strip()
            if nt_verified:
                item["nt_type_verified"] = nt_verified
            if nt and nt.lower() not in {"unknown", "nan", "none"}:
                item["nt_type"] = nt
            neuropil = _first(row, ("neuropil", "region", "roi"))
            if neuropil:
                item["neuropils"].add(str(neuropil))

    if not pairs:
        raise CodexDownloadError("No induced edges found among the sampled neurons; increase --max-neurons")

    # Cell annotations are optional at source level; missing rows remain unknown.
    cell_info: dict[int, dict[str, Any]] = {}
    with _open_csv(cell_types_path) as f:
        reader = csv.DictReader(f)
        for raw in reader:
            row = _normalized_row(raw)
            raw_id = _first(row, ("root_id", "rootid", "neuron_id", "body_id", "id"))
            if raw_id is None:
                continue
            try:
                nid = int(str(raw_id).strip())
            except (TypeError, ValueError, OverflowError):
                continue
            if nid in selected_set:
                cell_info[nid] = row

    by_neuron_neuropil: dict[int, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for (pre, post), info in pairs.items():
        for region in info["neuropils"]:
            by_neuron_neuropil[pre][region] += info["count"]
            by_neuron_neuropil[post][region] += info["count"]

    neurons: list[NeuronRecord] = []
    for nid in sorted(selected_set):
        info = cell_info.get(nid, {})
        cell_type = str(_first(info, ("resolved_type", "cell_type", "sub_class", "class", "type", "super_class"), "unknown"))
        nt_type = str(_first(info, ("nt_type_verified", "nt_type"), "unknown"))
        main_neuropil = max(by_neuron_neuropil[nid], key=by_neuron_neuropil[nid].get, default="")
        neurons.append(NeuronRecord(
            neuron_id=nid,
            region="other",
            cell_type=cell_type,
            morphology={},
            position_um=None,
            metadata={
                "source": "FlyWire Codex static download",
                "dataset": dataset,
                "root_id": nid,
                "cell_type": cell_type,
                "super_class": str(_first(info, ("super_class",), "unknown")),
                "sub_class": str(_first(info, ("sub_class",), "unknown")),
                "flow": str(_first(info, ("flow",), "unknown")),
                "nt_type": nt_type,
                "main_neuropil_from_edges": main_neuropil,
                "annotation_available": bool(info),
            },
        ))

    synapses: list[SynapseRecord] = []
    for (pre, post), info in sorted(pairs.items()):
        synapses.append(SynapseRecord(
            pre_id=pre, post_id=post, weight=1.0, delay_ms=1.0, receptor_type="unknown",
            confidence=None,
            metadata={
                "connection_count": int(info["count"]),
                "weight_semantics": "placeholder; connection_count is structural, not measured conductance",
                "nt_type": info["nt_type"],
                "nt_type_verified": info["nt_type_verified"],
                "neuropils": sorted(info["neuropils"]),
                "source_rows_aggregated": info["raw_rows"],
            },
        ))

    result = ConnectomeDataset(neurons, synapses, metadata={
        "source": "FlyWire Codex",
        "dataset": dataset,
        "data_product_connections": connections_product,
        "data_product_cell_types": cell_types_product,
        "seed": seed,
        "sample_method": "reservoir sample of root IDs; induced directed subgraph",
        "source_resource_files": [connections_path.name, cell_types_path.name],
        "max_neurons_requested": max_neurons,
        "selected_neurons": len(neurons),
        "max_synapses_requested": max_synapses,
        "selected_connection_pairs": len(synapses),
        "edge_limit_truncated": truncated,
        "biophysical_parameters_downloaded": False,
        "license_and_citation": "Check the selected Codex download portal for the dataset-specific citation and terms before redistribution.",
    }).validate(max_synapses=max_synapses)

    out = Path(output_json)
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "metadata": result.metadata,
        "neurons": [
            {"neuron_id": n.neuron_id, "region": n.region, "cell_type": n.cell_type,
             "morphology": n.morphology, "position_um": n.position_um, "metadata": n.metadata}
            for n in result.neurons
        ],
        "synapses": [
            {"pre_id": s.pre_id, "post_id": s.post_id, "weight": s.weight,
             "delay_ms": s.delay_ms, "receptor_type": s.receptor_type,
             "confidence": s.confidence, "metadata": s.metadata}
            for s in result.synapses
        ],
    }
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Download a bounded FlyWire Codex connectome subgraph")
    parser.add_argument("--dataset", default="fafb", choices=("fafb", "banc"))
    parser.add_argument("--output", default="data/flywire_sample.json")
    parser.add_argument("--cache-dir", default="data/raw_connectome")
    parser.add_argument("--max-neurons", type=int, default=500)
    parser.add_argument("--max-synapses", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=73)
    parser.add_argument("--connections-product", default="connections_princeton")
    parser.add_argument("--cell-types-product", default="consolidated_cell_types")
    parser.add_argument("--list-products", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.list_products:
            print(json.dumps(list_products(args.dataset), ensure_ascii=False, indent=2))
            return 0
        result = download_connectome(args.output, dataset=args.dataset, max_neurons=args.max_neurons,
            max_synapses=args.max_synapses, seed=args.seed, cache_dir=args.cache_dir,
            connections_product=args.connections_product, cell_types_product=args.cell_types_product)
        print(json.dumps(result.summary(), ensure_ascii=False, indent=2))
        print(f"Saved sampled connectome: {args.output}")
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
