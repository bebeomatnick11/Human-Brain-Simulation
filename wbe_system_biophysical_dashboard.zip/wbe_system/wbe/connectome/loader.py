"""Part 1 — Structural connectome data models and safe importers.

Supported interchange formats: JSON, CSV (neurons.csv + synapses.csv), and
NPZ (neuron_ids, pre_ids, post_ids; optional coordinates/weights). The loader
never downloads datasets implicitly; users must supply local data and license.
"""
from __future__ import annotations
import csv, json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable
import numpy as np


class ConnectomeValidationError(ValueError):
    """Raised when a connectome violates structural invariants."""


@dataclass(frozen=True)
class NeuronRecord:
    neuron_id: int
    region: str = "other"
    cell_type: str = "unknown"
    morphology: dict[str, Any] = field(default_factory=dict)
    position_um: tuple[float, float, float] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SynapseRecord:
    pre_id: int
    post_id: int
    weight: float = 1.0
    delay_ms: float = 1.0
    receptor_type: str = "unknown"
    confidence: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConnectomeDataset:
    neurons: list[NeuronRecord]
    synapses: list[SynapseRecord]
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self, *, allow_self_connections: bool = False, max_synapses: int | None = None) -> "ConnectomeDataset":
        ids = [n.neuron_id for n in self.neurons]
        if len(ids) != len(set(ids)):
            raise ConnectomeValidationError("Duplicate neuron_id values found")
        known = set(ids)
        if max_synapses is not None and len(self.synapses) > max_synapses:
            raise ConnectomeValidationError(f"Synapse count {len(self.synapses)} exceeds limit {max_synapses}")
        seen_edges: set[tuple[int, int]] = set()
        for i, syn in enumerate(self.synapses):
            if syn.pre_id not in known or syn.post_id not in known:
                raise ConnectomeValidationError(f"Synapse row {i} references unknown neuron: {syn.pre_id}->{syn.post_id}")
            if not allow_self_connections and syn.pre_id == syn.post_id:
                raise ConnectomeValidationError(f"Self-connection not allowed: neuron {syn.pre_id}")
            if not np.isfinite(syn.weight):
                raise ConnectomeValidationError(f"Non-finite weight at synapse row {i}")
            if not np.isfinite(syn.delay_ms) or syn.delay_ms < 0:
                raise ConnectomeValidationError(f"Invalid delay_ms at synapse row {i}")
            if syn.confidence is not None and not 0 <= syn.confidence <= 1:
                raise ConnectomeValidationError(f"confidence must be in [0, 1] at synapse row {i}")
        return self

    def summary(self) -> dict[str, Any]:
        return {"n_neurons": len(self.neurons), "n_synapses": len(self.synapses),
                "n_regions": len({n.region for n in self.neurons}), "metadata": self.metadata}


class ConnectomeLoader:
    """Load local connectome exports with aliases for common column names."""
    NEURON_ID_KEYS = ("neuron_id", "id", "root_id", "body_id")
    PRE_KEYS = ("pre_id", "source", "pre", "presynaptic_id", "pre_root_id")
    POST_KEYS = ("post_id", "target", "post", "postsynaptic_id", "post_root_id")

    @staticmethod
    def _first(d: dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
        for key in keys:
            if key in d and d[key] not in (None, ""):
                return d[key]
        return default

    @classmethod
    def from_json(cls, path: str | Path, *, max_synapses: int | None = None) -> ConnectomeDataset:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if isinstance(data, list):
            raise ConnectomeValidationError("JSON root must be an object with neurons and synapses arrays")
        neurons = [cls._neuron_from_dict(x) for x in data.get("neurons", [])]
        synapses = [cls._synapse_from_dict(x) for x in data.get("synapses", [])]
        ds = ConnectomeDataset(neurons, synapses, data.get("metadata", {}))
        return ds.validate(max_synapses=max_synapses)

    @classmethod
    def from_csv(cls, neurons_csv: str | Path, synapses_csv: str | Path, *, max_synapses: int | None = None) -> ConnectomeDataset:
        with open(neurons_csv, newline="", encoding="utf-8-sig") as f:
            neurons = [cls._neuron_from_dict(r) for r in csv.DictReader(f)]
        with open(synapses_csv, newline="", encoding="utf-8-sig") as f:
            synapses = [cls._synapse_from_dict(r) for r in csv.DictReader(f)]
        return ConnectomeDataset(neurons, synapses, {"format": "csv"}).validate(max_synapses=max_synapses)

    @classmethod
    def from_npz(cls, path: str | Path, *, max_synapses: int | None = None) -> ConnectomeDataset:
        with np.load(path, allow_pickle=False) as z:
            required = {"neuron_ids", "pre_ids", "post_ids"}
            missing = required.difference(z.files)
            if missing: raise ConnectomeValidationError(f"NPZ missing arrays: {sorted(missing)}")
            ids = z["neuron_ids"]
            pre, post = z["pre_ids"], z["post_ids"]
            if len(pre) != len(post): raise ConnectomeValidationError("pre_ids and post_ids lengths differ")
            weights = z["weights"] if "weights" in z else np.ones(len(pre))
            delays = z["delays_ms"] if "delays_ms" in z else np.ones(len(pre))
            if len(weights) != len(pre) or len(delays) != len(pre): raise ConnectomeValidationError("Synapse array lengths differ")
            ds = ConnectomeDataset([NeuronRecord(int(i)) for i in ids],
                [SynapseRecord(int(a), int(b), float(w), float(d)) for a,b,w,d in zip(pre,post,weights,delays)],
                {"format":"npz", "source_file":Path(path).name})
        return ds.validate(max_synapses=max_synapses)

    @classmethod
    def _neuron_from_dict(cls, d: dict[str, Any]) -> NeuronRecord:
        nid = cls._first(d, cls.NEURON_ID_KEYS)
        if nid is None: raise ConnectomeValidationError("Neuron row is missing neuron_id/id/root_id")
        pos = None
        if all(k in d and d[k] not in (None, "") for k in ("x", "y", "z")):
            pos = (float(d["x"]), float(d["y"]), float(d["z"]))
        morphology = d.get("morphology", {})
        if isinstance(morphology, str):
            try: morphology = json.loads(morphology) if morphology.strip() else {}
            except json.JSONDecodeError: morphology = {"raw": morphology}
        return NeuronRecord(int(nid), str(d.get("region") or "other"), str(d.get("cell_type") or d.get("type") or "unknown"), morphology or {}, pos, dict(d))

    @classmethod
    def _synapse_from_dict(cls, d: dict[str, Any]) -> SynapseRecord:
        pre, post = cls._first(d, cls.PRE_KEYS), cls._first(d, cls.POST_KEYS)
        if pre is None or post is None: raise ConnectomeValidationError("Synapse row requires pre_id/source and post_id/target")
        conf = d.get("confidence")
        return SynapseRecord(int(pre), int(post), float(d.get("weight") or 1.0), float(d.get("delay_ms") or d.get("delay") or 1.0), str(d.get("receptor_type") or d.get("type") or "unknown"), float(conf) if conf not in (None, "") else None, dict(d))
