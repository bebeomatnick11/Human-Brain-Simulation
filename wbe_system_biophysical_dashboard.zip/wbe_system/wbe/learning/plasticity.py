"""
Part 8: Learning & Self-modification System

Cung cấp các quy tắc plasticity (STDP, reward-modulated, homeostatic, structural)
và engine quản lý việc học của toàn bộ mạng.
"""

from __future__ import annotations
import logging
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
import numpy as np

from wbe.core.interfaces import SynapseState, LearningRule, NeuronState
from wbe.state.brain_state import BrainState, NeuromodulatorField

logger = logging.getLogger(__name__)


class PlasticityType(str, Enum):
    STDP = "stdp"
    REWARD_MODULATED = "reward_modulated"
    HOMEOSTATIC = "homeostatic"
    SHORT_TERM = "short_term"
    STRUCTURAL = "structural"


@dataclass
class STDPParams:
    a_plus: float = 0.01
    a_minus: float = 0.012
    tau_plus_ms: float = 20.0
    tau_minus_ms: float = 20.0
    w_max: float = 5.0
    w_min: float = 0.0


@dataclass
class HomeostaticParams:
    target_rate_hz: float = 5.0
    tau_homeo_ms: float = 1000.0
    strength: float = 0.001


@dataclass
class ShortTermParams:
    u: float = 0.2          # utilization
    tau_rec_ms: float = 200.0
    tau_facil_ms: float = 50.0


class STDPRule(LearningRule):
    """Classic Spike-Timing-Dependent Plasticity."""

    def __init__(self, params: Optional[STDPParams] = None):
        self.params = params or STDPParams()

    def apply(
        self,
        synapse: SynapseState,
        pre_spikes: list[float],
        post_spikes: list[float],
        neuromodulators: Dict[str, float],
        dt_ms: float,
    ) -> SynapseState:
        if not pre_spikes or not post_spikes:
            return synapse

        dw = 0.0
        for t_pre in pre_spikes:
            for t_post in post_spikes:
                dt = t_post - t_pre
                if dt > 0:
                    # LTP
                    dw += self.params.a_plus * np.exp(-dt / self.params.tau_plus_ms)
                elif dt < 0:
                    # LTD
                    dw -= self.params.a_minus * np.exp(dt / self.params.tau_minus_ms)

        new_w = np.clip(
            synapse.weight + dw,
            self.params.w_min,
            self.params.w_max,
        )
        synapse.weight = float(new_w)
        return synapse


class RewardModulatedSTDP(LearningRule):
    """STDP được điều chỉnh bởi dopamine (reward)."""

    def __init__(self, stdp: Optional[STDPRule] = None, dopamine_scale: float = 2.0):
        self.stdp = stdp or STDPRule()
        self.dopamine_scale = dopamine_scale

    def apply(
        self,
        synapse: SynapseState,
        pre_spikes: list[float],
        post_spikes: list[float],
        neuromodulators: Dict[str, float],
        dt_ms: float,
    ) -> SynapseState:
        # First apply normal STDP
        synapse = self.stdp.apply(synapse, pre_spikes, post_spikes, neuromodulators, dt_ms)

        # Modulate by dopamine
        da = neuromodulators.get("dopamine", 0.0)
        if abs(da) > 1e-6:
            # Eligibility trace style (simplified)
            modulation = 1.0 + self.dopamine_scale * da
            synapse.weight = float(np.clip(synapse.weight * modulation, 0.0, 5.0))
        return synapse


class HomeostaticRule(LearningRule):
    """Homeostatic synaptic scaling."""

    def __init__(self, params: Optional[HomeostaticParams] = None):
        self.params = params or HomeostaticParams()
        self._firing_rates: Dict[int, float] = {}

    def update_rate(self, neuron_id: int, rate_hz: float) -> None:
        self._firing_rates[neuron_id] = rate_hz

    def apply(
        self,
        synapse: SynapseState,
        pre_spikes: list[float],
        post_spikes: list[float],
        neuromodulators: Dict[str, float],
        dt_ms: float,
    ) -> SynapseState:
        post_rate = self._firing_rates.get(synapse.post_id, self.params.target_rate_hz)
        error = self.params.target_rate_hz - post_rate
        # Multiplicative scaling
        scale = 1.0 + self.params.strength * error * (dt_ms / self.params.tau_homeo_ms)
        synapse.weight = float(np.clip(synapse.weight * scale, 0.01, 5.0))
        return synapse


class ShortTermPlasticity:
    """Tsodyks-Markram short-term plasticity (facilitation + depression)."""

    def __init__(self, params: Optional[ShortTermParams] = None):
        self.params = params or ShortTermParams()

    def update(self, synapse: SynapseState, spiked: bool, dt_ms: float) -> SynapseState:
        # Recovery of depression
        synapse.depression += (1.0 - synapse.depression) * (dt_ms / self.params.tau_rec_ms)
        # Decay of facilitation
        synapse.facilitation += (self.params.u - synapse.facilitation) * (
            dt_ms / self.params.tau_facil_ms
        )

        if spiked:
            # On spike: use resources and increase facilitation
            effective = synapse.facilitation * synapse.depression
            synapse.depression -= synapse.facilitation * synapse.depression
            synapse.facilitation += self.params.u * (1.0 - synapse.facilitation)
            synapse.meta["effective_weight"] = synapse.weight * effective
        else:
            synapse.meta["effective_weight"] = synapse.weight * synapse.facilitation * synapse.depression

        return synapse


@dataclass
class PlasticityConfig:
    enable_stdp: bool = True
    enable_reward: bool = True
    enable_homeostatic: bool = True
    enable_short_term: bool = True
    enable_structural: bool = False  # expensive
    stdp_params: STDPParams = field(default_factory=STDPParams)
    homeo_params: HomeostaticParams = field(default_factory=HomeostaticParams)
    short_term_params: ShortTermParams = field(default_factory=ShortTermParams)
    structural_growth_rate: float = 1e-6
    structural_prune_threshold: float = 0.05


class PlasticityEngine:
    """
    Engine trung tâm quản lý mọi hình thức học của mạng.
    Gọi sau mỗi bước mô phỏng (hoặc mỗi N bước).
    """

    def __init__(self, config: Optional[PlasticityConfig] = None):
        self.config = config or PlasticityConfig()
        self.stdp = STDPRule(self.config.stdp_params)
        self.reward_stdp = RewardModulatedSTDP(self.stdp)
        self.homeostatic = HomeostaticRule(self.config.homeo_params)
        self.short_term = ShortTermPlasticity(self.config.short_term_params)
        self._step_count = 0
        self._last_structural_check = 0

    def process_synapses(
        self,
        synapses: List[SynapseState],
        spike_times: Dict[int, List[float]],  # neuron_id -> list of spike times in window
        neuromodulators: Dict[str, float],
        dt_ms: float,
    ) -> List[SynapseState]:
        """
        Áp dụng tất cả quy tắc plasticity lên danh sách synapse.
        """
        updated = []
        for syn in synapses:
            pre_spikes = spike_times.get(syn.pre_id, [])
            post_spikes = spike_times.get(syn.post_id, [])

            # Short-term (always, cheap)
            if self.config.enable_short_term:
                spiked = len(pre_spikes) > 0
                syn = self.short_term.update(syn, spiked, dt_ms)

            # Long-term
            if self.config.enable_reward:
                syn = self.reward_stdp.apply(syn, pre_spikes, post_spikes, neuromodulators, dt_ms)
            elif self.config.enable_stdp:
                syn = self.stdp.apply(syn, pre_spikes, post_spikes, neuromodulators, dt_ms)

            if self.config.enable_homeostatic:
                syn = self.homeostatic.apply(syn, pre_spikes, post_spikes, neuromodulators, dt_ms)

            updated.append(syn)

        self._step_count += 1
        return updated

    def update_firing_rates(self, rates: Dict[int, float]) -> None:
        for nid, rate in rates.items():
            self.homeostatic.update_rate(nid, rate)

    def structural_plasticity(
        self,
        state: BrainState,
        activity: Dict[int, float],
    ) -> BrainState:
        """
        Structural plasticity: mọc thêm hoặc cắt bớt synapse.
        Chỉ chạy thưa để tiết kiệm tài nguyên.
        """
        if not self.config.enable_structural:
            return state

        if self._step_count - self._last_structural_check < 1000:
            return state

        self._last_structural_check = self._step_count
        new_synapses = []
        pruned = 0
        grown = 0

        for syn in state.synapses:
            if syn.weight < self.config.structural_prune_threshold:
                pruned += 1
                continue
            new_synapses.append(syn)

        # Simple growth: high activity neurons tend to form new connections
        high_act = [nid for nid, a in activity.items() if a > 10.0]
        if high_act and np.random.random() < self.config.structural_growth_rate * len(high_act):
            pre = int(np.random.choice(high_act))
            post = int(np.random.choice(list(state.neurons.keys())))
            if pre != post:
                new_synapses.append(
                    SynapseState(pre_id=pre, post_id=post, weight=0.3)
                )
                grown += 1

        state.synapses = new_synapses
        if pruned or grown:
            logger.info(f"Structural plasticity: pruned={pruned}, grown={grown}")
        return state

    def get_stats(self) -> Dict[str, Any]:
        return {
            "step_count": self._step_count,
            "config": {
                "stdp": self.config.enable_stdp,
                "reward": self.config.enable_reward,
                "homeostatic": self.config.enable_homeostatic,
                "short_term": self.config.enable_short_term,
                "structural": self.config.enable_structural,
            },
        }
