"""
Part 10: Validation & Verification Framework

Hệ thống kiểm chứng độ trung thực của mô phỏng ở nhiều tầng.
"""

from __future__ import annotations
import logging
from typing import Dict, List, Optional, Any, Callable, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
import numpy as np
from collections import defaultdict

from wbe.core.interfaces import NeuronState, SimulationStepResult
from wbe.state.brain_state import BrainState

logger = logging.getLogger(__name__)


class ValidationLevel(str, Enum):
    CELLULAR = "cellular"
    CIRCUIT = "circuit"
    SYSTEMS = "systems"
    BEHAVIORAL = "behavioral"
    COGNITIVE = "cognitive"
    IDENTITY = "identity"


@dataclass
class ValidationMetric:
    name: str
    level: ValidationLevel
    value: float
    target: Optional[float] = None
    tolerance: float = 0.1
    passed: bool = False
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def evaluate(self) -> bool:
        if self.target is None:
            self.passed = True
            return True
        self.passed = abs(self.value - self.target) <= self.tolerance
        return self.passed


@dataclass
class ValidationReport:
    run_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    metrics: List[ValidationMetric] = field(default_factory=list)
    overall_passed: bool = False
    notes: str = ""

    def add(self, metric: ValidationMetric) -> None:
        metric.evaluate()
        self.metrics.append(metric)

    def finalize(self) -> None:
        self.end_time = datetime.now(timezone.utc)
        self.overall_passed = all(m.passed for m in self.metrics) if self.metrics else False

    def summary(self) -> Dict[str, Any]:
        by_level = defaultdict(list)
        for m in self.metrics:
            by_level[m.level.value].append({
                "name": m.name,
                "value": m.value,
                "target": m.target,
                "passed": m.passed,
            })
        return {
            "run_id": self.run_id,
            "overall_passed": self.overall_passed,
            "n_metrics": len(self.metrics),
            "n_passed": sum(1 for m in self.metrics if m.passed),
            "by_level": dict(by_level),
            "duration_s": (self.end_time - self.start_time).total_seconds() if self.end_time else None,
        }


class CellularValidator:
    """Kiểm tra mức tế bào đơn lẻ."""

    def check_resting_potential(
        self,
        neurons: Dict[int, NeuronState],
        expected_mean: float = -65.0,
        tolerance: float = 10.0,
    ) -> ValidationMetric:
        if not neurons:
            return ValidationMetric(
                name="resting_potential",
                level=ValidationLevel.CELLULAR,
                value=0.0,
                target=expected_mean,
                tolerance=tolerance,
                details={"error": "no neurons"},
            )
        vms = [n.v_m for n in neurons.values()]
        mean_vm = float(np.mean(vms))
        return ValidationMetric(
            name="resting_potential",
            level=ValidationLevel.CELLULAR,
            value=mean_vm,
            target=expected_mean,
            tolerance=tolerance,
            details={"std": float(np.std(vms)), "n": len(vms)},
        )

    def check_spike_rate(
        self,
        spike_counts: Dict[int, int],
        duration_ms: float,
        expected_mean_hz: float = 5.0,
        tolerance: float = 5.0,
    ) -> ValidationMetric:
        if not spike_counts or duration_ms <= 0:
            return ValidationMetric(
                name="mean_firing_rate",
                level=ValidationLevel.CELLULAR,
                value=0.0,
                target=expected_mean_hz,
                tolerance=tolerance,
            )
        rates = [c / (duration_ms / 1000.0) for c in spike_counts.values()]
        mean_rate = float(np.mean(rates))
        return ValidationMetric(
            name="mean_firing_rate",
            level=ValidationLevel.CELLULAR,
            value=mean_rate,
            target=expected_mean_hz,
            tolerance=tolerance,
            details={"std": float(np.std(rates)), "n": len(rates)},
        )


class CircuitValidator:
    """Kiểm tra mức mạch (oscillation, synchrony...)."""

    def check_population_synchrony(
        self,
        spike_times: Dict[int, List[float]],
        window_ms: float = 50.0,
    ) -> ValidationMetric:
        """Đo độ đồng bộ thô bằng cách đếm spike trong cửa sổ."""
        if not spike_times:
            return ValidationMetric(
                name="synchrony_index",
                level=ValidationLevel.CIRCUIT,
                value=0.0,
            )

        all_spikes = []
        for times in spike_times.values():
            all_spikes.extend(times)
        if not all_spikes:
            return ValidationMetric(
                name="synchrony_index",
                level=ValidationLevel.CIRCUIT,
                value=0.0,
            )

        all_spikes = np.array(all_spikes)
        t_min, t_max = all_spikes.min(), all_spikes.max()
        bins = np.arange(t_min, t_max + window_ms, window_ms)
        if len(bins) < 2:
            bins = np.array([t_min, t_min + window_ms], dtype=float)
        hist, _ = np.histogram(all_spikes, bins=bins)
        # Coefficient of variation of bin counts as simple synchrony proxy
        if hist.mean() > 0:
            cv = float(hist.std() / hist.mean())
        else:
            cv = 0.0
        # Higher CV roughly means more bursty/synchronous
        return ValidationMetric(
            name="synchrony_index",
            level=ValidationLevel.CIRCUIT,
            value=cv,
            details={"n_bins": len(hist), "total_spikes": len(all_spikes)},
        )


class SystemsValidator:
    """Kiểm tra mức hệ thống (EEG-like spectrum, network stats)."""

    def check_power_spectrum_proxy(
        self,
        population_activity: np.ndarray,
        fs: float = 1000.0,
    ) -> ValidationMetric:
        """
        Proxy đơn giản cho power spectrum.
        Trong thực tế sẽ so với EEG band power thật.
        """
        if len(population_activity) < 10:
            return ValidationMetric(
                name="alpha_power_proxy",
                level=ValidationLevel.SYSTEMS,
                value=0.0,
            )
        # Simple FFT energy in 8-12 Hz
        from scipy.signal import welch
        freqs, psd = welch(population_activity, fs=fs, nperseg=min(256, len(population_activity)))
        alpha_mask = (freqs >= 8) & (freqs <= 12)
        alpha_power = float(np.trapezoid(psd[alpha_mask], freqs[alpha_mask])) if alpha_mask.any() else 0.0
        return ValidationMetric(
            name="alpha_power_proxy",
            level=ValidationLevel.SYSTEMS,
            value=alpha_power,
            details={"freqs": freqs.tolist()[:20]},
        )


class ValidationSuite:
    """
    Bộ kiểm chứng tổng hợp. Chạy định kỳ trong quá trình mô phỏng.
    """

    def __init__(self, run_id: Optional[str] = None):
        self.run_id = run_id or f"val_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
        self.cellular = CellularValidator()
        self.circuit = CircuitValidator()
        self.systems = SystemsValidator()
        self.history: List[ValidationReport] = []
        self._current: Optional[ValidationReport] = None

    def start_run(self) -> ValidationReport:
        self._current = ValidationReport(
            run_id=self.run_id,
            start_time=datetime.now(timezone.utc),
        )
        return self._current

    def add_metric(self, metric: ValidationMetric) -> None:
        if self._current is None:
            self.start_run()
        self._current.add(metric)

    def run_cellular_checks(
        self,
        neurons: Dict[int, NeuronState],
        spike_counts: Dict[int, int],
        duration_ms: float,
    ) -> None:
        self.add_metric(self.cellular.check_resting_potential(neurons))
        self.add_metric(self.cellular.check_spike_rate(spike_counts, duration_ms))

    def run_circuit_checks(self, spike_times: Dict[int, List[float]]) -> None:
        self.add_metric(self.circuit.check_population_synchrony(spike_times))

    def run_systems_checks(self, population_activity: np.ndarray, fs: float = 1000.0) -> None:
        self.add_metric(self.systems.check_power_spectrum_proxy(population_activity, fs))

    def finalize(self) -> ValidationReport:
        if self._current is None:
            self.start_run()
        self._current.finalize()
        self.history.append(self._current)
        report = self._current
        self._current = None
        logger.info(f"Validation finished: passed={report.overall_passed}")
        return report

    def get_latest_summary(self) -> Dict[str, Any]:
        if not self.history:
            return {"status": "no_runs"}
        return self.history[-1].summary()
