"""Part 5 — Reproducible initial state strategies (synthetic, prior, connectome, personalized)."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import numpy as np
from wbe.core.interfaces import NeuronState, SynapseState, BrainRegion
from wbe.state.brain_state import BrainState, StateSource, StateManager, UncertaintyMap
from wbe.connectome.loader import ConnectomeDataset
from wbe.models.functional import FunctionalParameterSet, FunctionalParameterMapper

@dataclass(frozen=True)
class PersonalizedProfile:
    """Optional measured/prior overrides; this is not a neural scan or mind upload."""
    neuron_voltage_mv: dict[int, float] = field(default_factory=dict)
    neuron_calcium: dict[int, float] = field(default_factory=dict)
    synapse_weight: dict[tuple[int, int], float] = field(default_factory=dict)
    neuromodulators: dict[str, float] = field(default_factory=dict)
    description: str = "Personalized initial profile"

class InitialStateFactory:
    def __init__(self, state_manager: StateManager | None = None):
        self.state_manager = state_manager or StateManager()

    def synthetic(self, n_neurons: int = 100, n_synapses: int = 500, seed: int = 42) -> BrainState:
        if n_neurons < 1: raise ValueError("n_neurons must be >= 1")
        if n_synapses < 0: raise ValueError("n_synapses must be >= 0")
        rng = np.random.default_rng(seed)
        regions = list(BrainRegion)
        neurons = {i: NeuronState(neuron_id=i, region=regions[i % len(regions)], v_m=float(rng.uniform(-68, -62)),
                    intrinsic={"model":"lif", "tau_m_ms":20.0, "resistance_mohm":1.0, "resting_potential_mv":-65.0,
                               "reset_potential_mv":-65.0, "threshold_mv":-50.0, "refractory_ms":2.0,
                               "membrane_capacitance_nf":1.0, "excitability":1.0, "calcium_decay_ms":100.0},
                    calcium=float(rng.uniform(0, .1))) for i in range(n_neurons)}
        synapses: list[SynapseState] = []
        max_edges = n_neurons * max(0, n_neurons - 1)
        n_synapses = min(n_synapses, max_edges)
        seen: set[tuple[int,int]] = set()
        while len(synapses) < n_synapses:
            pre, post = int(rng.integers(n_neurons)), int(rng.integers(n_neurons))
            if pre == post or (pre, post) in seen: continue
            seen.add((pre, post))
            synapses.append(SynapseState(pre_id=pre, post_id=post, weight=float(rng.uniform(.05, 1.0)),
                           delay_ms=float(rng.uniform(.5, 5.0)), receptor_type="inhibitory" if rng.random() < .2 else "excitatory"))
        return BrainState(source=StateSource.SYNTHETIC, description=f"Deterministic synthetic state seed={seed}",
                          neurons=neurons, synapses=synapses,
                          uncertainty=UncertaintyMap(neuron_v_m=.8, synapse_weights=.5, overall=.7),
                          extra={"initialization":{"method":"synthetic", "seed":seed}})

    def from_connectome(self, dataset: ConnectomeDataset, params: FunctionalParameterSet | None = None,
                        source: StateSource = StateSource.POSTMORTEM) -> BrainState:
        dataset.validate()
        neurons, synapses = FunctionalParameterMapper.apply(dataset, params)
        return BrainState(source=source, description="Initialized from supplied structural connectome",
            neurons=neurons, synapses=synapses,
            uncertainty=UncertaintyMap(neuron_v_m=.35, synapse_weights=.25, overall=.4),
            extra={"connectome":dataset.summary(), "initialization":{"method":"connectome"}})

    def prior(self, region_sizes: dict[BrainRegion, int], connectivity_density: float = .01, seed: int = 123) -> BrainState:
        if not 0 <= connectivity_density <= 1: raise ValueError("connectivity_density must be in [0, 1]")
        if any(int(n) < 0 for n in region_sizes.values()): raise ValueError("region sizes cannot be negative")
        rng = np.random.default_rng(seed)
        neurons: dict[int, NeuronState] = {}
        nid = 0
        for region, count in region_sizes.items():
            for _ in range(int(count)):
                neurons[nid] = NeuronState(neuron_id=nid, region=region, v_m=float(rng.normal(-65, 3)), calcium=.1,
                    intrinsic={"model":"lif", "tau_m_ms":20., "resistance_mohm":1., "resting_potential_mv":-65.,
                               "reset_potential_mv":-65., "threshold_mv":-50., "refractory_ms":2., "excitability":1., "calcium_decay_ms":100.})
                nid += 1
        ids = list(neurons)
        possible = len(ids) * max(0, len(ids)-1)
        count = min(possible, int(possible * connectivity_density))
        edges: set[tuple[int,int]] = set()
        while len(edges) < count:
            a, b = int(rng.choice(ids)), int(rng.choice(ids))
            if a != b: edges.add((a,b))
        synapses = [SynapseState(pre_id=a, post_id=b, weight=.5, delay_ms=1.) for a,b in sorted(edges)]
        return BrainState(source=StateSource.STATISTICAL_PRIOR, description="Estimated from explicit statistical priors",
            neurons=neurons, synapses=synapses, uncertainty=UncertaintyMap(overall=.8),
            extra={"initialization":{"method":"prior", "seed":seed, "connectivity_density":connectivity_density}})

    def personalized(self, base: BrainState, profile: PersonalizedProfile) -> BrainState:
        state = base.model_copy(deep=True)
        for nid, value in profile.neuron_voltage_mv.items():
            if nid not in state.neurons: raise KeyError(f"profile references unknown neuron {nid}")
            state.neurons[nid].v_m = float(value)
        for nid, value in profile.neuron_calcium.items():
            if nid not in state.neurons: raise KeyError(f"profile references unknown neuron {nid}")
            state.neurons[nid].calcium = max(0.0, float(value))
        for edge, value in profile.synapse_weight.items():
            matches = [s for s in state.synapses if (s.pre_id,s.post_id) == edge]
            if not matches: raise KeyError(f"profile references unknown synapse {edge}")
            for syn in matches: syn.weight = float(value)
        for name, value in profile.neuromodulators.items():
            if name in {"dopamine", "serotonin", "acetylcholine", "norepinephrine"}:
                setattr(state.neuromodulators, name, float(value))
            else: state.neuromodulators.extra[name] = float(value)
        state.source = StateSource.PERSONALIZED
        state.description = profile.description
        state.extra.setdefault("initialization", {})["method"] = "personalized"
        return state
