"""Part 2 — Functional properties with explicit units and safe defaults."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import math
from wbe.core.interfaces import NeuronState, SynapseState, BrainRegion
from wbe.connectome.loader import ConnectomeDataset

@dataclass(frozen=True)
class NeuronParameters:
    model: str = "lif"
    tau_m_ms: float = 20.0
    resistance_mohm: float = 1.0
    resting_potential_mv: float = -65.0
    reset_potential_mv: float = -65.0
    threshold_mv: float = -50.0
    refractory_ms: float = 2.0
    membrane_capacitance_nf: float = 1.0
    excitability: float = 1.0
    calcium_decay_ms: float = 100.0
    def validate(self) -> "NeuronParameters":
        if self.tau_m_ms <= 0 or self.resistance_mohm <= 0 or self.membrane_capacitance_nf <= 0:
            raise ValueError("tau_m_ms, resistance_mohm and membrane_capacitance_nf must be > 0")
        if self.refractory_ms < 0 or self.calcium_decay_ms <= 0: raise ValueError("Invalid refractory/calcium time constant")
        if self.threshold_mv <= self.reset_potential_mv or self.threshold_mv <= self.resting_potential_mv:
            raise ValueError("threshold_mv must exceed reset/resting potential")
        if not math.isfinite(self.excitability) or self.excitability < 0: raise ValueError("excitability must be finite and >= 0")
        return self

@dataclass(frozen=True)
class SynapseParameters:
    receptor_type: str = "excitatory"  # excitatory, inhibitory, modulatory
    delay_ms: float = 1.0
    weight: float = 1.0
    reversal_potential_mv: float | None = None
    stp_enabled: bool = True
    neuromodulator_sensitivity: dict[str, float] = field(default_factory=dict)
    def validate(self) -> "SynapseParameters":
        if self.delay_ms < 0 or not math.isfinite(self.delay_ms): raise ValueError("delay_ms must be finite and >= 0")
        if not math.isfinite(self.weight): raise ValueError("weight must be finite")
        if self.receptor_type not in {"excitatory", "inhibitory", "modulatory", "unknown"}: raise ValueError(f"Unsupported receptor_type: {self.receptor_type}")
        return self

@dataclass
class FunctionalParameterSet:
    neuron_defaults: NeuronParameters = field(default_factory=NeuronParameters)
    synapse_defaults: SynapseParameters = field(default_factory=SynapseParameters)
    neuron_overrides: dict[int, dict[str, Any]] = field(default_factory=dict)
    synapse_overrides: dict[tuple[int, int], dict[str, Any]] = field(default_factory=dict)
    # Additive audit metadata: source/method/confidence for inferred values.
    inference_metadata: dict[int, dict[str, Any]] = field(default_factory=dict)

    def neuron_for(self, neuron_id: int) -> NeuronParameters:
        return NeuronParameters(**{**self.neuron_defaults.__dict__, **self.neuron_overrides.get(int(neuron_id), {})}).validate()
    def synapse_for(self, pre_id: int, post_id: int) -> SynapseParameters:
        return SynapseParameters(**{**self.synapse_defaults.__dict__, **self.synapse_overrides.get((int(pre_id), int(post_id)), {})}).validate()

class FunctionalParameterMapper:
    """Maps structural records onto the existing Parts 6-10 state contract."""
    @staticmethod
    def apply(dataset: ConnectomeDataset, params: FunctionalParameterSet | None = None) -> tuple[dict[int, NeuronState], list[SynapseState]]:
        params = params or FunctionalParameterSet()
        neurons: dict[int, NeuronState] = {}
        region_map = {r.value: r for r in BrainRegion}
        for n in dataset.neurons:
            p = params.neuron_for(n.neuron_id)
            region = region_map.get(n.region.lower(), BrainRegion.OTHER)
            neurons[n.neuron_id] = NeuronState(neuron_id=n.neuron_id, region=region, v_m=p.resting_potential_mv,
                intrinsic=p.__dict__.copy(), resources={"excitability": p.excitability}, meta={"cell_type": n.cell_type, "morphology": n.morphology, "position_um": n.position_um, "source_metadata": dict(n.metadata), "parameter_inference": dict(params.inference_metadata.get(int(n.neuron_id), {}))})
        synapses: list[SynapseState] = []
        for s in dataset.synapses:
            override = params.synapse_overrides.get((int(s.pre_id), int(s.post_id)), {})
            p = params.synapse_for(s.pre_id, s.post_id)
            # Structural measurements are the default source for weight/delay/type;
            # an explicit functional override wins even when its value is exactly 1.0.
            weight = float(override["weight"]) if "weight" in override else float(s.weight)
            delay = float(override["delay_ms"]) if "delay_ms" in override else float(s.delay_ms)
            receptor = str(override["receptor_type"]) if "receptor_type" in override else s.receptor_type
            synapses.append(SynapseState(pre_id=s.pre_id, post_id=s.post_id, weight=weight,
                delay_ms=delay, receptor_type=receptor,
                meta={"reversal_potential_mv": p.reversal_potential_mv, "stp_enabled": p.stp_enabled,
                      "neuromodulator_sensitivity": p.neuromodulator_sensitivity, "source_metadata": s.metadata}))
        return neurons, synapses
