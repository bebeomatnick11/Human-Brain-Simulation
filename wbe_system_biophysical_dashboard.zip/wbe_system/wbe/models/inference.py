"""Part 2 — auditable functional-parameter inference.

Important: connectome edges do not determine electrophysiology. This module uses,
in order: measured fields already present in source metadata, explicit morphology
+ user-specified passive membrane constants, optional empirical reference rows,
and finally configurable low-confidence priors. Every inferred value carries a
provenance record; estimates are not presented as measurements.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
import csv
import math
from pathlib import Path
from typing import Any

import numpy as np

from wbe.connectome.loader import ConnectomeDataset
from wbe.models.functional import FunctionalParameterSet, NeuronParameters, SynapseParameters


_NEURON_ALIASES = {
    "tau_m_ms": ("tau_m_ms", "membrane_time_constant_ms", "tau_ms"),
    "resistance_mohm": ("resistance_mohm", "input_resistance_mohm", "input_resistance_MOhm"),
    "membrane_capacitance_nf": ("membrane_capacitance_nf", "capacitance_nf", "cm_nF"),
    "resting_potential_mv": ("resting_potential_mv", "v_rest_mv", "resting_mv"),
    "reset_potential_mv": ("reset_potential_mv", "v_reset_mv"),
    "threshold_mv": ("threshold_mv", "spike_threshold_mv", "v_threshold_mv"),
    "refractory_ms": ("refractory_ms", "refractory_period_ms"),
    "excitability": ("excitability",),
    "calcium_decay_ms": ("calcium_decay_ms",),
}
_NUMERIC_NEURON_KEYS = set(_NEURON_ALIASES)


def _first_present(mapping: dict[str, Any], names: tuple[str, ...]) -> Any:
    for name in names:
        value = mapping.get(name)
        if value not in (None, ""):
            try:
                value = float(value)
                if math.isfinite(value):
                    return value
            except (TypeError, ValueError):
                continue
    return None


def _flatten_metadata(meta: dict[str, Any]) -> dict[str, Any]:
    """Combine commonly used nested parameter bags without overwriting top-level fields."""
    merged: dict[str, Any] = {}
    for key in ("morphology", "intrinsic", "physiology", "parameters", "metadata"):
        value = meta.get(key)
        if isinstance(value, dict):
            merged.update(value)
    merged.update(meta)
    return merged


@dataclass(frozen=True)
class InferenceConfig:
    """Configurable LIF prior; units are documented in field names.

    The generic numbers below are engineering priors for starting a model, not
    species-specific measured truth. Provide empirical reference CSV data to
    calibrate them for a particular species, cell type, and experimental regime.
    """
    species: str = "fly"
    seed: int = 412
    tau_m_range_ms: tuple[float, float] = (8.0, 25.0)
    resistance_range_mohm: tuple[float, float] = (40.0, 180.0)
    resting_potential_range_mv: tuple[float, float] = (-68.0, -58.0)
    threshold_delta_range_mv: tuple[float, float] = (12.0, 20.0)
    refractory_range_ms: tuple[float, float] = (1.0, 3.0)
    calcium_decay_range_ms: tuple[float, float] = (50.0, 150.0)
    synapse_gain_na: float = 1.0
    specific_capacitance_uF_cm2: float | None = None
    specific_membrane_resistance_ohm_cm2: float | None = None
    reference_csv: str | None = None

    def validate(self) -> "InferenceConfig":
        for name in ("tau_m_range_ms", "resistance_range_mohm", "resting_potential_range_mv",
                     "threshold_delta_range_mv", "refractory_range_ms", "calcium_decay_range_ms"):
            lo, hi = getattr(self, name)
            if not (math.isfinite(lo) and math.isfinite(hi) and lo <= hi):
                raise ValueError(f"Invalid range: {name}")
        if self.tau_m_range_ms[0] <= 0 or self.resistance_range_mohm[0] <= 0:
            raise ValueError("tau and resistance ranges must be positive")
        if self.synapse_gain_na <= 0 or not math.isfinite(self.synapse_gain_na):
            raise ValueError("synapse_gain_na must be finite and > 0")
        return self


@dataclass
class ParameterInferenceReport:
    species: str
    neuron_count: int = 0
    neuron_measured_count: int = 0
    neuron_morphology_derived_count: int = 0
    neuron_reference_matched_count: int = 0
    neuron_prior_count: int = 0
    synapse_count: int = 0
    synapse_annotation_count: int = 0
    synapse_unknown_sign_count: int = 0
    mean_confidence: float = 0.0
    warnings: list[str] = field(default_factory=list)
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "species": self.species,
            "neuron_count": self.neuron_count,
            "neuron_measured_count": self.neuron_measured_count,
            "neuron_morphology_derived_count": self.neuron_morphology_derived_count,
            "neuron_reference_matched_count": self.neuron_reference_matched_count,
            "neuron_prior_count": self.neuron_prior_count,
            "synapse_count": self.synapse_count,
            "synapse_annotation_count": self.synapse_annotation_count,
            "synapse_unknown_sign_count": self.synapse_unknown_sign_count,
            "mean_confidence": round(self.mean_confidence, 4),
            "warnings": self.warnings,
            "provenance": self.provenance,
        }


class ParameterInferenceEngine:
    """Infer a FunctionalParameterSet using explicit provenance and uncertainty."""

    def __init__(self, config: InferenceConfig | None = None):
        self.config = (config or InferenceConfig()).validate()
        self._references = self._load_reference_csv(self.config.reference_csv)

    @staticmethod
    def _load_reference_csv(path: str | None) -> dict[str, dict[str, float]]:
        """Read optional empirical table with cell_type/type and parameter columns.

        Duplicate rows are pooled by arithmetic median. Missing or malformed cells
        are skipped. The file's source and experimental conditions should be
        documented by its provider; no reference data is downloaded implicitly.
        """
        if not path:
            return {}
        p = Path(path)
        if not p.is_file():
            raise FileNotFoundError(f"Physiology reference CSV not found: {p}")
        grouped: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
        with p.open(newline="", encoding="utf-8-sig") as handle:
            for row in csv.DictReader(handle):
                cell_type = str(row.get("cell_type") or row.get("type") or row.get("class") or "").strip().lower()
                if not cell_type:
                    continue
                for field_name, aliases in _NEURON_ALIASES.items():
                    if field_name in {"resting_potential_mv", "threshold_mv", "reset_potential_mv", "excitability", "refractory_ms", "calcium_decay_ms", "tau_m_ms", "resistance_mohm", "membrane_capacitance_nf"}:
                        value = _first_present(row, aliases)
                        if value is not None:
                            grouped[cell_type][field_name].append(value)
        result: dict[str, dict[str, float]] = {}
        for cell_type, fields in grouped.items():
            result[cell_type] = {k: float(np.median(v)) for k, v in fields.items() if v}
        return result

    def infer(self, dataset: ConnectomeDataset) -> tuple[FunctionalParameterSet, ParameterInferenceReport]:
        dataset.validate()
        cfg = self.config
        rng = np.random.default_rng(cfg.seed)
        report = ParameterInferenceReport(species=cfg.species, neuron_count=len(dataset.neurons),
                                          synapse_count=len(dataset.synapses))
        overrides: dict[int, dict[str, Any]] = {}
        confidences: list[float] = []
        method_counts = defaultdict(int)
        inference_details: dict[int, dict[str, Any]] = {}

        for neuron in dataset.neurons:
            md = _flatten_metadata(dict(neuron.metadata or {}))
            md.update(neuron.morphology if isinstance(neuron.morphology, dict) else {})
            cell_type = str(md.get("cell_type") or md.get("resolved_type") or md.get("type") or neuron.cell_type or "unknown")
            key = cell_type.strip().lower()
            reference = self._references.get(key) or {}
            # Exact values in source metadata are treated as observed only when the
            # source explicitly contains the parameter; morphology alone is not a measurement.
            values: dict[str, float] = {}
            observed: set[str] = set()
            derived: set[str] = set()
            evidence_derived: set[str] = set()
            referenced: set[str] = set()
            for name, aliases in _NEURON_ALIASES.items():
                value = _first_present(md, aliases)
                if value is not None:
                    values[name] = value
                    observed.add(name)

            # Compute C and R from morphology only when the user supplied membrane
            # constants. Dimensions: C[nF] = area[um²] * Cm[µF/cm²] * 1e-5.
            area = _first_present(md, ("surface_area_um2", "membrane_area_um2", "soma_surface_area_um2"))
            if area is not None and area > 0 and cfg.specific_capacitance_uF_cm2 and "membrane_capacitance_nf" not in values:
                values["membrane_capacitance_nf"] = area * cfg.specific_capacitance_uF_cm2 * 1e-5
                derived.add("membrane_capacitance_nf")
                evidence_derived.add("membrane_capacitance_nf")
            if area is not None and area > 0 and cfg.specific_membrane_resistance_ohm_cm2 and "resistance_mohm" not in values:
                values["resistance_mohm"] = 100.0 * cfg.specific_membrane_resistance_ohm_cm2 / area
                derived.add("resistance_mohm")
                evidence_derived.add("resistance_mohm")

            for name, value in reference.items():
                if name not in values:
                    values[name] = value
                    referenced.add(name)

            # Tau = R[MΩ] * C[nF] in ms. Derive it if both underlying quantities
            # are known, before falling back to a prior.
            evidence_fields = observed | referenced | evidence_derived
            if "tau_m_ms" not in values and "resistance_mohm" in values and "membrane_capacitance_nf" in values:
                values["tau_m_ms"] = values["resistance_mohm"] * values["membrane_capacitance_nf"]
                derived.add("tau_m_ms")
                if {"resistance_mohm", "membrane_capacitance_nf"}.issubset(evidence_fields):
                    evidence_derived.add("tau_m_ms")
            if "membrane_capacitance_nf" not in values and "tau_m_ms" in values and "resistance_mohm" in values:
                values["membrane_capacitance_nf"] = values["tau_m_ms"] / values["resistance_mohm"]
                derived.add("membrane_capacitance_nf")
                if {"tau_m_ms", "resistance_mohm"}.issubset(evidence_fields):
                    evidence_derived.add("membrane_capacitance_nf")
            if "resistance_mohm" not in values and "tau_m_ms" in values and "membrane_capacitance_nf" in values:
                values["resistance_mohm"] = values["tau_m_ms"] / values["membrane_capacitance_nf"]
                derived.add("resistance_mohm")
                if {"tau_m_ms", "membrane_capacitance_nf"}.issubset(evidence_fields):
                    evidence_derived.add("resistance_mohm")

            # The defaults are priors with random but reproducible cell-level
            # variation; they are intentionally marked low-confidence.
            def prior(name: str, pair: tuple[float, float]) -> float:
                value = float(rng.uniform(pair[0], pair[1]))
                values[name] = value
                return value

            for field_name in ("tau_m_ms", "resistance_mohm"):
                if field_name not in values:
                    pair = cfg.tau_m_range_ms if field_name == "tau_m_ms" else cfg.resistance_range_mohm
                    prior(field_name, pair)
            # Keep passive parameters internally coherent when the prior supplies
            # tau and R but no C: use tau/R rather than independent random numbers.
            if "membrane_capacitance_nf" not in values:
                values["membrane_capacitance_nf"] = values["tau_m_ms"] / values["resistance_mohm"]
                derived.add("membrane_capacitance_nf")
            if "resting_potential_mv" not in values:
                prior("resting_potential_mv", cfg.resting_potential_range_mv)
            if "threshold_mv" not in values:
                delta = float(rng.uniform(*cfg.threshold_delta_range_mv))
                values["threshold_mv"] = values["resting_potential_mv"] + delta
            if "reset_potential_mv" not in values:
                values["reset_potential_mv"] = values["resting_potential_mv"]
            if "refractory_ms" not in values:
                prior("refractory_ms", cfg.refractory_range_ms)
            if "calcium_decay_ms" not in values:
                prior("calcium_decay_ms", cfg.calcium_decay_range_ms)
            if "excitability" not in values:
                values["excitability"] = 1.0

            # Validate the inferred record through the public model. Invalid source
            # measurements are not silently replaced: surface the source error.
            values = {k: float(v) for k, v in values.items() if k in _NUMERIC_NEURON_KEYS}
            try:
                NeuronParameters(**values).validate()
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Invalid inferred/source neuron parameters for neuron {neuron.neuron_id} ({cell_type}): {exc}") from exc
            if observed:
                method = "source_metadata"
                confidence = 0.25 + 0.75 * len(observed) / max(1, len(_NUMERIC_NEURON_KEYS))
                report.neuron_measured_count += 1
            elif referenced:
                method = "empirical_reference_csv"
                confidence = 0.45 + 0.30 * len(referenced) / max(1, len(_NUMERIC_NEURON_KEYS))
                report.neuron_reference_matched_count += 1
            elif evidence_derived:
                method = "morphology_or_equation_plus_prior"
                confidence = 0.40
                report.neuron_morphology_derived_count += 1
            else:
                method = "configurable_low_confidence_prior"
                confidence = 0.25
                report.neuron_prior_count += 1
            method_counts[method] += 1
            confidences.append(confidence)
            overrides[int(neuron.neuron_id)] = values
            inference_details[int(neuron.neuron_id)] = {
                "method": method, "confidence": confidence, "species_prior": cfg.species,
                "measured_fields": sorted(observed), "derived_fields": sorted(derived),
                "evidence_derived_fields": sorted(evidence_derived), "reference_fields": sorted(referenced),
                "reference_csv": cfg.reference_csv,
                "note": "This parameter set may contain priors; confidence is an engineering score, not a calibrated posterior probability." if method != "source_metadata" else "Confidence reflects fraction of parameter fields observed in source metadata."
            }

        incoming_max: dict[int, float] = defaultdict(float)
        for syn in dataset.synapses:
            connection_count = _first_present(dict(syn.metadata or {}), ("connection_count", "synapse_count", "syn_count", "weight"))
            count = max(1.0, float(connection_count if connection_count is not None else syn.weight))
            incoming_max[syn.post_id] = max(incoming_max[syn.post_id], math.log1p(count))

        synapse_overrides: dict[tuple[int, int], dict[str, Any]] = {}
        for syn in dataset.synapses:
            smd = dict(syn.metadata or {})
            raw_nt = str(smd.get("nt_type_verified") or smd.get("nt_type") or smd.get("neurotransmitter") or "").strip().lower()
            receptor_explicit = str(smd.get("receptor_type") or syn.receptor_type or "").strip().lower()
            if receptor_explicit in {"inhibitory", "excitatory", "modulatory", "unknown"} and receptor_explicit != "unknown":
                receptor = receptor_explicit
                ann_conf = 0.95
                annotated = True
            else:
                receptor, annotated = self._receptor_from_nt(raw_nt, cfg.species)
                ann_conf = 0.8 if annotated else 0.1
            connection_count_value = _first_present(smd, ("connection_count", "synapse_count", "syn_count"))
            if connection_count_value is None:
                connection_count_value = float(syn.weight)
            normalized = math.log1p(max(1.0, connection_count_value)) / max(incoming_max[syn.post_id], 1e-9)
            # This maps structural edge size to a bounded model gain; it does NOT
            # claim to reconstruct measured postsynaptic conductance.
            inferred_gain = cfg.synapse_gain_na * min(1.0, max(0.05, normalized))
            synapse_overrides[(int(syn.pre_id), int(syn.post_id))] = {
                "weight": float(inferred_gain),
                "receptor_type": receptor,
                "delay_ms": float(syn.delay_ms),
            }
            if annotated:
                report.synapse_annotation_count += 1
            else:
                report.synapse_unknown_sign_count += 1

        report.mean_confidence = float(np.mean(confidences)) if confidences else 0.0
        if report.neuron_prior_count:
            report.warnings.append(f"{report.neuron_prior_count} neuron(s) use configurable low-confidence physiological priors")
        if report.synapse_unknown_sign_count:
            report.warnings.append(f"{report.synapse_unknown_sign_count} synapse(s) have unknown transmitter/receptor sign and should remain neutral until annotated")
        if not self._references:
            report.warnings.append("No empirical physiology reference CSV loaded; missing values use priors/equations")
        report.provenance = {
            "config": {"species": cfg.species, "seed": cfg.seed,
                "tau_m_range_ms": list(cfg.tau_m_range_ms), "resistance_range_mohm": list(cfg.resistance_range_mohm),
                "resting_potential_range_mv": list(cfg.resting_potential_range_mv), "synapse_gain_na": cfg.synapse_gain_na},
            "method_counts": dict(method_counts),
            "reference_csv": cfg.reference_csv,
            "inference_version": "1.0",
        }
        inference_metadata = inference_details
        return FunctionalParameterSet(neuron_defaults=NeuronParameters(), synapse_defaults=SynapseParameters(),
                                      neuron_overrides=overrides, synapse_overrides=synapse_overrides,
                                      inference_metadata=inference_metadata), report

    @staticmethod
    def _receptor_from_nt(nt_type: str, species: str) -> tuple[str, bool]:
        nt = nt_type.lower().replace("-", "_").replace(" ", "_")
        if not nt or nt in {"none", "nan", "unknown", "untyped"}:
            return "unknown", False
        if any(key in nt for key in ("gaba", "glycine", "glycinergic")):
            return "inhibitory", True
        if any(key in nt for key in ("dopamine", "serotonin", "octopamine", "tyramine", "histamine", "neuromodulator")):
            return "modulatory", True
        if "acetylcholine" in nt or nt in {"ach", "acetylcholine", "ach_like"}:
            return "excitatory", True
        if any(key in nt for key in ("glutamate", "glutamatergic", "glu")):
            if species.lower() in {"human", "mouse", "mammal", "rat", "vertebrate"}:
                return "excitatory", True
            # For insect neurons, glutamatergic signaling may be excitatory or
            # inhibitory by receptor; neurotransmitter alone does not settle sign.
            return "unknown", False
        return "unknown", False
