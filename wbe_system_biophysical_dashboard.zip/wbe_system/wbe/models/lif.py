"""Part 3 — Leaky integrate-and-fire neuron model."""
from __future__ import annotations
from dataclasses import dataclass
from wbe.core.interfaces import NeuronState
from wbe.models.functional import NeuronParameters

@dataclass(frozen=True)
class NeuronStep:
    voltage_mv: float
    spiked: bool
    calcium: float
    refractory_until_ms: float

class LIFNeuronModel:
    """Current-based LIF stepper. Inputs are nA, time constants are ms, V is mV.

    Units are internally consistent at this abstraction level: R[mV/nA] * I[nA]
    produces a voltage change in mV. It is a simplified point-neuron model, not a
    detailed biophysical neuron or a claim of biological equivalence.
    """
    def step(self, state: NeuronState, current_na: float, t_ms: float, dt_ms: float,
             params: NeuronParameters | None = None) -> NeuronStep:
        p = params or NeuronParameters(**{k:v for k,v in state.intrinsic.items() if k in NeuronParameters.__dataclass_fields__})
        p.validate()
        if dt_ms <= 0: raise ValueError("dt_ms must be > 0")
        v = float(state.v_m)
        calcium = float(state.calcium)
        calcium *= max(0.0, 1.0 - dt_ms / p.calcium_decay_ms)
        if t_ms < state.refractory_until_ms:
            return NeuronStep(p.reset_potential_mv, False, calcium, state.refractory_until_ms)
        dv = ((p.resting_potential_mv - v) + p.resistance_mohm * float(current_na) * p.excitability) * (dt_ms / p.tau_m_ms)
        v += dv
        if v >= p.threshold_mv:
            calcium += 1.0
            return NeuronStep(p.reset_potential_mv, True, calcium, t_ms + p.refractory_ms)
        return NeuronStep(v, False, calcium, state.refractory_until_ms)
