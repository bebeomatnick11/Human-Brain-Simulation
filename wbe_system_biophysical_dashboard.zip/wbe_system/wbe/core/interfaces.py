"""
Core interfaces that Parts 6-10 expose to the user's Simulation Engine (Part 4-5).
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple, Protocol
from enum import Enum
import numpy as np
from pydantic import BaseModel, Field
from datetime import datetime


class Precision(str, Enum):
    FP32 = "fp32"
    FP16 = "fp16"
    BF16 = "bf16"
    INT8 = "int8"
    MIXED = "mixed"


class HardwareBackend(str, Enum):
    CPU = "cpu"
    CUDA = "cuda"
    ROCM = "rocm"
    NEUROMORPHIC = "neuromorphic"
    SIMULATED = "simulated"


class BrainRegion(str, Enum):
    """High-level brain regions for hierarchical scheduling."""
    CORTEX = "cortex"
    HIPPOCAMPUS = "hippocampus"
    THALAMUS = "thalamus"
    BASAL_GANGLIA = "basal_ganglia"
    CEREBELLUM = "cerebellum"
    BRAINSTEM = "brainstem"
    OTHER = "other"


class NeuronState(BaseModel):
    """Minimal neuron state that learning & validation systems expect."""
    neuron_id: int
    region: BrainRegion = BrainRegion.OTHER
    v_m: float = Field(..., description="Membrane potential (mV)")
    spikes: list[float] = Field(default_factory=list, description="Spike times (ms)")
    calcium: float = 0.0
    resources: Dict[str, float] = Field(default_factory=dict)
    # Additive Part 1-5 fields; defaults preserve compatibility with Parts 6-10.
    intrinsic: Dict[str, Any] = Field(default_factory=dict)
    meta: Dict[str, Any] = Field(default_factory=dict)
    refractory_until_ms: float = 0.0
    last_spike_ms: Optional[float] = None


class SynapseState(BaseModel):
    pre_id: int
    post_id: int
    weight: float
    delay_ms: float = 1.0
    last_pre_spike: Optional[float] = None
    last_post_spike: Optional[float] = None
    facilitation: float = 1.0
    depression: float = 1.0
    receptor_type: str = "excitatory"
    meta: Dict[str, Any] = Field(default_factory=dict)


class SimulationStepResult(BaseModel):
    """What the user's engine should return after each step."""
    t_ms: float
    neuron_states: Dict[int, NeuronState]
    synapse_updates: list[SynapseState] = Field(default_factory=list)
    neuromodulators: Dict[str, float] = Field(default_factory=dict)
    extra: Dict[str, Any] = Field(default_factory=dict)
    motor_activities: Dict[int, float] = Field(default_factory=dict)


class HardwareAllocator(Protocol):
    def allocate(self, region: BrainRegion, n_neurons: int, n_synapses: int) -> str:
        """Return a device/handle id."""
        ...

    def free(self, handle: str) -> None:
        ...


class StateStore(Protocol):
    def save_checkpoint(self, path: str, state: Any) -> None:
        ...

    def load_checkpoint(self, path: str) -> Any:
        ...


class LearningRule(ABC):
    @abstractmethod
    def apply(
        self,
        synapse: SynapseState,
        pre_spikes: list[float],
        post_spikes: list[float],
        neuromodulators: Dict[str, float],
        dt_ms: float,
    ) -> SynapseState:
        ...


class SensoryEncoder(ABC):
    @abstractmethod
    def encode(self, raw_input: Any, t_ms: float) -> Dict[int, float]:
        """Return dict of neuron_id -> current (nA) or spike probability."""
        ...


class MotorDecoder(ABC):
    @abstractmethod
    def decode(self, motor_neuron_activities: Dict[int, float], t_ms: float) -> Any:
        ...
