"""
Part 9: Sensorimotor Interface

Cung cấp lớp giao tiếp giữa não mô phỏng và thế giới bên ngoài
(virtual body hoặc robot thật).
"""

from __future__ import annotations
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import numpy as np
from abc import ABC, abstractmethod

from wbe.core.interfaces import SensoryEncoder, MotorDecoder

logger = logging.getLogger(__name__)


class Modality(str, Enum):
    VISION = "vision"
    AUDITION = "audition"
    TOUCH = "touch"
    PROPRIOCEPTION = "proprioception"
    INTEROCEPTION = "interoception"
    OLFACTION = "olfaction"
    GUSTATION = "gustation"
    MOTOR = "motor"


@dataclass
class SensoryPacket:
    modality: Modality
    t_ms: float
    data: Any
    source: str = "virtual"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MotorCommand:
    t_ms: float
    joint_targets: Dict[str, float] = field(default_factory=dict)  # joint_name -> angle/torque
    muscle_activations: Dict[str, float] = field(default_factory=dict)
    raw: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class SimpleVisionEncoder(SensoryEncoder):
    """
    Encoder thị giác đơn giản: chuyển ảnh thành current inject vào population neuron.
    Trong thực tế sẽ thay bằng retina model chi tiết.
    """

    def __init__(self, neuron_ids: List[int], input_shape: tuple = (64, 64)):
        self.neuron_ids = neuron_ids
        self.input_shape = input_shape
        self.n = len(neuron_ids)

    def encode(self, raw_input: Any, t_ms: float) -> Dict[int, float]:
        """
        raw_input: np.ndarray (H, W) hoặc (H, W, C) normalized 0-1
        Trả về dict neuron_id -> current (nA)
        """
        if raw_input is None:
            return {nid: 0.0 for nid in self.neuron_ids}

        if self.n == 0:
            return {}
        img = np.asarray(raw_input, dtype=np.float32)
        if img.size == 0:
            return {nid: 0.0 for nid in self.neuron_ids}
        if img.ndim == 3:
            img = img.mean(axis=2)
        if img.ndim != 2:
            raise ValueError("Vision input must be a 2D image or 3D image with channels")
        # Resize to a rectangle with at least n pixels (not a square of floor(sqrt(n))).
        from scipy.ndimage import zoom
        target_h = max(1, int(np.sqrt(self.n)))
        target_w = max(1, int(np.ceil(self.n / target_h)))
        zoom_factors = (target_h / img.shape[0], target_w / img.shape[1])
        resized = zoom(img, zoom_factors, order=1)
        flat = resized.flatten()[: self.n]
        if flat.size < self.n:
            flat = np.pad(flat, (0, self.n - flat.size), mode="edge")
        # Map intensity → current (0-10 nA)
        currents = flat * 10.0
        return {nid: float(currents[i]) for i, nid in enumerate(self.neuron_ids)}


class SimpleMotorDecoder(MotorDecoder):
    """
    Decoder vận động đơn giản: lấy activity của motor neurons → joint commands.
    """

    def __init__(self, motor_neuron_ids: List[int], joint_names: List[str]):
        self.motor_neuron_ids = motor_neuron_ids
        self.joint_names = joint_names
        self.n_joints = len(joint_names)

    def decode(self, motor_neuron_activities: Dict[int, float], t_ms: float) -> MotorCommand:
        acts = np.array([motor_neuron_activities.get(nid, 0.0) for nid in self.motor_neuron_ids])
        if len(acts) == 0:
            return MotorCommand(t_ms=t_ms)

        # Simple linear mapping (trong thực tế dùng population coding + biomechanics)
        n = min(len(acts), self.n_joints)
        joint_targets = {}
        for i in range(n):
            # Normalize activity to [-1, 1] range roughly
            val = np.tanh(acts[i] / 10.0)
            joint_targets[self.joint_names[i]] = float(val)

        return MotorCommand(
            t_ms=t_ms,
            joint_targets=joint_targets,
            muscle_activations={f"m_{k}": abs(v) for k, v in joint_targets.items()},
        )


class VirtualBody:
    """
    Cơ thể ảo tối giản (có thể thay bằng MuJoCo / custom physics sau).
    """

    def __init__(self):
        self.joint_angles: Dict[str, float] = {
            "head_yaw": 0.0,
            "head_pitch": 0.0,
            "left_arm": 0.0,
            "right_arm": 0.0,
            "left_leg": 0.0,
            "right_leg": 0.0,
        }
        self.position = np.array([0.0, 0.0, 0.0])
        self.orientation = 0.0  # yaw

    def apply_command(self, cmd: MotorCommand, dt_ms: float) -> None:
        for joint, target in cmd.joint_targets.items():
            if joint in self.joint_angles:
                # Simple first-order dynamics
                current = self.joint_angles[joint]
                self.joint_angles[joint] = current + 0.1 * (target - current)

    def get_proprioception(self) -> Dict[str, float]:
        return dict(self.joint_angles)

    def get_vision_placeholder(self) -> np.ndarray:
        """Trả về ảnh giả (trong thực tế render từ camera ảo)."""
        return np.random.rand(64, 64).astype(np.float32)


class SensorimotorInterface:
    """
    Lớp chính điều phối input cảm giác và output vận động.
    """

    def __init__(self):
        self.encoders: Dict[Modality, SensoryEncoder] = {}
        self.decoders: Dict[Modality, MotorDecoder] = {}
        self.virtual_body = VirtualBody()
        self._sensory_buffer: List[SensoryPacket] = []
        self._motor_history: List[MotorCommand] = []
        self.t_ms = 0.0

    def register_encoder(self, modality: Modality, encoder: SensoryEncoder) -> None:
        self.encoders[modality] = encoder
        logger.info(f"Registered encoder for {modality.value}")

    def register_decoder(self, modality: Modality, decoder: MotorDecoder) -> None:
        self.decoders[modality] = decoder
        logger.info(f"Registered decoder for {modality.value}")

    def inject_sensory(self, packet: SensoryPacket) -> Dict[int, float]:
        """
        Nhận dữ liệu cảm giác thô → encode thành current/spike cho neuron.
        Trả về dict neuron_id -> value để engine inject.
        """
        self._sensory_buffer.append(packet)
        encoder = self.encoders.get(packet.modality)
        if encoder is None:
            logger.warning(f"No encoder for modality {packet.modality}")
            return {}
        return encoder.encode(packet.data, packet.t_ms)

    def read_motor(
        self,
        motor_activities: Dict[int, float],
        t_ms: float,
    ) -> MotorCommand:
        """
        Đọc activity từ motor neurons → tạo lệnh vận động.
        """
        decoder = self.decoders.get(Modality.MOTOR)
        if decoder is None:
            return MotorCommand(t_ms=t_ms)

        cmd = decoder.decode(motor_activities, t_ms)
        self._motor_history.append(cmd)
        self.virtual_body.apply_command(cmd, dt_ms=1.0)  # assume 1ms step
        return cmd

    def step_virtual_body(self, dt_ms: float = 1.0) -> Dict[str, Any]:
        """Cập nhật cơ thể ảo và trả về dữ liệu cảm giác mới."""
        self.t_ms += dt_ms
        proprio = self.virtual_body.get_proprioception()
        vision = self.virtual_body.get_vision_placeholder()

        return {
            "proprioception": proprio,
            "vision": vision,
            "t_ms": self.t_ms,
        }

    def get_status(self) -> Dict[str, Any]:
        return {
            "encoders": list(self.encoders.keys()),
            "decoders": list(self.decoders.keys()),
            "joint_angles": self.virtual_body.joint_angles,
            "sensory_packets_buffered": len(self._sensory_buffer),
            "motor_commands_sent": len(self._motor_history),
        }
