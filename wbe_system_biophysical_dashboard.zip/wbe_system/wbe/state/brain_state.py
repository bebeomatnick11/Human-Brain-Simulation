"""
Part 7: Initial State Schema & Management

Định nghĩa schema trạng thái não + công cụ lưu/load/checkpoint + 
ước lượng trạng thái ban đầu từ dữ liệu có sẵn.
"""

from __future__ import annotations
import logging
import json
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone
from enum import Enum
import numpy as np
from pydantic import BaseModel, Field, field_validator
import h5py

from wbe.core.interfaces import NeuronState, SynapseState, BrainRegion

logger = logging.getLogger(__name__)


class StateSource(str, Enum):
    POSTMORTEM = "postmortem"
    STATISTICAL_PRIOR = "statistical_prior"
    PERSONALIZED = "personalized"
    SYNTHETIC = "synthetic"
    MIXED = "mixed"


class UncertaintyMap(BaseModel):
    """Mức độ tin cậy của từng thành phần trạng thái."""
    neuron_v_m: float = Field(0.5, ge=0.0, le=1.0)
    synapse_weights: float = Field(0.3, ge=0.0, le=1.0)
    neuromodulators: float = Field(0.4, ge=0.0, le=1.0)
    calcium: float = Field(0.2, ge=0.0, le=1.0)
    overall: float = Field(0.35, ge=0.0, le=1.0)


class NeuromodulatorField(BaseModel):
    dopamine: float = 0.0
    serotonin: float = 0.0
    acetylcholine: float = 0.0
    norepinephrine: float = 0.0
    extra: Dict[str, float] = Field(default_factory=dict)


class BrainState(BaseModel):
    """
    Container trạng thái đầy đủ của não tại một thời điểm.
    Đây là định dạng chuẩn mà engine (Part 4-5) và learning system dùng.
    """
    version: str = "1.0.0"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source: StateSource = StateSource.SYNTHETIC
    description: str = ""

    # Core data
    neurons: Dict[int, NeuronState] = Field(default_factory=dict)
    synapses: List[SynapseState] = Field(default_factory=list)
    neuromodulators: NeuromodulatorField = Field(default_factory=NeuromodulatorField)

    # Metadata
    t_ms: float = 0.0
    uncertainty: UncertaintyMap = Field(default_factory=UncertaintyMap)
    region_stats: Dict[str, Any] = Field(default_factory=dict)
    extra: Dict[str, Any] = Field(default_factory=dict)

    def n_neurons(self) -> int:
        return len(self.neurons)

    def n_synapses(self) -> int:
        return len(self.synapses)

    def get_neurons_by_region(self, region: BrainRegion) -> Dict[int, NeuronState]:
        return {k: v for k, v in self.neurons.items() if v.region == region}

    def summary(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "source": self.source.value,
            "t_ms": self.t_ms,
            "n_neurons": self.n_neurons(),
            "n_synapses": self.n_synapses(),
            "uncertainty_overall": self.uncertainty.overall,
            "created_at": self.created_at.isoformat(),
        }


class StateManager:
    """
    Quản lý lưu trữ, checkpoint, và khôi phục trạng thái não.
    """

    def __init__(self, base_path: str | Path = "./brain_states"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    def save(self, state: BrainState, name: str, compress: bool = True) -> Path:
        """Lưu BrainState ra file HDF5 + metadata JSON."""
        path = self.base_path / name
        path.mkdir(parents=True, exist_ok=True)

        # Metadata
        meta_path = path / "meta.json"
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(state.summary(), f, indent=2, default=str)

        # Full state (HDF5 for large arrays)
        h5_path = path / "state.h5"
        with h5py.File(h5_path, "w") as f:
            # Authoritative full-fidelity checkpoint. Legacy numeric datasets remain
            # below for compatibility with existing tools and quick inspection.
            full_json = state.model_dump_json()
            f.create_dataset("state_json", data=full_json, dtype=h5py.string_dtype(encoding="utf-8"))
            f.attrs["version"] = state.version
            f.attrs["t_ms"] = state.t_ms
            f.attrs["source"] = state.source.value

            # Neurons
            if state.neurons:
                n_ids = np.array(list(state.neurons.keys()), dtype=np.int64)
                v_ms = np.array([n.v_m for n in state.neurons.values()], dtype=np.float32)
                calciums = np.array([n.calcium for n in state.neurons.values()], dtype=np.float32)
                f.create_dataset("neuron_ids", data=n_ids, compression="gzip" if compress else None)
                f.create_dataset("v_m", data=v_ms, compression="gzip" if compress else None)
                f.create_dataset("calcium", data=calciums, compression="gzip" if compress else None)

            # Synapses (simplified)
            if state.synapses:
                pre = np.array([s.pre_id for s in state.synapses], dtype=np.int64)
                post = np.array([s.post_id for s in state.synapses], dtype=np.int64)
                weights = np.array([s.weight for s in state.synapses], dtype=np.float32)
                f.create_dataset("syn_pre", data=pre, compression="gzip" if compress else None)
                f.create_dataset("syn_post", data=post, compression="gzip" if compress else None)
                f.create_dataset("syn_weight", data=weights, compression="gzip" if compress else None)

            # Neuromodulators
            nm = state.neuromodulators
            f.attrs["dopamine"] = nm.dopamine
            f.attrs["serotonin"] = nm.serotonin
            f.attrs["acetylcholine"] = nm.acetylcholine
            f.attrs["norepinephrine"] = nm.norepinephrine

        logger.info(f"Saved BrainState to {path}")
        return path

    def load(self, name: str) -> BrainState:
        """Load BrainState từ thư mục đã lưu."""
        path = self.base_path / name
        h5_path = path / "state.h5"
        if not h5_path.exists():
            raise FileNotFoundError(f"State not found: {h5_path}")

        with h5py.File(h5_path, "r") as f:
            # Prefer exact schema-preserving checkpoint written by current versions.
            if "state_json" in f:
                raw = f["state_json"][()]
                if isinstance(raw, bytes): raw = raw.decode("utf-8")
                return BrainState.model_validate_json(raw)
            # Backward-compatible fallback for older checkpoints lacking state_json.
            state = BrainState(
                version=f.attrs.get("version", "1.0.0"),
                t_ms=float(f.attrs.get("t_ms", 0.0)),
                source=StateSource(f.attrs.get("source", "synthetic")),
            )

            if "neuron_ids" in f:
                ids = f["neuron_ids"][:]
                v_ms = f["v_m"][:]
                calciums = f["calcium"][:]
                for i, nid in enumerate(ids):
                    state.neurons[int(nid)] = NeuronState(
                        neuron_id=int(nid),
                        v_m=float(v_ms[i]),
                        calcium=float(calciums[i]),
                    )

            if "syn_pre" in f:
                pre = f["syn_pre"][:]
                post = f["syn_post"][:]
                weights = f["syn_weight"][:]
                for i in range(len(pre)):
                    state.synapses.append(
                        SynapseState(
                            pre_id=int(pre[i]),
                            post_id=int(post[i]),
                            weight=float(weights[i]),
                        )
                    )

            state.neuromodulators = NeuromodulatorField(
                dopamine=float(f.attrs.get("dopamine", 0.0)),
                serotonin=float(f.attrs.get("serotonin", 0.0)),
                acetylcholine=float(f.attrs.get("acetylcholine", 0.0)),
                norepinephrine=float(f.attrs.get("norepinephrine", 0.0)),
            )

        logger.info(f"Loaded BrainState from {path} ({state.n_neurons()} neurons)")
        return state

    def create_synthetic_state(
        self,
        n_neurons: int = 1000,
        n_synapses: int = 5000,
        seed: int = 42,
    ) -> BrainState:
        """Tạo trạng thái giả lập để test (khi chưa có data thật)."""
        rng = np.random.default_rng(seed)
        state = BrainState(source=StateSource.SYNTHETIC, description="Synthetic test state")

        regions = list(BrainRegion)
        for i in range(n_neurons):
            state.neurons[i] = NeuronState(
                neuron_id=i,
                region=regions[i % len(regions)],
                v_m=float(rng.uniform(-70, -50)),
                calcium=float(rng.uniform(0, 0.5)),
            )

        # Keep the requested count when at least two neurons exist. The old
        # `for range(n_synapses)` loop silently produced fewer edges whenever
        # a sampled self-connection was skipped.
        target_synapses = max(0, int(n_synapses)) if n_neurons >= 2 else 0
        while len(state.synapses) < target_synapses:
            pre = int(rng.integers(0, n_neurons))
            post = int(rng.integers(0, n_neurons))
            if pre == post:
                continue
            state.synapses.append(
                SynapseState(
                    pre_id=pre,
                    post_id=post,
                    weight=float(rng.uniform(0.1, 2.0)),
                    delay_ms=float(rng.uniform(0.5, 5.0)),
                )
            )

        state.uncertainty = UncertaintyMap(
            neuron_v_m=0.8,
            synapse_weights=0.7,
            overall=0.75,
        )
        return state

    def estimate_from_prior(
        self,
        region_sizes: Dict[BrainRegion, int],
        connectivity_density: float = 0.01,
    ) -> BrainState:
        """
        Ước lượng trạng thái ban đầu từ prior thống kê
        (dùng khi không có dữ liệu cá nhân).
        """
        state = BrainState(
            source=StateSource.STATISTICAL_PRIOR,
            description="Estimated from population priors",
        )
        nid = 0
        for region, n in region_sizes.items():
            for _ in range(n):
                # Typical resting potential
                state.neurons[nid] = NeuronState(
                    neuron_id=nid,
                    region=region,
                    v_m=-65.0 + np.random.normal(0, 3),
                    calcium=0.1,
                )
                nid += 1

        # Simple random connectivity
        neuron_ids = list(state.neurons.keys())
        n_syn = int(len(neuron_ids) * (len(neuron_ids) - 1) * connectivity_density)
        rng = np.random.default_rng(123)
        for _ in range(n_syn):
            pre, post = rng.choice(neuron_ids, size=2, replace=False)
            state.synapses.append(
                SynapseState(pre_id=int(pre), post_id=int(post), weight=0.5)
            )

        state.uncertainty.overall = 0.25  # low confidence
        return state
