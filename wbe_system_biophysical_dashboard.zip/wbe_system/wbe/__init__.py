"""WBE System — extensible brain-network simulation framework.

Parts 1-5 provide structural import, functional parameters, LIF dynamics,
network simulation and initialization. Parts 6-10 remain available as supporting
hardware, state, plasticity, sensorimotor and validation services.
"""
from wbe.connectome import ConnectomeDataset, ConnectomeLoader, NeuronRecord, SynapseRecord
from wbe.models.functional import NeuronParameters, SynapseParameters, FunctionalParameterSet, FunctionalParameterMapper
from wbe.models.lif import LIFNeuronModel
from wbe.models.inference import InferenceConfig, ParameterInferenceEngine, ParameterInferenceReport
from wbe.simulation.engine import SimulationEngine, SimulationConfig
from wbe.initialization.factory import InitialStateFactory, PersonalizedProfile
from wbe.hardware.manager import HardwareManager, HardwareConfig
from wbe.state.brain_state import BrainState, StateManager, StateSource
from wbe.learning.plasticity import PlasticityEngine, PlasticityConfig
from wbe.sensorimotor.interface import SensorimotorInterface, Modality, SensoryPacket
from wbe.validation.suite import ValidationSuite, ValidationLevel

__version__ = "0.2.0"
__all__ = ["ConnectomeDataset", "ConnectomeLoader", "NeuronRecord", "SynapseRecord", "NeuronParameters", "SynapseParameters",
"FunctionalParameterSet", "FunctionalParameterMapper", "LIFNeuronModel", "InferenceConfig", "ParameterInferenceEngine", "ParameterInferenceReport", "SimulationEngine", "SimulationConfig", "InitialStateFactory",
"PersonalizedProfile", "HardwareManager", "HardwareConfig", "BrainState", "StateManager", "StateSource", "PlasticityEngine",
"PlasticityConfig", "SensorimotorInterface", "Modality", "SensoryPacket", "ValidationSuite", "ValidationLevel"]
