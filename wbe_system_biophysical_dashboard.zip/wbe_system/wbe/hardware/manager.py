"""
Part 6: Hardware Abstraction & Resource Manager

Cung cấp lớp trừu tượng hóa phần cứng để simulation engine (Part 4)
có thể chạy trên CPU, GPU hoặc neuromorphic backend mà không cần sửa code.
"""

from __future__ import annotations
import logging
import psutil
import platform
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
import numpy as np

from wbe.core.interfaces import HardwareBackend, Precision, BrainRegion

logger = logging.getLogger(__name__)


@dataclass
class DeviceInfo:
    device_id: str
    backend: HardwareBackend
    name: str
    total_memory_gb: float
    available_memory_gb: float
    compute_capability: Optional[str] = None
    power_limit_w: Optional[float] = None
    is_neuromorphic: bool = False


@dataclass
class Allocation:
    handle: str
    region: BrainRegion
    n_neurons: int
    n_synapses: int
    device_id: str
    precision: Precision
    estimated_flops: float = 0.0
    memory_mb: float = 0.0


@dataclass
class HardwareConfig:
    preferred_backend: HardwareBackend = HardwareBackend.CUDA
    fallback_backend: HardwareBackend = HardwareBackend.CPU
    default_precision: Precision = Precision.MIXED
    max_power_w: Optional[float] = None
    enable_profiling: bool = True
    memory_safety_margin: float = 0.15  # keep 15% free


class HardwareManager:
    """
    Quản lý tài nguyên phần cứng cho mô phỏng não.
    """

    def __init__(self, config: Optional[HardwareConfig] = None):
        self.config = config or HardwareConfig()
        self.devices: Dict[str, DeviceInfo] = {}
        self.allocations: Dict[str, Allocation] = {}
        self._handle_counter = 0
        self._discover_devices()

    def _discover_devices(self) -> None:
        """Phát hiện các thiết bị có sẵn."""
        # Always add CPU
        mem = psutil.virtual_memory()
        self.devices["cpu:0"] = DeviceInfo(
            device_id="cpu:0",
            backend=HardwareBackend.CPU,
            name=platform.processor() or "CPU",
            total_memory_gb=mem.total / (1024**3),
            available_memory_gb=mem.available / (1024**3),
        )

        # Try CUDA
        try:
            import torch
            if torch.cuda.is_available():
                for i in range(torch.cuda.device_count()):
                    props = torch.cuda.get_device_properties(i)
                    free, total = torch.cuda.mem_get_info(i)
                    self.devices[f"cuda:{i}"] = DeviceInfo(
                        device_id=f"cuda:{i}",
                        backend=HardwareBackend.CUDA,
                        name=props.name,
                        total_memory_gb=total / (1024**3),
                        available_memory_gb=free / (1024**3),
                        compute_capability=f"{props.major}.{props.minor}",
                    )
        except ImportError:
            logger.info("PyTorch not available – CUDA backend disabled")

        # Simulated neuromorphic device (for development)
        self.devices["neuro:0"] = DeviceInfo(
            device_id="neuro:0",
            backend=HardwareBackend.NEUROMORPHIC,
            name="Simulated Neuromorphic Chip",
            total_memory_gb=64.0,
            available_memory_gb=64.0,
            is_neuromorphic=True,
        )

        logger.info(f"Discovered devices: {list(self.devices.keys())}")

    def list_devices(self) -> List[DeviceInfo]:
        return list(self.devices.values())

    def get_best_device(
        self,
        min_memory_gb: float = 1.0,
        prefer_neuromorphic: bool = False,
    ) -> Optional[DeviceInfo]:
        candidates = []
        for dev in self.devices.values():
            if dev.available_memory_gb < min_memory_gb:
                continue
            if prefer_neuromorphic and not dev.is_neuromorphic:
                continue
            candidates.append(dev)

        if not candidates:
            return self.devices.get("cpu:0")

        # Prefer CUDA > Neuromorphic > CPU
        priority = {
            HardwareBackend.CUDA: 3,
            HardwareBackend.NEUROMORPHIC: 2,
            HardwareBackend.CPU: 1,
            HardwareBackend.ROCM: 3,
            HardwareBackend.SIMULATED: 0,
        }
        candidates.sort(
            key=lambda d: (priority.get(d.backend, 0), d.available_memory_gb),
            reverse=True,
        )
        return candidates[0]

    def allocate(
        self,
        region: BrainRegion,
        n_neurons: int,
        n_synapses: int,
        precision: Optional[Precision] = None,
        preferred_device: Optional[str] = None,
    ) -> Allocation:
        """
        Cấp phát tài nguyên cho một vùng não.
        Trả về Allocation handle để engine sử dụng.
        """
        precision = precision or self.config.default_precision

        # Ước tính bộ nhớ thô (rất conservative)
        # 64 bytes / neuron + 32 bytes / synapse (state)
        est_memory_mb = (n_neurons * 64 + n_synapses * 32) / (1024 * 1024)
        est_memory_gb = est_memory_mb / 1024

        if preferred_device and preferred_device in self.devices:
            device = self.devices[preferred_device]
        else:
            device = self.get_best_device(min_memory_gb=est_memory_gb * 1.2)

        if device is None:
            raise RuntimeError("No suitable device found for allocation")

        self._handle_counter += 1
        handle = f"alloc_{self._handle_counter:08d}"

        allocation = Allocation(
            handle=handle,
            region=region,
            n_neurons=n_neurons,
            n_synapses=n_synapses,
            device_id=device.device_id,
            precision=precision,
            estimated_flops=n_neurons * 1000 + n_synapses * 50,  # rough
            memory_mb=est_memory_mb,
        )
        self.allocations[handle] = allocation

        # Update available memory (simplified)
        device.available_memory_gb = max(
            0.0, device.available_memory_gb - est_memory_gb
        )

        logger.info(
            f"Allocated {handle}: {n_neurons} neurons, {n_synapses} synapses "
            f"on {device.device_id} ({est_memory_mb:.1f} MB)"
        )
        return allocation

    def free(self, handle: str) -> None:
        if handle not in self.allocations:
            logger.warning(f"Handle {handle} not found")
            return
        alloc = self.allocations.pop(handle)
        if alloc.device_id in self.devices:
            self.devices[alloc.device_id].available_memory_gb += alloc.memory_mb / 1024
        logger.info(f"Freed {handle}")

    def get_allocation(self, handle: str) -> Optional[Allocation]:
        return self.allocations.get(handle)

    def summary(self) -> Dict[str, Any]:
        return {
            "devices": {
                d.device_id: {
                    "backend": d.backend.value,
                    "name": d.name,
                    "total_gb": round(d.total_memory_gb, 2),
                    "available_gb": round(d.available_memory_gb, 2),
                }
                for d in self.devices.values()
            },
            "active_allocations": len(self.allocations),
            "total_neurons_allocated": sum(a.n_neurons for a in self.allocations.values()),
            "total_synapses_allocated": sum(a.n_synapses for a in self.allocations.values()),
        }

    def recommend_partitioning(
        self,
        total_neurons: int,
        total_synapses: int,
        max_neurons_per_device: int = 10_000_000,
    ) -> List[Dict[str, Any]]:
        """
        Đề xuất cách chia não thành các partition phù hợp với phần cứng hiện có.
        """
        n_parts = max(1, (total_neurons + max_neurons_per_device - 1) // max_neurons_per_device)
        neurons_per = total_neurons // n_parts
        synapses_per = total_synapses // n_parts

        plan = []
        for i in range(n_parts):
            device = self.get_best_device(min_memory_gb=2.0)
            plan.append({
                "partition_id": i,
                "n_neurons": neurons_per if i < n_parts - 1 else total_neurons - neurons_per * (n_parts - 1),
                "n_synapses": synapses_per if i < n_parts - 1 else total_synapses - synapses_per * (n_parts - 1),
                "recommended_device": device.device_id if device else "cpu:0",
            })
        return plan
