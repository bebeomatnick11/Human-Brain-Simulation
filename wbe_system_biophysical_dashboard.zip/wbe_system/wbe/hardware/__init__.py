from .manager import HardwareManager, HardwareConfig
