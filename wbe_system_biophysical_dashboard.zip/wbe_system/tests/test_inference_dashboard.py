import csv
import gzip
import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer

from wbe.connectome.loader import ConnectomeDataset, ConnectomeLoader, NeuronRecord, SynapseRecord
from wbe.connectome.flywire_codex import download_connectome
from wbe.dashboard.server import SimulationWorkbench, make_handler, run_engine_self_test
from wbe.initialization.factory import InitialStateFactory
from wbe.models.inference import InferenceConfig, ParameterInferenceEngine
from wbe.simulation.engine import SimulationConfig, SimulationEngine
from wbe.core.interfaces import NeuronState, SynapseState
from wbe.state.brain_state import BrainState


class ParameterInferenceTests(unittest.TestCase):
    def test_fills_missing_parameters_and_marks_low_confidence_prior(self):
        ds = ConnectomeDataset(
            neurons=[NeuronRecord(1, cell_type="unknown"), NeuronRecord(2, cell_type="unknown")],
            synapses=[SynapseRecord(1, 2, weight=1.0, metadata={"connection_count": 8, "nt_type": "untyped"})],
        ).validate()
        params, report = ParameterInferenceEngine(InferenceConfig(seed=9)).infer(ds)
        self.assertGreater(params.neuron_for(1).tau_m_ms, 0)
        self.assertGreater(params.neuron_for(1).resistance_mohm, 0)
        self.assertAlmostEqual(params.neuron_for(1).tau_m_ms,
                               params.neuron_for(1).resistance_mohm * params.neuron_for(1).membrane_capacitance_nf, places=6)
        self.assertEqual(report.neuron_prior_count, 2)
        self.assertEqual(params.synapse_for(1, 2).receptor_type, "unknown")
        self.assertEqual(params.inference_metadata[1]["method"], "configurable_low_confidence_prior")
        state = InitialStateFactory().from_connectome(ds, params)
        self.assertIn("parameter_inference", state.neurons[1].meta)
        self.assertAlmostEqual(state.synapses[0].weight, 1.0)

    def test_observed_parameters_override_priors_and_report_partial_confidence(self):
        ds = ConnectomeDataset(
            neurons=[NeuronRecord(44, cell_type="measured", metadata={"tau_m_ms": 15.0, "resistance_mohm": 75.0})],
            synapses=[],
        ).validate()
        params, report = ParameterInferenceEngine(InferenceConfig(seed=2)).infer(ds)
        self.assertEqual(params.neuron_for(44).tau_m_ms, 15.0)
        self.assertEqual(params.neuron_for(44).resistance_mohm, 75.0)
        self.assertEqual(report.neuron_measured_count, 1)
        self.assertGreater(params.inference_metadata[44]["confidence"], 0.25)
        self.assertLess(params.inference_metadata[44]["confidence"], 1.0)

    def test_empirical_reference_csv_fills_missing_values_by_exact_cell_type(self):
        with tempfile.TemporaryDirectory() as d:
            ref = Path(d) / "physiology.csv"
            ref.write_text("cell_type,tau_m_ms,resistance_mohm,resting_potential_mv\nknown_type,13,65,-67\nknown_type,15,75,-69\n", encoding="utf-8")
            ds = ConnectomeDataset(neurons=[NeuronRecord(8, cell_type="Known_Type")], synapses=[]).validate()
            params, report = ParameterInferenceEngine(InferenceConfig(reference_csv=str(ref))).infer(ds)
            p = params.neuron_for(8)
            self.assertEqual(p.tau_m_ms, 14.0)
            self.assertEqual(p.resistance_mohm, 70.0)
            self.assertEqual(p.resting_potential_mv, -68.0)
            self.assertEqual(report.neuron_reference_matched_count, 1)
            self.assertEqual(params.inference_metadata[8]["method"], "empirical_reference_csv")

    def test_morphology_derivation_requires_explicit_user_supplied_membrane_constants(self):
        ds = ConnectomeDataset(
            neurons=[NeuronRecord(1, metadata={"surface_area_um2": 10000.0})], synapses=[]
        ).validate()
        cfg = InferenceConfig(specific_capacitance_uF_cm2=1.0,
                              specific_membrane_resistance_ohm_cm2=10000.0, seed=1)
        params, report = ParameterInferenceEngine(cfg).infer(ds)
        p = params.neuron_for(1)
        self.assertAlmostEqual(p.membrane_capacitance_nf, 0.1, places=6)
        self.assertAlmostEqual(p.resistance_mohm, 100.0, places=6)
        self.assertAlmostEqual(p.tau_m_ms, 10.0, places=6)
        self.assertEqual(report.neuron_morphology_derived_count, 1)

    def test_neurotransmitter_annotations_are_species_aware_and_uncertainty_preserving(self):
        self.assertEqual(ParameterInferenceEngine._receptor_from_nt("GABA", "fly"), ("inhibitory", True))
        self.assertEqual(ParameterInferenceEngine._receptor_from_nt("acetylcholine", "fly"), ("excitatory", True))
        self.assertEqual(ParameterInferenceEngine._receptor_from_nt("glutamate", "fly"), ("unknown", False))
        self.assertEqual(ParameterInferenceEngine._receptor_from_nt("glutamate", "human"), ("excitatory", True))

    def test_unknown_synapse_is_neutral_by_default_not_silently_excitation(self):
        params = {"tau_m_ms": 20.0, "resistance_mohm": 1.0, "resting_potential_mv": -65.0,
                  "reset_potential_mv": -65.0, "threshold_mv": -50.0, "refractory_ms": 2.0}
        state = BrainState(neurons={
            0: NeuronState(neuron_id=0, v_m=-65, intrinsic=dict(params)),
            1: NeuronState(neuron_id=1, v_m=-65, intrinsic=dict(params)),
        }, synapses=[SynapseState(pre_id=0, post_id=1, weight=500.0, delay_ms=1.0, receptor_type="unknown")])
        engine = SimulationEngine(SimulationConfig(dt_ms=1.0, update_plasticity=False))
        engine.step(state, {0: 400.0})
        engine.step(state, {})
        self.assertAlmostEqual(state.neurons[1].v_m, -65.0, places=6)


class FlyWireDownloaderOfflineTests(unittest.TestCase):
    def _write_gzip_csv(self, path, header, rows):
        path.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(path, "wt", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(rows)

    def test_offline_cached_csv_builds_subgraph_without_64bit_id_loss(self):
        # Root IDs intentionally exceed 2**53; round-tripping through float would corrupt them.
        a, b, c = 720575940630786105, 720575940610739662, 720575940545913232
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            cache = root / "raw"
            self._write_gzip_csv(cache / "fafb_connections_princeton.csv.gz",
                ["pre_root_id", "post_root_id", "syn_count", "nt_type", "neuropil"],
                [[a, b, 8, "acetylcholine", "AL_L"], [b, c, 5, "GABA", "MB_CA"], [c, a, 2, "glutamate", "LH_R"]])
            self._write_gzip_csv(cache / "fafb_consolidated_cell_types.csv.gz",
                ["root_id", "cell_type", "super_class", "nt_type"],
                [[a, "cell_a", "central", "acetylcholine"], [b, "cell_b", "central", "GABA"], [c, "cell_c", "sensory", "glutamate"]])
            out = root / "connectome.json"
            ds = download_connectome(out, api_token="fixture-token-is-not-used", max_neurons=3,
                                     max_synapses=20, cache_dir=cache, seed=1)
            self.assertEqual(len(ds.neurons), 3)
            self.assertEqual(len(ds.synapses), 3)
            ids = {n.neuron_id for n in ds.neurons}
            self.assertEqual(ids, {a, b, c})
            self.assertEqual(next(s for s in ds.synapses if s.pre_id == a).metadata["connection_count"], 8)
            loaded = ConnectomeLoader.from_json(out)
            self.assertEqual({n.neuron_id for n in loaded.neurons}, {a, b, c})
            self.assertFalse(loaded.metadata["biophysical_parameters_downloaded"])


class DashboardIntegrationTests(unittest.TestCase):
    def test_engine_self_test_and_real_simulation_generate_spikes(self):
        self.assertTrue(run_engine_self_test()["passed"])
        app = SimulationWorkbench()
        result = app.run(steps=120, target_id=0, amplitude_na=25.0, duration_steps=30)
        self.assertGreater(result["summary"]["run_spike_events"], 0)
        self.assertEqual(result["summary"]["final_time_ms"], 120.0)
        status = app.status()
        self.assertTrue(status["self_test"]["passed"])
        self.assertEqual(status["run_count"], 1)
        self.assertIn("network_preview", status)

    def test_http_dashboard_health_and_run_endpoints(self):
        app = SimulationWorkbench()
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_address[1]}"
        try:
            with urlopen(base + "/api/health", timeout=3) as response:
                self.assertEqual(response.status, 200)
                self.assertTrue(json.loads(response.read())["self_test"]["passed"])
            body = json.dumps({"steps": 80, "target_id": 0, "amplitude_na": 25, "duration_steps": 30}).encode()
            req = Request(base + "/api/run", body, {"Content-Type": "application/json"}, method="POST")
            with urlopen(req, timeout=5) as response:
                data = json.loads(response.read())
                self.assertTrue(data["ok"])
                self.assertGreater(data["summary"]["run_spike_events"], 0)
            with urlopen(base + "/", timeout=3) as response:
                html = response.read().decode()
                self.assertIn("Simulation Lab", html)
                self.assertIn("/api/run", html)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
