import json
import tempfile
import unittest
from pathlib import Path

from wbe.connectome.loader import ConnectomeDataset, ConnectomeLoader, NeuronRecord, SynapseRecord, ConnectomeValidationError
from wbe.core.interfaces import BrainRegion, NeuronState, SynapseState
from wbe.initialization.factory import InitialStateFactory, PersonalizedProfile
from wbe.models.lif import LIFNeuronModel
from wbe.simulation.engine import SimulationEngine, SimulationConfig
from wbe.state.brain_state import BrainState, StateManager, StateSource


class Part1ConnectomeTests(unittest.TestCase):
    def test_json_import_and_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'connectome.json'
            p.write_text(json.dumps({'neurons':[{'id':1,'region':'cortex'},{'id':2,'region':'thalamus'}],
                'synapses':[{'source':1,'target':2,'weight':0.7,'delay_ms':2.0}]}), encoding='utf-8')
            ds = ConnectomeLoader.from_json(p)
            self.assertEqual(len(ds.neurons), 2)
            self.assertEqual(ds.synapses[0].pre_id, 1)
            self.assertEqual(ds.synapses[0].delay_ms, 2.0)
    def test_reject_unknown_neuron(self):
        ds = ConnectomeDataset([NeuronRecord(1)], [SynapseRecord(1, 99)])
        with self.assertRaises(ConnectomeValidationError): ds.validate()

    def test_csv_and_npz_importers(self):
        import numpy as np
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            (d / "neurons.csv").write_text("neuron_id,region\n1,cortex\n2,thalamus\n", encoding="utf-8")
            (d / "synapses.csv").write_text("pre_id,post_id,weight,delay_ms\n1,2,0.4,1.5\n", encoding="utf-8")
            csv_ds = ConnectomeLoader.from_csv(d / "neurons.csv", d / "synapses.csv")
            self.assertEqual(csv_ds.synapses[0].weight, .4)
            npz = d / "connectome.npz"
            np.savez(npz, neuron_ids=np.array([1,2]), pre_ids=np.array([1]), post_ids=np.array([2]), weights=np.array([.4]))
            npz_ds = ConnectomeLoader.from_npz(npz)
            self.assertEqual(npz_ds.summary()["n_synapses"], 1)


class Part2And5Tests(unittest.TestCase):
    def test_connectome_to_brain_state(self):
        ds = ConnectomeDataset([NeuronRecord(1, 'cortex'), NeuronRecord(2, 'thalamus')], [SynapseRecord(1,2,.4,1.5)])
        state = InitialStateFactory().from_connectome(ds)
        self.assertEqual(state.source, StateSource.POSTMORTEM)
        self.assertEqual(state.neurons[1].region, BrainRegion.CORTEX)
        self.assertEqual(state.synapses[0].weight, .4)
        self.assertEqual(state.synapses[0].delay_ms, 1.5)
    def test_synthetic_is_deterministic_and_personalized(self):
        factory = InitialStateFactory()
        a = factory.synthetic(10, 20, seed=7)
        b = factory.synthetic(10, 20, seed=7)
        self.assertEqual([s.weight for s in a.synapses], [s.weight for s in b.synapses])
        customized = factory.personalized(a, PersonalizedProfile(neuron_voltage_mv={0:-60}, description='test'))
        self.assertEqual(customized.neurons[0].v_m, -60)
        self.assertEqual(customized.source, StateSource.PERSONALIZED)


class Part3LIFTests(unittest.TestCase):
    def test_spike_reset_and_refractory(self):
        n = NeuronState(neuron_id=1, v_m=-65, intrinsic={'tau_m_ms':20, 'resistance_mohm':1,
            'resting_potential_mv':-65, 'reset_potential_mv':-65, 'threshold_mv':-50, 'refractory_ms':2})
        model = LIFNeuronModel()
        r1 = model.step(n, 400, 0, 1)
        self.assertTrue(r1.spiked)
        self.assertEqual(r1.voltage_mv, -65)
        n.refractory_until_ms = r1.refractory_until_ms
        r2 = model.step(n, 400, 1, 1)
        self.assertFalse(r2.spiked)
        self.assertEqual(r2.voltage_mv, -65)


class Part4IntegrationTests(unittest.TestCase):
    def test_engine_integrates_and_calls_plasticity_compatible_result(self):
        state = BrainState(neurons={0:NeuronState(neuron_id=0,v_m=-65, intrinsic={'tau_m_ms':20,'resistance_mohm':1,
            'resting_potential_mv':-65,'reset_potential_mv':-65,'threshold_mv':-50,'refractory_ms':2}),
            1:NeuronState(neuron_id=1,v_m=-65)}, synapses=[SynapseState(pre_id=0,post_id=1,weight=1,delay_ms=1)])
        engine = SimulationEngine(SimulationConfig(dt_ms=1))
        result = engine.step(state, {0:400})
        self.assertEqual(result.t_ms, 1)
        self.assertIn(0, result.extra['spiking_neurons'])
        self.assertEqual(state.neurons[0].v_m, -65)
        # Event from neuron 0 arrives on a subsequent step.
        engine.step(state)
        self.assertGreater(state.neurons[1].v_m, -65)
    def test_unknown_sensory_neuron_fails_fast(self):
        engine = SimulationEngine()
        with self.assertRaises(KeyError): engine.step(BrainState(), {99:1})

    def test_full_connectome_to_motor_and_validation_pipeline(self):
        import numpy as np
        from wbe.sensorimotor.interface import SimpleMotorDecoder
        from wbe.validation.suite import ValidationSuite
        ds = ConnectomeDataset([NeuronRecord(0, "cortex"), NeuronRecord(1, "cortex")],
                               [SynapseRecord(0, 1, .8, 1.0)]).validate()
        state = InitialStateFactory().from_connectome(ds)
        for neuron in state.neurons.values():
            neuron.intrinsic.update({"tau_m_ms":20., "resistance_mohm":1., "resting_potential_mv":-65.,
                "reset_potential_mv":-65., "threshold_mv":-50., "refractory_ms":2.})
        state.neurons[1].meta["role"] = "motor"
        engine = SimulationEngine(SimulationConfig(dt_ms=1), motor_neuron_ids={1})
        results = [engine.step(state, {0:400. if i == 0 else 0.}) for i in range(5)]
        self.assertIn(1, results[-1].motor_activities)
        decoder = SimpleMotorDecoder([1], ["head_yaw"])
        command = decoder.decode(results[-1].motor_activities, results[-1].t_ms)
        self.assertIn("head_yaw", command.joint_targets)
        suite = ValidationSuite(run_id="parts1to10")
        suite.start_run()
        suite.run_cellular_checks(state.neurons, {nid:len(n.spikes) for nid,n in state.neurons.items()}, state.t_ms)
        suite.run_circuit_checks({nid:n.spikes for nid,n in state.neurons.items() if n.spikes})
        suite.run_systems_checks(np.sin(np.linspace(0, 20*np.pi, 256)), fs=1000.)
        report = suite.finalize()
        self.assertEqual(len(report.metrics), 4)


class Part5CheckpointTests(unittest.TestCase):
    def test_full_fidelity_checkpoint_roundtrip(self):
        state = BrainState(source=StateSource.PERSONALIZED, t_ms=12.5,
            neurons={7:NeuronState(neuron_id=7, region=BrainRegion.HIPPOCAMPUS, v_m=-54, spikes=[1.0,2.0], calcium=.7,
                resources={'x':.4}, intrinsic={'threshold_mv':-49}, meta={'cell_type':'test'}, refractory_until_ms=3.0, last_spike_ms=2.0)},
            synapses=[SynapseState(pre_id=7,post_id=7,weight=.3,delay_ms=2.5,facilitation=.4,depression=.8,
                receptor_type='inhibitory',meta={'tag':'keep'})], extra={'custom':{'a':1}})
        with tempfile.TemporaryDirectory() as d:
            manager = StateManager(d)
            manager.save(state, 'roundtrip')
            loaded = manager.load('roundtrip')
        self.assertEqual(loaded.model_dump(mode='json'), state.model_dump(mode='json'))

if __name__ == '__main__': unittest.main()
