"""Regression tests for the original supporting Parts 6-10 APIs."""
import tempfile
import unittest
from wbe.core.interfaces import BrainRegion, NeuronState, SynapseState
from wbe.state.brain_state import BrainState, StateManager
from wbe.learning.plasticity import PlasticityEngine, PlasticityConfig
from wbe.sensorimotor.interface import SensorimotorInterface, Modality, SensoryPacket, SimpleVisionEncoder
from wbe.simulation.engine import SimulationEngine, SimulationConfig

class ExistingPartsCompatibilityTests(unittest.TestCase):
    def test_part7_legacy_synthetic_and_checkpoint(self):
        manager = StateManager()
        state = manager.create_synthetic_state(n_neurons=12, n_synapses=25, seed=2)
        with tempfile.TemporaryDirectory() as d:
            manager2 = StateManager(d)
            manager2.save(state, 'legacy_api')
            loaded = manager2.load('legacy_api')
        self.assertEqual(loaded.n_neurons(), 12)
        self.assertEqual(loaded.n_synapses(), 25)

    def test_part8_plasticity_can_be_called_by_engine(self):
        state = BrainState(neurons={0:NeuronState(neuron_id=0,v_m=-65,intrinsic={'tau_m_ms':20,'resistance_mohm':1,
                'resting_potential_mv':-65,'reset_potential_mv':-65,'threshold_mv':-50,'refractory_ms':2}),
                1:NeuronState(neuron_id=1,v_m=-65)},
                synapses=[SynapseState(pre_id=0,post_id=1,weight=.5,delay_ms=1)])
        plasticity = PlasticityEngine(PlasticityConfig(enable_homeostatic=False, enable_short_term=True))
        engine = SimulationEngine(SimulationConfig(dt_ms=1), plasticity_engine=plasticity)
        result = engine.step(state, {0:400}, {'dopamine':0.1})
        self.assertEqual(len(result.synapse_updates), 1)
        self.assertIn('effective_weight', state.synapses[0].meta)

    def test_part9_sensorimotor_encoder_api_unchanged(self):
        interface = SensorimotorInterface()
        interface.register_encoder(Modality.VISION, SimpleVisionEncoder(list(range(8))))
        encoded = interface.inject_sensory(SensoryPacket(modality=Modality.VISION, t_ms=0, data=[[0,1],[1,0]]))
        self.assertIsInstance(encoded, dict)
        self.assertTrue(set(encoded).issubset(set(range(8))))

if __name__ == '__main__': unittest.main()
