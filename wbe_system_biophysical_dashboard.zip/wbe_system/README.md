# WBE System — Parts 1–10 integration scaffold

This repository is a research-oriented **network simulation framework**, not a complete human-brain emulation or mind-upload system. Structural connectome data describes connectivity; it does not by itself provide complete functional dynamics or validate biological realism.

## Parts 1–5

1. **Structural connectome** — local JSON, paired CSV, and NPZ import; ID/edge/weight/delay validation; no implicit data download.
2. **Functional parameters** — explicit LIF parameters, synaptic receptor class, delays, STP metadata, and neuromodulator sensitivity.
3. **Neuron model** — current-based leaky integrate-and-fire (LIF), threshold/reset, refractory interval and calcium proxy.
4. **Simulation engine** — deterministic discrete time, sensory current injection, delayed synaptic events, spike history, optional Part 8 plasticity integration, and a shared `SimulationStepResult`.
5. **Initial state** — reproducible synthetic network, statistical prior, structural connectome mapping, personalized state overrides, and full-fidelity checkpoints.

## Parts 6–10 kept

- Part 6: hardware/resource manager abstraction (its simulated backend is a prototype, not real accelerator execution).
- Part 7: `BrainState`, `StateManager`, checkpoint persistence.
- Part 8: plasticity rules.
- Part 9: sensorimotor encoders/decoders.
- Part 10: validation suite.

Existing state fields and method entry points are retained. New fields are additive and have defaults. Current checkpoint files store an authoritative `state_json` payload while retaining legacy HDF5 arrays; older checkpoints continue to load through a compatibility path.

## Install and test

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m compileall -q wbe tests demo.py
python demo.py
```

## Minimal Parts 1–5 example

```python
from wbe import InitialStateFactory, SimulationEngine, SimulationConfig

state = InitialStateFactory().synthetic(n_neurons=100, n_synapses=400, seed=7)
engine = SimulationEngine(SimulationConfig(dt_ms=1.0))
for _ in range(100):
    result = engine.step(state, sensory_input={0: 20.0})
print(state.summary(), result.extra)
```

`sensory_input` values are injected currents in nA in this simplified model. Parameters and numerical scales are configurable abstractions, not calibrated biological measurements. Use licensed, documented local datasets for connectome imports and record their provenance.

## Biological parameter inference and real-data imports (new)

### What the inference engine does

`wbe.models.inference.ParameterInferenceEngine` assigns a parameter set to each neuron and synapse, with a provenance record and an engineering confidence score. Its order of evidence is:

1. Numeric parameters already present in the source row / `metadata` / `physiology` / `intrinsic` fields.
2. Morphology-derived passive properties only when both a surface-area value and user-supplied specific membrane constants are available. In that configured case, capacitance is derived from area and specific capacitance, resistance from area and specific membrane resistance, and `tau_m_ms = resistance_mohm * membrane_capacitance_nf`.
3. Optional empirical reference CSV rows, matched exactly by case-insensitive `cell_type`/`type`/`class`; repeated types are pooled by median.
4. A reproducible configurable prior for remaining values.

The priors are **generic LIF-model priors, not a species-calibrated electrophysiology database**. The species option currently affects neurotransmitter-to-sign interpretation; it must not be read as evidence that missing human values have been measured. Confidence scores are audit heuristics, not Bayesian probabilities. Structural connection counts are normalized into bounded model gains for simulation, not treated as measured synaptic conductance.

Unknown transmitter/receptor sign is retained as `unknown`. In the Parts 1–5 engine, unknown connections are neutral by default rather than being silently assumed excitatory. An explicit source annotation or a deliberate `SimulationConfig(unknown_receptor_policy="excitatory")`/`"inhibitory"` override can change that behavior.

### Download a bounded FlyWire Codex connectome subgraph

The importer uses the official static Codex product endpoints and defaults to `connections_princeton` and `consolidated_cell_types`. Its output is a reproducibly sampled *induced subgraph*, not the whole connectome. Downloaded raw CSV files are cached separately and are not included in this source ZIP. Public resource downloading requires a Codex API token; do not paste the token into source code or the HTML page.

Linux/macOS shell:

```bash
export FLYWIRE_CODEX_API_TOKEN="YOUR_CODEX_TOKEN"
python -m wbe.connectome.flywire_codex \
  --dataset fafb \
  --max-neurons 500 \
  --max-synapses 10000 \
  --seed 73 \
  --output data/flywire_fafb_sample.json
```

PowerShell:

```powershell
$env:FLYWIRE_CODEX_API_TOKEN = "YOUR_CODEX_TOKEN"
python -m wbe.connectome.flywire_codex --dataset fafb --max-neurons 500 --max-synapses 10000 --output data/flywire_fafb_sample.json
```

For another supported public Codex snapshot, use `--dataset banc`. Product names can be overridden with `--connections-product` and `--cell-types-product`. The full raw resource can be large even when the resulting subgraph is small; the downloader has a per-file safety cap and can reuse its on-disk cache. Review the current Codex portal's data-version, licensing, terms, and citation requirements before redistributing any downloaded data.

### Optional empirical physiology reference CSV

If you have a published/curated table of electrophysiology measurements with documented provenance, set `WBE_PHYSIOLOGY_REFERENCE_CSV` before starting the dashboard. Supported columns include `cell_type` (or `type`/`class`) plus any of `tau_m_ms`, `resistance_mohm`, `membrane_capacitance_nf`, `resting_potential_mv`, `reset_potential_mv`, `threshold_mv`, `refractory_ms`, `calcium_decay_ms`, and `excitability`. Do not mix measurements from incompatible preparations without noting species, region, temperature, age, recording configuration, and source; this loader is a table matcher, not a scientific harmonization pipeline.

### Real HTML dashboard and operational test

Start the backend from the repository root:

```bash
python -m wbe.dashboard.server --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000` in a browser. This page is served by Python and calls the actual `SimulationEngine`, not a front-end-only animation. It supports stimulus injection, spike/voltage plots, network-preview drawing from the current state, parameter snapshots, JSON report export, local connectome upload, and optional FlyWire import (when the environment token is configured).

At startup, `/api/health` checks a smoke path containing a real LIF spike/reset and a delayed synaptic event that changes the receiver voltage. This confirms the code executes and the event path is connected; it **does not establish biological fidelity, behavior reproduction, human-brain emulation, or consciousness**. By default the dashboard binds only to loopback; do not expose this development server to the public internet.

Run all regression/integration tests and demos:

```bash
python -m compileall -q wbe tests demo.py demo_parts_1_5.py
python -m unittest discover -s tests -v
python demo_parts_1_5.py
python demo.py
```

The FlyWire connector test uses offline fixture CSVs so CI does not require or consume a private API token. A successful fixture test is not proof that a live remote download succeeded; use the downloader on your machine with a valid token to verify access to your selected dataset.

## Data-source references

- FlyWire Codex FAQ / programmatic downloads: https://codex.flywire.ai/faq
- FlyWire Codex current public dataset and data-product pages: https://codex.flywire.ai/
- neuPrint Python client / access and query documentation (alternative source for suitable fruit-fly datasets): https://connectome-neuprint.github.io/neuprint-python/docs/quickstart.html
- Allen Institute Teaching Connectomics / MICrONS and CAVE access (requires CAVE token for programmatic access): https://alleninstitute.github.io/Teaching_Connectomics/notebooks/microns_data_access_education.html
