#!/usr/bin/env python3
"""Small end-to-end demonstration of Parts 1-5 with optional Part 8 plasticity."""
from wbe.connectome.loader import ConnectomeDataset, NeuronRecord, SynapseRecord
from wbe.initialization.factory import InitialStateFactory
from wbe.learning.plasticity import PlasticityEngine, PlasticityConfig
from wbe.simulation.engine import SimulationEngine, SimulationConfig


def main():
    # In production, load a licensed local JSON/CSV/NPZ export using ConnectomeLoader.
    connectome = ConnectomeDataset(
        neurons=[NeuronRecord(0, "cortex"), NeuronRecord(1, "cortex"), NeuronRecord(2, "thalamus")],
        synapses=[SynapseRecord(0, 1, weight=0.8, delay_ms=1.0, receptor_type="excitatory"),
                  SynapseRecord(1, 2, weight=0.5, delay_ms=2.0, receptor_type="excitatory")],
        metadata={"source": "tiny illustrative network", "biological_data": False},
    ).validate()
    state = InitialStateFactory().from_connectome(connectome)
    # Give demo neurons explicit point-neuron dynamics.
    for neuron in state.neurons.values():
        neuron.intrinsic.update({"tau_m_ms": 20.0, "resistance_mohm": 1.0,
            "resting_potential_mv": -65.0, "reset_potential_mv": -65.0,
            "threshold_mv": -50.0, "refractory_ms": 2.0, "excitability": 1.0})
    plasticity = PlasticityEngine(PlasticityConfig(enable_homeostatic=False))
    engine = SimulationEngine(SimulationConfig(dt_ms=1.0), plasticity_engine=plasticity)
    for step in range(10):
        sensory = {0: 350.0 if step == 0 else 0.0}
        result = engine.step(state, sensory_input=sensory, neuromodulators={"dopamine": 0.0})
        print(f"t={result.t_ms:5.1f} ms | spikes={result.extra['spiking_neurons']} | pending={result.extra['pending_events']}")
    print("Final state:", state.summary())

if __name__ == "__main__":
    main()
