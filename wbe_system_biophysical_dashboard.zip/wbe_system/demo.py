#!/usr/bin/env python3
"""
Demo tích hợp Parts 6-10.
Chạy thử toàn bộ pipeline với dữ liệu synthetic.
"""

import logging
import numpy as np
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from wbe.hardware.manager import HardwareManager, HardwareConfig
from wbe.state.brain_state import StateManager
from wbe.core.interfaces import BrainRegion
from wbe.learning.plasticity import PlasticityEngine, PlasticityConfig
from wbe.sensorimotor.interface import (
    SensorimotorInterface,
    Modality,
    SensoryPacket,
    SimpleVisionEncoder,
    SimpleMotorDecoder,
)
from wbe.validation.suite import ValidationSuite

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(name)s | %(message)s")
console = Console()


def main():
    console.print(Panel.fit("[bold cyan]WBE System Demo – Parts 6-10[/bold cyan]"))

    # ========== 6. Hardware ==========
    console.print("\n[bold]6. Hardware Manager[/bold]")
    hw = HardwareManager(HardwareConfig(preferred_backend="cuda"))
    console.print(hw.summary())

    alloc = hw.allocate(
        region=BrainRegion.CORTEX,
        n_neurons=10_000,
        n_synapses=100_000,
    )
    console.print(f"Allocated handle: {alloc.handle} on {alloc.device_id}")

    # ========== 7. State ==========
    console.print("\n[bold]7. Brain State[/bold]")
    sm = StateManager("./demo_states")
    state = sm.create_synthetic_state(n_neurons=500, n_synapses=2000)
    console.print(state.summary())
    path = sm.save(state, "demo_v1")
    console.print(f"Saved to {path}")

    # ========== 8. Learning ==========
    console.print("\n[bold]8. Plasticity Engine[/bold]")
    pe = PlasticityEngine(PlasticityConfig(enable_structural=True))
    # Fake spike times
    spike_times = {i: [10.0, 25.0] for i in range(0, 50, 5)}
    nm = {"dopamine": 0.3, "serotonin": 0.1}
    updated_syn = pe.process_synapses(state.synapses[:100], spike_times, nm, dt_ms=1.0)
    console.print(f"Updated {len(updated_syn)} synapses")
    console.print(pe.get_stats())

    # ========== 9. Sensorimotor ==========
    console.print("\n[bold]9. Sensorimotor Interface[/bold]")
    smi = SensorimotorInterface()
    vision_neurons = list(range(100))
    motor_neurons = list(range(200, 210))
    smi.register_encoder(Modality.VISION, SimpleVisionEncoder(vision_neurons))
    smi.register_decoder(
        Modality.MOTOR,
        SimpleMotorDecoder(motor_neurons, ["head_yaw", "left_arm", "right_arm"]),
    )

    fake_image = np.random.rand(64, 64)
    packet = SensoryPacket(modality=Modality.VISION, t_ms=0.0, data=fake_image)
    currents = smi.inject_sensory(packet)
    console.print(f"Encoded vision → {len(currents)} neuron currents")

    motor_act = {nid: np.random.uniform(0, 15) for nid in motor_neurons}
    cmd = smi.read_motor(motor_act, t_ms=1.0)
    console.print(f"Motor command: {cmd.joint_targets}")
    console.print(smi.get_status())

    # ========== 10. Validation ==========
    console.print("\n[bold]10. Validation Suite[/bold]")
    val = ValidationSuite(run_id="demo_run")
    val.start_run()

    neurons = state.neurons
    spike_counts = {i: np.random.randint(0, 20) for i in list(neurons.keys())[:100]}
    val.run_cellular_checks(neurons, spike_counts, duration_ms=1000.0)

    spike_times_full = {i: list(np.random.uniform(0, 1000, size=5)) for i in range(50)}
    val.run_circuit_checks(spike_times_full)

    pop_activity = np.random.randn(2000) + np.sin(np.linspace(0, 20 * np.pi, 2000))
    val.run_systems_checks(pop_activity, fs=1000.0)

    report = val.finalize()
    console.print(report.summary())

    # Summary table
    table = Table(title="Parts 6-10 Status")
    table.add_column("Part", style="cyan")
    table.add_column("Component", style="green")
    table.add_column("Status")
    table.add_row("6", "HardwareManager", "OK")
    table.add_row("7", "StateManager + BrainState", "OK")
    table.add_row("8", "PlasticityEngine", "OK")
    table.add_row("9", "SensorimotorInterface", "OK")
    table.add_row("10", "ValidationSuite", "OK")
    console.print(table)

    console.print("\n[bold green]Demo hoàn tất. Bạn có thể gắn simulation engine (Part 4-5) vào các interface này.[/bold green]")


if __name__ == "__main__":
    main()
